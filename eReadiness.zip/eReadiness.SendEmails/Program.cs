﻿using eReadiness.DataContext.Models;
using NLog;
using Skoda.SenderWSSecuredRest.Model;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.Entity;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Runtime.Serialization.Json;
using System.Security.Cryptography;
using System.Text;
using eReadiness.Utils;

namespace eReadiness.SendEmails
{
    class Program
    {
        private static Logger Log = LogManager.GetCurrentClassLogger();

        static void Main(string[] args)
        {
            ProcessReadiness();
            ProcessCarriers();
        }

        public static void ProcessReadiness()
        {
            Log.Info("ProcessReadiness");
            try
            {
                using (var context = new DataContext.ERContext())
                {
                    var emailsQuery = context.EmailQuery.Where(x => x.DateDeleted == null && x.DateSent == null)
                        .Include(x => x.Form.Project.FormTemplate.LocalizedTemplates)
                        .ToList();
                    foreach (var emailQuery in emailsQuery)
                    {
                        try
                        {
                            var emailTo = emailQuery.Form.Supplier.SupplierContacts.FirstOrDefault(x => x.Disponent == emailQuery.Form.Disponent)?.Email;
                            if (emailTo == null)
                                emailTo = emailQuery.Form.Supplier.Email;
                            var email = new Email();
                            email.From = Configuration.FromAddress;

                            email.To = !string.IsNullOrEmpty(Configuration.DebugEmail) ? Configuration.DebugEmail : emailTo;

                            string body = string.Empty;
                            string subject = string.Empty;

                            List<Attachment> attachments = new List<Attachment>();
                            foreach (var localizedTemplate in emailQuery.Form.Project.FormTemplate.LocalizedTemplates.OrderBy(x => x.Language.LangCode))
                            {
                                foreach (var attach in localizedTemplate.EmailAttachments.Where(x => x.AsAttachment == true))
                                {
                                    if (!attachments.Exists(x => x.FileName == attach.FileName))
                                    {
                                        attachments.Add(new Attachment()
                                        {
                                            FileName = attach.FileName,
                                            FileData = attach.Data,
                                            ContentType = "application/octet-stream",
                                            IsSetTransferEncoding = true,
                                            TransferEncoding = System.Net.Mime.TransferEncoding.Base64,
                                        });
                                    }
                                }
                                if (emailQuery.Form.FormState == FormState.Sent)
                                {
                                    Log.Debug($"Form sent. Using urgent.");
                                    body = body + localizedTemplate.MailBodyUrgent + "<hr/>";
                                }
                                else
                                {
                                    body = body + localizedTemplate.MailBody + "<hr/>";
                                }

                                subject = subject + localizedTemplate.MailSubject + " | ";
                            }
                            body = body.Replace('\n', ' ').Replace('\r', ' ').Replace('\t', ' ');
                            email.Body =
                                string.Format(
                                    "<!DOCTYPE html><html><head><meta charset='utf-8' /></head><body><p>{0}</p></body></html>",
                                    body);
                            email.Body = email.Body.Replace(Configuration.eReadinessUrl, string.Format("{0}{1}", Configuration.eReadinessUrl, "/Forms/Fill/" + emailQuery.Form.Code));
                            email.Subject = subject.Trim().Trim('|').Trim();
                            email.Subject = email.Subject.ReplacePlaceholdersWithProjectValues(emailQuery?.Form?.Project);
                            email.Body = email.Body.ReplacePlaceholdersWithProjectValues(emailQuery?.Form?.Project);
                            email.IsBodyHtml = true;
                            email.Attachments = attachments.ToArray();
                            Log.Debug($"Sending email to : {email.To}");
                            try
                            {
                                Send(email);
                                emailQuery.Result = "Ok";
                            }
                            catch (Exception ex)
                            {
                                emailQuery.Result = ex.Message;
                            }
                            emailQuery.DateSent = DateTime.Now;
                            if (emailQuery.Form.FormState == FormState.Ready)
                                emailQuery.Form.FormState = FormState.Sent;
                            context.SaveChanges();
                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine(ex.Message);
                            Log.Error(ex);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                Log.Error(ex);
            }
        }

        public static void ProcessCarriers()
        {
            Log.Info("ProcessCarriers");
            try
            {
                using (var context = new DataContext.ERContext())
                {
                    var emailsQuery = context.CarrierEmailQuery.Where(x => x.DateDeleted == null && x.DateSent == null).ToList();

                    var carrierFormTemplates = context.CarrierLocalizedTemplates.Include(x => x.CarrierFormTemplate).OrderBy(x => x.Language.LangCode).ToList();
                    foreach (var emailQuery in emailsQuery)
                    {
                        try
                        {
                            var emailTo = emailQuery.CarrierForm.Carrier.Email;
                            var email = new Email
                            {
                                From = Configuration.FromAddress,
                                To = !string.IsNullOrEmpty(Configuration.DebugEmail) ? Configuration.DebugEmail : emailTo
                            };

                            string body = string.Empty;
                            string subject = string.Empty;
                            
                            //List<Attachment> attachments = new List<Attachment>();
                            foreach (var carrierFormTemplate in carrierFormTemplates)
                            {
                                if (emailQuery.CarrierForm.FormState == FormState.Sent)
                                {
                                    Log.Debug($"Form sent. Using urgent.");
                                    body = body + carrierFormTemplate.MailBodyUrgent + "<hr/>";
                                }
                                else
                                {
                                    body = body + carrierFormTemplate.MailBody + "<hr/>";
                                }

                                subject = subject + carrierFormTemplate.MailSubject + " | ";
                            }
                            body = body.Replace('\n', ' ').Replace('\r', ' ').Replace('\t', ' ');
                            email.Body =
                                string.Format(
                                    "<!DOCTYPE html><html><head><meta charset='utf-8' /></head><body><p>{0}</p></body></html>",
                                    body);
                            email.Body = email.Body.Replace(Configuration.eReadinessUrl, string.Format("{0}{1}", Configuration.CarrierFillUrl, "/CarrierForms/Fill/" + emailQuery.CarrierForm.Code));
                            email.Subject = subject.Trim().Trim('|').Trim();
                            email.IsBodyHtml = true;
                            //email.Attachments = attachments.ToArray();
                            Log.Debug($"Sending email to : {email.To}");
                            
                            try
                            {
                                Send(email);
                                emailQuery.Result = "Ok";
                            }
                            catch (Exception ex)
                            {
                                emailQuery.Result = ex.Message;
                            }
                            emailQuery.DateSent = DateTime.Now;
                            if (emailQuery.CarrierForm.FormState == FormState.Ready)
                                emailQuery.CarrierForm.FormState = FormState.Sent;
                            context.SaveChanges();
                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine(ex.Message);
                            Log.Error(ex);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                Log.Error(ex);
            }
        }

        /// <summary>
        /// Provede odeslání emailu.
        /// </summary>
        /// <param name="email">Email k odeslání.</param>
        public static void Send(Email email)
        {
            // For the test cert that isn't trusted.
            ServicePointManager.ServerCertificateValidationCallback = delegate { return true; };

            using (var webClient = new WebClient())
            {
                using (var contentStream = new MemoryStream())
                {
                    var contentSerializer = new DataContractJsonSerializer(typeof(Email));
                    contentSerializer.WriteObject(contentStream, email);

                    string operationUri = Configuration.ServiceUrl + "/SendEmail";

                    webClient.Headers["Content-type"] = "application/json";
                    string now = string.Format(CultureInfo.GetCultureInfo("en-US"), "{0:ddd,' 'dd' 'MMM' 'yyyy' 'HH':'mm':'ss' 'K}", DateTime.UtcNow);
                    string dateHeaderName = Configuration.DateHeaderName;
                    webClient.Headers[dateHeaderName] = now;
                    string content;
                    contentStream.Position = 0;
                    using (var streamReader = new StreamReader(contentStream))
                    {
                        content = streamReader.ReadToEnd();
                    }
                    string messageToken = string.Format("{0}:{1}\n{2}", dateHeaderName, now, content);
                    string senderSignature = Configuration.SenderSignature;
                    string messageSignature = ComputeHash(messageToken, senderSignature);
                    string senderAccountName = Configuration.SenderAccountName;
                    string authorizationHeaderName = Configuration.AuthorizationHeaderName;
                    webClient.Headers[authorizationHeaderName] = string.Format("{0}:{1}", senderAccountName, messageSignature);

                    byte[] responseBytes;

                    try
                    {
                        responseBytes = webClient.UploadData(operationUri, "POST", contentStream.ToArray());
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.Message);
                        Log.Error(ex);
                        throw new Exception("Odeslání emailu se nezdařilo.", ex);
                    }

                    using (var responseStream = new MemoryStream(responseBytes))
                    {
                        var responseSerializer = new DataContractJsonSerializer(typeof(string));
                        var response = responseSerializer.ReadObject(responseStream);
                    }
                }
            }
        }

        private static string ComputeHash(string inputString, string inputKey)
        {
            var key = inputKey ?? string.Empty;
            var keyInBytes = Encoding.UTF8.GetBytes(key);

            using (var hmacsha256 = new HMACSHA256(keyInBytes))
            {
                var input = Encoding.UTF8.GetBytes(inputString);
                var hashmessage = hmacsha256.ComputeHash(input);
                return Convert.ToBase64String(hashmessage);
            }
        }

        public static class Configuration
        {
            const string DbContextUserKey = "DbContextUser";
            const string AppDomainKey = "AppDomain";
            const string AuthorizationHeaderNameKey = "AuthorizationHeaderName";
            const string DateHeaderNameKey = "DateHeaderName";
            const string FromAddressKey = "FromAddress";
            const string SenderAccountNameKey = "SenderAccountName";
            const string SenderSignatureKey = "SenderSignature";
            const string SenderUrlKey = "SenderUrl";
            const string eReadinessUrlKey = "eReadinessUrl";
            const string CarrierFillUrlKey = "CarrierFillUrl";

            public static string DbContextUser { get { return ConfigurationManager.AppSettings[DbContextUserKey]; } }

            /// <summary>
            /// Vrací root http cesty do aplikace.
            /// </summary>
            /// <remarks>
            /// Slouží k sestavené http odkazu do aplikace.
            /// </remarks>
            public static string AppDomain { get { return ConfigurationManager.AppSettings[AppDomainKey]; } }
            public static string AuthorizationHeaderName { get { return ConfigurationManager.AppSettings[AuthorizationHeaderNameKey]; } }
            public static string DateHeaderName { get { return ConfigurationManager.AppSettings[DateHeaderNameKey]; } }
            public static string FromAddress { get { return ConfigurationManager.AppSettings[FromAddressKey]; } }
            public static string SenderAccountName { get { return ConfigurationManager.AppSettings[SenderAccountNameKey]; } }
            public static string SenderSignature { get { return ConfigurationManager.AppSettings[SenderSignatureKey]; } }
            public static string ServiceUrl { get { return ConfigurationManager.AppSettings[SenderUrlKey]; } }
            public static string eReadinessUrl { get { return ConfigurationManager.AppSettings[eReadinessUrlKey]; } }
            public static string CarrierFillUrl { get { return ConfigurationManager.AppSettings[CarrierFillUrlKey]; } }
            public static string DebugEmail { get { return ConfigurationManager.AppSettings["DebugEmail"]; } }
        }
    }
 
}
