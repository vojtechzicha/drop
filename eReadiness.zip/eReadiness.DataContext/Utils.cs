﻿/*
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace eReadiness.DataContext
{
    public static class Utils
    {
        public static string GetUsername()
        {
            try
            {
                ClaimsPrincipal oClaimsPrincipal = (ClaimsPrincipal)Thread.CurrentPrincipal;
                return oClaimsPrincipal.Claims.Where(x => x.Type.StartsWith(((ClaimsIdentity)oClaimsPrincipal.Identity).NameClaimType)).Select(x => x.Value).FirstOrDefault();
            }
            catch { return ""; }
        }

    }
}
*/