﻿using eReadiness.DataContext.Models.Abstracts;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace eReadiness.DataContext.Models
{
    public class Question : ISoftDeleteEntity
    {
        public string QuestionText { get; set; }
        public bool ShowInReport { get; set; }
        public virtual ICollection<FormTemplateLocalized_Question> FormTemplateLocalized_Questions { get; set; }
    }
}