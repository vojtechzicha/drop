﻿using eReadiness.DataContext.Models.Abstracts;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Security.Cryptography;
using System.Web;

namespace eReadiness.DataContext.Models
{
    public class Form : ISoftDeleteEntity
    {
        public Form()
        {
            Code = GetRandomString(100);
        }

        [StringLength(100)]
        public string Code { get; set; }
        public DateTime DateSent { get; set; }
        public DateTime DateFilled { get; set; }
        public int Completition { get; set; }
        public FormState FormState { get; set; }
        public MilestoneType MilestoneType { get; set; }
        //public ICollection<Project> Project { get; set; }
        public virtual Project Project { get; set; }
        public virtual Disponent Disponent { get; set; }
        public virtual Disponent DisponentOriginal { get; set; }
        public virtual Supplier Supplier { get; set; }
        public virtual ICollection<Note> Notes { get; set; }
        public virtual ICollection<Material> Materials { get; set; }
        public string FilledBy { get; set; }
        public string ContactProjectManagement { get; set; }
        public string ContactRepresentationOfManager { get; set; }
        public string ContactLogistics247 { get; set; }
        public string ContactQuality { get; set; }
        public string ContactEscalation { get; set; }

        public bool CompleteOk => Completition == 100;

        private static string GetRandomString(int length)
        {
            using (RNGCryptoServiceProvider rnd = new RNGCryptoServiceProvider())
            {
                byte[] r = new byte[length / 2];
                rnd.GetBytes(r);
                return string.Concat(r.Select(item => item.ToString("x2")));
            }
        }
    }
    public enum MilestoneType
    {
        VFF = 1,
        PVS = 2,
        S0 = 3
    }
    public enum FormState
    {
        Ready = 0,
        Sent = 1,
        Opened = 2,
        Closed = 3
    }
}