﻿using eReadiness.DataContext.Models.Abstracts;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace eReadiness.DataContext.Models
{
    public class WERK : ISoftDeleteEntity
    {
        public string WerkCode { get; set; }
        public string Name { get; set; }
    }
}