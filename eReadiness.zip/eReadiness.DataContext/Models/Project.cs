﻿using eReadiness.DataContext.Models.Abstracts;
using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace eReadiness.DataContext.Models
{
    public class Project : ISoftDeleteEntity
    {
        public PID PID { get; set; }
        public WERK WERK { get; set; }
        public string Name { get; set; }
        [Column("SOP", TypeName = "date")]
        public DateTime SOP { get; set; }
        [Column("PVS", TypeName = "date")]
        public DateTime? PVS { get; set; }
        [Column("VFF", TypeName = "date")]
        public DateTime? VFF { get; set; }
        [Column("OS", TypeName = "date")]
        public DateTime? OS { get; set; }
        public virtual FormTemplate FormTemplate { get; set; }
    }
}