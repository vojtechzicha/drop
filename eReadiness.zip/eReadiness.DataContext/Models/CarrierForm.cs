﻿using eReadiness.DataContext.Models.Abstracts;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Security.Cryptography;

namespace eReadiness.DataContext.Models
{
    public class CarrierForm : ISoftDeleteEntity
    {
        public CarrierForm()
        {
            Code = GetRandomString(100);
        }

        [StringLength(100)]
        public string Code { get; set; }
        public DateTime? DateSent { get; set; }
        public DateTime? DateFilled { get; set; }
        public DateTime? ValidUntil { get; set; }
        [StringLength(100)]
        public string FilledBy { get; set; }
        public int Completition { get; set; }
        public FormState FormState { get; set; }
        public virtual Carrier Carrier { get; set; }
        public virtual ICollection<Note> Notes { get; set; }

        public bool CompleteOk => Completition == 100;

        private static string GetRandomString(int length)
        {
            using (RNGCryptoServiceProvider rnd = new RNGCryptoServiceProvider())
            {
                byte[] r = new byte[length / 2];
                rnd.GetBytes(r);
                return string.Concat(r.Select(item => item.ToString("x2")));
            }
        }
    }
}