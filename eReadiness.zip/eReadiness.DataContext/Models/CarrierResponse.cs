﻿using eReadiness.DataContext.Models.Abstracts;

namespace eReadiness.DataContext.Models
{
    public class CarrierResponse : ISoftDeleteEntity
    {
        public string Question { get; set; }
        public string Value { get; set; }
        public virtual CarrierForm Form { get; set; }
    }
}