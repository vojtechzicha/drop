﻿using eReadiness.DataContext.Models.Abstracts;
using System.Collections.Generic;

namespace eReadiness.DataContext.Models
{
    public class CarrierFormTemplate : ISoftDeleteEntity
    {
        public string TemplateName { get; set; }
        public CarrierType CarrierType { get; set; }
        public virtual ICollection<CarrierFormTemplateLocalized> LocalizedTemplates { get; set; }
    }
}