﻿using eReadiness.DataContext.Models.Abstracts;
using System.Collections.Generic;

namespace eReadiness.DataContext.Models
{
    public class CarrierFormTemplateLocalized : ISoftDeleteEntity
    {
        public string MailSubject { get; set; }
        public string MailBody { get; set; }
        public string MailBodyUrgent { get; set; }
        public virtual Language Language { get; set; }
        public virtual CarrierFormTemplate CarrierFormTemplate { get; set; }
        //public virtual ICollection<CarrierEmailAttachment> EmailAttachments { get; set; }
    }
}
