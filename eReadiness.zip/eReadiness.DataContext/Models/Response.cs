﻿using eReadiness.DataContext.Models.Abstracts;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace eReadiness.DataContext.Models
{
    public class Response : ISoftDeleteEntity
    {
        public bool ResponseValue { get; set; }
        public string ResponseReason { get; set; }
        public virtual Form Form { get; set; }
        public virtual Question Question { get; set; }
    }
}