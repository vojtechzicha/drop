﻿using eReadiness.DataContext.Models.Abstracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace eReadiness.DataContext.Models
{
    public class FormTemplateLocalized : ISoftDeleteEntity
    {
        public string MailSubject { get; set; }
        public string MailBody { get; set; }
        public string MailBodyUrgent { get; set; }
        public virtual Language Language { get; set; }
        public virtual FormTemplate ParentTemplate { get; set; }
        //public virtual ICollection<Question> Questions { get; set; }
        public virtual ICollection<FormTemplateLocalized_Question> FormTemplateLocalized_Questions { get; set; }

        public virtual ICollection<EmailAttachment> EmailAttachments { get; set; }
    }
}
