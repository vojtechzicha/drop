﻿using eReadiness.DataContext.Models.Abstracts;
using System;
using System.ComponentModel.DataAnnotations;

namespace eReadiness.DataContext.Models
{
    public class Note : ISoftDeleteEntity
    {
        public string NoteText { get; set; }
        public virtual Form Form { get; set; }
    }
}