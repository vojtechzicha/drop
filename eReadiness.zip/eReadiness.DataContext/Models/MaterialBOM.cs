﻿using eReadiness.DataContext.Models.Abstracts;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace eReadiness.DataContext.Models
{
    public class MaterialBOM : IIntIdEntity
    {
        [Index("IX_MaterialBOM", Order = 1)]
        [StringLength(3)]
        public string PROD_ID { get; set; }

        [Index("IX_MaterialBOM", Order = 2)]
        [StringLength(2)]
        public string WK { get; set; }

        [StringLength(20)]
        [Index("IX_MaterialBOM", Order = 3)]
        public string TEIL_NR { get; set; }

        public bool NOTB { get; set; }

        [StringLength(8)]
        [Index("IX_MaterialBOM", Order = 4)]
        public string SOP { get; set; }

        public DateTime SOPDATE { get; set; }

        [StringLength(200)]
        public string BEN { get; set; }

        public bool NOTCOLOR { get; set; }

        [StringLength(3)]
        public string DISP { get; set; }
    }
}
