﻿using eReadiness.DataContext.Models.Abstracts;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace eReadiness.DataContext.Models
{
    public class Material : ISoftDeleteEntity
    {
        [StringLength(20)]
        public string Number { get; set; }
        [StringLength(200)]
        public string Name { get; set; }
        public bool ManualAdded { get; set; }
        public bool ManualDeleted { get; set; }
        public virtual Form Form { get; set; }
    }
}