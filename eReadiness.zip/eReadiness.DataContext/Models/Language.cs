﻿using eReadiness.DataContext.Models.Abstracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace eReadiness.DataContext.Models
{
    public class Language : ISoftDeleteEntity
    {
        public string LangCode { get; set; }
    }
}
