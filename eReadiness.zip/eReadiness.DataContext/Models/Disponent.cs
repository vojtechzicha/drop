﻿using eReadiness.DataContext.Models.Abstracts;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace eReadiness.DataContext.Models
{
    public class Disponent : ISoftDeleteEntity
    {
        public string DispoCode { get; set; }
        public string Name { get; set; }
        public virtual ICollection<Language> Languages { get; set; }

        public string DisplayName => $"{DispoCode} - {Name}";
    }
}