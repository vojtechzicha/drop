﻿using eReadiness.DataContext.Models.Abstracts;

namespace eReadiness.DataContext.Models
{
    public class SupplierDuns : IIntIdEntity
    {
        public string DunsCode { get; set; }
    }
}