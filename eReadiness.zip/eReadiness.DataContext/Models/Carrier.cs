﻿using eReadiness.DataContext.Models.Abstracts;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations.Schema;

namespace eReadiness.DataContext.Models
{
    public class Carrier : ISoftDeleteEntity
    {
        public string DunsCode { get; set; }
        public string Name { get; set; }
        public string Address { get; set; }
        public string Email { get; set; }
        public string SAP { get; set; }
        public virtual Language PrefferedLanguage { get; set; }
        public CarrierType CarrierType { get; set; }
    }

    public enum CarrierType
    {
        [Description("Inbound")]
        Inbound = 1,
        [Description("Outbound")]
        Outbound = 2
    }
}
