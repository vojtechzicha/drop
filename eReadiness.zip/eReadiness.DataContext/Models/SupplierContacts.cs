﻿using eReadiness.DataContext.Models.Abstracts;

namespace eReadiness.DataContext.Models
{
    public class SupplierContacts : ISoftDeleteEntity
    {
        public virtual Disponent Disponent { get; set; }
        public string Email { get; set; }
    }
}