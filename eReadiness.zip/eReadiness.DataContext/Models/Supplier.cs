﻿using eReadiness.DataContext.Models.Abstracts;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;

namespace eReadiness.DataContext.Models
{
    public class Supplier : ISoftDeleteEntity
    {
        //public string DunsCode { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public virtual Language PrefferedLanguage { get; set; }
        public virtual ICollection<SupplierContacts> SupplierContacts { get; set; }
        public virtual ICollection<SupplierDuns> DunsCodes { get; set; }

        [NotMapped]
        public string DunsCode
        {
            get
            {
                try
                {
                    return string.Join("\n", DunsCodes.Select(x => x.DunsCode));
                }
                catch
                {
                    return "";
                }
            }
        }
    }
}