﻿using eReadiness.DataContext.Models.Abstracts;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations.Schema;

namespace eReadiness.DataContext.Models
{
    public class PID : ISoftDeleteEntity
    {
        public string ProjectCode { get; set; }
        public string Name { get; set; }
        public PIDType Type { get; set; }
    }

    public enum PIDType
    {
        [Description("Car")]
        Car = 1,
        [Description("Component")]
        Component = 2
    }
}