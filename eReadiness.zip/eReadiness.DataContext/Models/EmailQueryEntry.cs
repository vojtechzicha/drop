﻿using eReadiness.DataContext.Models.Abstracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace eReadiness.DataContext.Models
{
    public class EmailQueryEntry : ISoftDeleteEntity
    {
        /*public string RecipientEmailAdress { get; set; }
        public virtual FormTemplate FormTemplate { get; set; }*/
        public virtual Form Form { get; set; }
        public DateTime? DateSent { get; set; }
        public string Result { get; set; }
    }
}
