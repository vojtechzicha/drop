﻿using eReadiness.DataContext.Models.Abstracts;
using System;

namespace eReadiness.DataContext.Models
{
    public class CarrierEmailQueryEntry : ISoftDeleteEntity
    {
        public virtual CarrierForm CarrierForm { get; set; }
        public DateTime? DateSent { get; set; }
        public string Result { get; set; }
    }
}
