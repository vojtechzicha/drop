﻿using eReadiness.DataContext.Models.Abstracts;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace eReadiness.DataContext.Models
{
    public class FormTemplate : ISoftDeleteEntity
    {
        public string TemplateName { get; set; }
        public virtual ICollection<FormTemplateLocalized> LocalizedTemplates { get; set; }
    }
}