﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace eReadiness.DataContext.Models.Abstracts
{
    public abstract class IIntIdEntity
    {
        [Key]
        public int Id { get; set; }
    }
}
