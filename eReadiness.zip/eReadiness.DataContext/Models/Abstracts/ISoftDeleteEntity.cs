﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace eReadiness.DataContext.Models.Abstracts
{
    public abstract class ISoftDeleteEntity : IChangeTrackedEntity
    {
        [StringLength(100)]
        public string DeletedBy { get; set; }
        public DateTime? DateDeleted { get; set; }
    }
}
