﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace eReadiness.DataContext.Models.Abstracts
{
    public abstract class IChangeTrackedEntity : IIntIdEntity
    {
        public DateTime DateCreated { get; set; }
        public DateTime DateModified { get; set; }
        [StringLength(100)]
        public string CreatedBy { get; set; }
        [StringLength(100)]
        public string UpdatedBy { get; set; }

        public IChangeTrackedEntity()
        {
            DateCreated = DateTime.Now;
            DateModified = DateTime.Now;
        }
    }
}
