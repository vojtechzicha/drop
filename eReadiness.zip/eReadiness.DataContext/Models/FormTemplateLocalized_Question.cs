﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace eReadiness.DataContext.Models
{
    public class FormTemplateLocalized_Question
    {
        [Key, Column(Order = 0)]
        public int FormTemplateLocalizedID { get; set; }
        [Key, Column(Order = 1)]
        public int QuestionID { get; set; }

        public virtual FormTemplateLocalized LocalizedForm { get; set; }
        public virtual Question Question { get; set; }

        public int QuestionOrder { get; set; }
    }
}
