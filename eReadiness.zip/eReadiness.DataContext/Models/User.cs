﻿using System.ComponentModel.DataAnnotations;

namespace eReadiness.DataContext.Models
{
    public class User
    {
        [Key]
        [StringLength(20)]
        public string Name { get; set; }
        [StringLength(100)]
        public string Roles { get; set; }
    }
}