﻿using eReadiness.DataContext.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity.Migrations;
using System.Linq;

namespace eReadiness.DataContext
{

    internal sealed class Configuration : DbMigrationsConfiguration<eReadiness.DataContext.ERContext>
    {
        public Configuration()
        {
            AutomaticMigrationsEnabled = true;
        }

        protected override void Seed(ERContext context)
        {
            if (context.Questions.Any())
                return;

            if (System.Diagnostics.Debugger.IsAttached == false)
            {
                System.Diagnostics.Debugger.Launch();
            }

            var q1 = new Question
            {
                QuestionText = "Termín dodání dílů pro VFF k TBT termínu {VFF}",
                ShowInReport = true
            };
            var q2 = new Question
            {
                QuestionText = "Delivery time of VFF parts to TBT term {VFF}",
                ShowInReport = true
            };
            var q3 = new Question
            {
                QuestionText = "Lieferzeit von VFF-Teilen nach TBT Term {VFF}",
                ShowInReport = true
            };
            var q4 = new Question
            {
                QuestionText = "Termín dodání dílů pro PVS k TBT termínu {PVS}",
                ShowInReport = true
            };
            var q5 = new Question
            {
                QuestionText = "Delivery date for PVS parts to TBT term {PVS}",
                ShowInReport = true
            };
            var q6 = new Question
            {
                QuestionText = "Liefertermin für PVS-Teile nach TBT Term {PVS}",
                ShowInReport = true
            };
            var q7 = new Question
            {
                QuestionText = "Termín dodání dílů pro 0S k TBT termínu {0S}",
                ShowInReport = true
            };
            var q8 = new Question
            {
                QuestionText = "Termín dodání vzorků N3 nejpozději k TBT PVS v {PVS} včetně BEONU",
                ShowInReport = true
            };
            var q9 = new Question
            {
                QuestionText = "Zadané termíny N3/N1 jsou v LIONu (vyplňte nejpozději do 5 pracovních dnů po obdržení tohoto formuláře)",
                ShowInReport = true
            };
            var q10 = new Question
            {
                QuestionText = "Kvalitativní (generační) stav je k TBT VFF v {VFF} finální (tz. po TBT VFF není plánovaná žádná další optimalizace/AEKO)",
                ShowInReport = true
            };
            var q11 = new Question
            {
                QuestionText = "Stav dezénu je k TBT VFF v {VFF} finální (v případě, že je relevantní) (tz.po TBT VFF není plánovaná žádná další optimalizace / AEKO)",
                ShowInReport = true
            };
            var q12 = new Question
            {
                QuestionText = "EDI odvolávky jsou pro Vás viditelné v systému",
                ShowInReport = true
            };
            var q13 = new Question
            {
                QuestionText = "EDI call-offs are visible to you in the system",
                ShowInReport = true
            };
            var q14 = new Question
            {
                QuestionText = "EDI-Abrufe sind für Sie im System sichtbar",
                ShowInReport = true
            };

            context.Questions.AddRange(new[] { q1, q2, q3, q4, q5, q6, q7, q8, q9, q10, q11, q12, q13, q14 });

            var l1 = new Language
            {
                LangCode = "CS"
            };
            var l2 = new Language
            {
                LangCode = "EN"
            };
            var l3 = new Language
            {
                LangCode = "DE"
            };

            context.Languages.AddRange(new[] { l1, l2, l3 });

            var t1 = new FormTemplate
            {
                TemplateName = "Základní formulář",
                LocalizedTemplates = new List<FormTemplateLocalized>()
            };
            var t2 = new FormTemplate
            {
                TemplateName = "Rozšířený formulář",
                LocalizedTemplates = new List<FormTemplateLocalized>()
            };
            var t3 = new FormTemplate
            {
                TemplateName = "Další formulář",
                LocalizedTemplates = new List<FormTemplateLocalized>()
            };

            context.FormTemplates.AddRange(new[] { t1, t2, t3 });

            var l11 = new FormTemplateLocalized
            {
                MailSubject = "Formulář pro dodavatele",
                MailBody = "Prosíme vyplňte tento formulář.",
                Language = l1,
                ParentTemplate = t1
            };
            var l12 = new FormTemplateLocalized
            {
                MailSubject = "For for suppliers",
                MailBody = "Please fill this form.",
                Language = l2,
                ParentTemplate = t1
            };
            var l13 = new FormTemplateLocalized
            {
                MailSubject = "Das form fur der DODAVATEL(DE)",
                MailBody = "Bitte VYPLNIT(DE).",
                Language = l3,
                ParentTemplate = t1
            };
            t1.LocalizedTemplates.Add(l11);
            t1.LocalizedTemplates.Add(l12);
            t1.LocalizedTemplates.Add(l13);

            var l21 = new FormTemplateLocalized
            {
                MailSubject = "Rozšířený formulář",
                MailBody = "Toto je rozšířený formulář.",
                Language = l1,
                ParentTemplate = t2
            };
            var l22 = new FormTemplateLocalized
            {
                MailSubject = "Extended form",
                MailBody = "This form is extended.",
                Language = l2,
                ParentTemplate = t2
            };

            t2.LocalizedTemplates.Add(l21);
            t2.LocalizedTemplates.Add(l22);

            var l31 = new FormTemplateLocalized
            {
                MailSubject = "Další formulář",
                MailBody = "Nějaký další formulář.",
                Language = l1,
                ParentTemplate = t3
            };
            var l32 = new FormTemplateLocalized
            {
                MailSubject = "Another form",
                MailBody = "Some another form",
                Language = l2,
                ParentTemplate = t3
            };
            t3.LocalizedTemplates.Add(l31);
            t3.LocalizedTemplates.Add(l32);

            context.LocalizedTemplates.AddRange(new[] { l11, l12, l13, l21, l22, l31, l32 });

            context.SaveChanges();

            var ftl_q_binding1 = new FormTemplateLocalized_Question
            {
                LocalizedForm = l11,
                Question = q1,
                QuestionOrder = 1
            };

            var ftl_q_binding2 = new FormTemplateLocalized_Question
            {
                LocalizedForm = l11,
                Question = q4,
                QuestionOrder = 2
            };

            var ftl_q_binding3 = new FormTemplateLocalized_Question
            {
                LocalizedForm = l12,
                Question = q2,
                QuestionOrder = 1
            };

            var ftl_q_binding4 = new FormTemplateLocalized_Question
            {
                LocalizedForm = l12,
                Question = q5,
                QuestionOrder = 2

            };

            var ftl_q_binding5 = new FormTemplateLocalized_Question
            {
                LocalizedForm = l13,
                Question = q3,
                QuestionOrder = 1
            };

            var ftl_q_binding6 = new FormTemplateLocalized_Question
            {
                LocalizedForm = l13,
                Question = q6,
                QuestionOrder = 2

            };

            context.FormTemplateLocalized_Questions.AddRange(new[] { ftl_q_binding1, ftl_q_binding2, ftl_q_binding3, ftl_q_binding4, ftl_q_binding5, ftl_q_binding6 });

            var p1 = new PID
            {
                ProjectCode = "5EP",
                Name = "Karoq"
            };
            var p2 = new PID
            {
                ProjectCode = "5EN",
                Name = "Octavia NF"
            };
            var p3 = new PID
            {
                ProjectCode = "55A",
                Name = "Kodiaq"
            };

            context.PIDs.AddRange(new[] { p1, p2, p3 });

            var w1 = new WERK
            {
                WerkCode = "31",
                Name = "Mladá Boleslav"
            };
            var w2 = new WERK
            {
                WerkCode = "33",
                Name = "Kvasiny"
            };
            var w3 = new WERK
            {
                WerkCode = "74",
                Name = "Indie"
            };

            context.WERKs.AddRange(new[] { w1, w2, w3 });

            var d1 = new Disponent
            {
                DispoCode = "0JN",
                Name = "Jan Novák"
            };
            var d2 = new Disponent
            {
                DispoCode = "1MH",
                Name = "Martin Henten"
            };
            var d3 = new Disponent
            {
                DispoCode = "2DZ",
                Name = "David Zowie"
            };

            context.Disponents.AddRange(new[] { d1, d2, d3 });

            var s1 = new Supplier
            {
                //DunsCode = "BOSHBOSHB",
                Name = "Bosch",
                Email = "hrdy@bosch.com",
                PrefferedLanguage = l1
            };
            var s2 = new Supplier
            {
                //DunsCode = "MGNMGNMGN",
                Name = "Magna",
                Email = "nejaka@magna.cz",
                PrefferedLanguage = l2
            };
            var s3 = new Supplier
            {
                //DunsCode = "VWGVWGVWG",
                Name = "Volkswagen",
                Email = "kleman@vwg.com",
                PrefferedLanguage = l3
            };

            context.Suppliers.AddRange(new[] { s1, s2, s3 });

            var car1 = new Carrier
            {
                DunsCode = "12345679",
                Name = "Dopravce1",
                Email = "e1@dopravce1.cz",
                Address = "Adresa 123",
                SAP = "12345678",
                PrefferedLanguage = l1
            };
            context.Carriers.AddRange(new[] { car1 });

            var formsList = new List<Form>
            {
                new Form
                {
                    Disponent = d1,
                    Materials = new List<Material>
                    {
                        new Material
                        {
                            Number = "5WA919298"
                        },
                        new Material
                        {
                            Number = "5WA937086A"
                        },
                        new Material
                        {
                            Number = "5WA937086B"
                        }
                    },
                    Supplier = s1,
                    Project = new Project
                    {
                        Name = "Karoq 2020",
                        PID = p1,
                        WERK = w1,
                        OS = DateTime.Now.AddDays(7).StartOfWeek(DayOfWeek.Monday),
                        PVS = DateTime.Now.AddDays(14).StartOfWeek(DayOfWeek.Monday),
                        SOP = DateTime.Now.AddDays(21).StartOfWeek(DayOfWeek.Monday),
                        VFF = DateTime.Now.AddDays(28).StartOfWeek(DayOfWeek.Monday),
                        FormTemplate = t1
                    },
                    FormState = FormState.Ready,
                    MilestoneType = MilestoneType.PVS
                },
                new Form
                {
                    Disponent = d2,
                    Materials = new List<Material>
                    {
                        new Material
                        {
                            Number = "123456789"
                        },
                        new Material
                        {
                            Number = "0123456789"
                        },
                        new Material
                        {
                            Number = "111111111"
                        }
                    },
                    Supplier = s2,
                    Project = new Project
                    {
                        Name = "Octavia 2019",
                        PID = p2,
                        WERK = w2,
                        OS = DateTime.Now.AddDays(35).StartOfWeek(DayOfWeek.Monday),
                        PVS = DateTime.Now.AddDays(42).StartOfWeek(DayOfWeek.Monday),
                        SOP = DateTime.Now.AddDays(49).StartOfWeek(DayOfWeek.Monday),
                        VFF = DateTime.Now.AddDays(56).StartOfWeek(DayOfWeek.Monday),
                        FormTemplate = t2
                    },
                    FormState = FormState.Ready,
                    MilestoneType = MilestoneType.S0
                },
                new Form
                {
                    Disponent = d3,
                    Materials = new List<Material>
                    {
                        new Material
                        {
                            Number = "5WA5WA5WA"
                        },
                        new Material
                        {
                            Number = "159357456"
                        },
                        new Material
                        {
                            Number = "QWERTYUIO"
                        }
                    },
                    Supplier = s3,
                    Project = new Project
                    {
                        Name = "Kodiaq 2020",
                        PID = p3,
                        WERK = w3,
                        OS = DateTime.Now.AddDays(15).StartOfWeek(DayOfWeek.Monday),
                        PVS = DateTime.Now.AddDays(17).StartOfWeek(DayOfWeek.Monday),
                        SOP = DateTime.Now.AddDays(26).StartOfWeek(DayOfWeek.Monday),
                        VFF = DateTime.Now.AddDays(33).StartOfWeek(DayOfWeek.Monday),
                        FormTemplate = t3
                    },
                    FormState = FormState.Ready,
                    MilestoneType = MilestoneType.VFF
                },
                new Form
                {
                    Disponent = d1,
                    Materials = new List<Material>
                    {
                        new Material
                        {
                            Number = "AAABBBCCC"
                        },
                        new Material
                        {
                            Number = "QQQAAAZZZ"
                        },
                        new Material
                        {
                            Number = "PLMOKNIJB"
                        }
                    },
                    Supplier = s1,
                    Project = new Project
                    {
                        Name = "Kodiaq 2021",
                        PID = p3,
                        WERK = w2,
                        OS = DateTime.Now.AddDays(1).StartOfWeek(DayOfWeek.Monday),
                        PVS = DateTime.Now.AddDays(19).StartOfWeek(DayOfWeek.Monday),
                        SOP = DateTime.Now.AddDays(48).StartOfWeek(DayOfWeek.Monday),
                        VFF = DateTime.Now.AddDays(200).StartOfWeek(DayOfWeek.Monday),
                        FormTemplate = t3,
                    },
                    FormState = FormState.Ready,
                    MilestoneType = MilestoneType.PVS
                },
                new Form
                {
                    Disponent = d3,
                    Materials = new List<Material>
                    {
                        new Material
                        {
                            Number = "89734512384"
                        },
                        new Material
                        {
                            Number = "897435612310"
                        },
                        new Material
                        {
                            Number = "753214587455"
                        }
                    },
                    Supplier = s2,
                    Project = new Project
                    {
                        Name = "Octavia 2020",
                        PID = p2,
                        WERK = w1,
                        OS = DateTime.Now.AddDays(99).StartOfWeek(DayOfWeek.Monday),
                        PVS = DateTime.Now.AddDays(120).StartOfWeek(DayOfWeek.Monday),
                        SOP = DateTime.Now.AddDays(220).StartOfWeek(DayOfWeek.Monday),
                        VFF = DateTime.Now.AddDays(330).StartOfWeek(DayOfWeek.Monday),
                        
                        FormTemplate = t2,
                    },
                    FormState = FormState.Ready,
                    MilestoneType = MilestoneType.S0
                }
            };

            context.Forms.AddRange(formsList);
            context.SaveChanges();
        }
    }

    public static class DateTimeExtensions
    {
        public static DateTime StartOfWeek(this DateTime dt, DayOfWeek startOfWeek)
        {
            int diff = (7 + (dt.DayOfWeek - startOfWeek)) % 7;
            return dt.AddDays(-1 * diff).Date;
        }
    }
}