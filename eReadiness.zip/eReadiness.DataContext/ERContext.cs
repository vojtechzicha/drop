﻿using EntityFramework.DynamicFilters;
using eReadiness.DataContext.Models;
using eReadiness.DataContext.Models.Abstracts;
using Npgsql;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.Entity;
using System.Data.Entity.Core.Metadata.Edm;
using System.Data.Entity.Core.Objects;
using System.Data.Entity.Infrastructure;
using System.Data.SqlClient;
using System.Linq;

namespace eReadiness.DataContext
{
    public class ERContext : DbContext
    {
        public DbSet<SupplierContacts> SupplierContacts { get; set; }
        public DbSet<EmailQueryEntry> EmailQuery { get; set; }
        public DbSet<FormTemplate> FormTemplates { get; set; }
        public DbSet<FormTemplateLocalized> LocalizedTemplates { get; set; }
        public DbSet<Question> Questions { get; set; }
        public DbSet<Project> Projects { get; set; }
        public DbSet<Supplier> Suppliers { get; set; }
        public DbSet<Note> Notes { get; set; }
        public DbSet<Response> Responses { get; set; }
        public DbSet<WERK> WERKs { get; set; }
        public DbSet<PID> PIDs { get; set; }
        public DbSet<Disponent> Disponents { get; set; }
        public DbSet<Form> Forms { get; set; }
        public DbSet<EmailAttachment> EmailAttachments { get; set; }
        public DbSet<Material> Materials { get; set; }
        public DbSet<Language> Languages { get; set; }
        public DbSet<FormTemplateLocalized_Question> FormTemplateLocalized_Questions { get; set; }
        public DbSet<User> Users { get; set; }
        public DbSet<MaterialBOM> MaterialBOMs { get; set; }
        public DbSet<SupplierDuns> SupplierDuns { get; set; }

        public DbSet<Carrier> Carriers { get; set; }
        public DbSet<CarrierForm> CarrierForms { get; set; }
        public DbSet<CarrierResponse> CarrierResponses { get; set; }
        public DbSet<CarrierFormTemplate> CarrierFormTemplates { get; set; }
        public DbSet<CarrierFormTemplateLocalized> CarrierLocalizedTemplates { get; set; }
        public DbSet<CarrierEmailQueryEntry> CarrierEmailQuery { get; set; }

        public string UserName { get; set; }

        public ERContext() : base("name=EREAD_DB")
        {
        }

        public void SetUser(string userName)
        {
            UserName = userName;
        }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            //modelBuilder.NamesToSnakeCase();
            //modelBuilder.Properties<DateTime>().Configure(c => c.HasColumnType("datetime2"));

            /*modelBuilder.Entity<PID>().HasKey(p => p.Id);
            modelBuilder.Entity<WERK>().HasKey(w => w.Id);*/

            modelBuilder.HasDefaultSchema(ConfigurationManager.AppSettings["DefaultSchema"]);


            modelBuilder.Entity<FormTemplateLocalized>().HasMany(f => f.FormTemplateLocalized_Questions);//.WithMany(q => q.LocalizedFormTemplates);
            modelBuilder.Entity<FormTemplateLocalized>().HasMany(f => f.EmailAttachments).WithMany(e => e.LocalizedTemplates);

            modelBuilder.Entity<Language>().Property(l => l.LangCode).IsRequired();

            modelBuilder.Entity<Form>().HasMany(f => f.Notes).WithRequired(n => n.Form);
            modelBuilder.Entity<Form>().HasRequired(f => f.Project);
            modelBuilder.Entity<Form>().HasIndex(u => u.Code).IsUnique();
            modelBuilder.Entity<Form>().Property(p => p.DateFilled).IsOptional();
            modelBuilder.Entity<Form>().Property(p => p.DateSent).IsOptional();
            modelBuilder.Entity<Form>().HasRequired(p => p.Supplier);
            modelBuilder.Entity<Form>().HasOptional(p => p.Disponent);
            modelBuilder.Entity<Form>().HasMany(f => f.Materials);

            modelBuilder.Entity<Project>().HasRequired(p => p.FormTemplate);
            //modelBuilder.Entity<Project>().HasMany(p => p.Materials);
            modelBuilder.Entity<Project>().Property(p => p.OS).IsOptional();
            modelBuilder.Entity<Project>().Property(p => p.PVS).IsOptional();
            modelBuilder.Entity<Project>().Property(p => p.VFF).IsOptional();

            //modelBuilder.Entity<Supplier>().HasMany(d => d.Projects).WithRequired(p => p.Supplier);

            //modelBuilder.Entity<Disponent>().HasMany(d => d.Projects).WithRequired(p => p.Disponent);

            modelBuilder.Entity<Response>().HasRequired(r => r.Form);
            modelBuilder.Entity<Response>().HasRequired(r => r.Question);

            modelBuilder.Entity<EmailAttachment>().Property(e => e.Data).IsRequired();

            modelBuilder.Entity<Supplier>().HasOptional(s => s.PrefferedLanguage);
            modelBuilder.Entity<Supplier>().HasMany(s => s.SupplierContacts);
            modelBuilder.Entity<Supplier>().HasMany(s => s.DunsCodes);

            modelBuilder.Entity<Disponent>().HasMany(d => d.Languages).WithMany();

            modelBuilder.Entity<EmailQueryEntry>().HasRequired(eq => eq.Form);
            /*modelBuilder.Entity<EmailQueryEntry>().HasRequired(eq => eq.FormTemplate);
            modelBuilder.Entity<EmailQueryEntry>().Property(eq => eq.DateSent).IsOptional();
            modelBuilder.Entity<EmailQueryEntry>().Property(eq => eq.RecipientEmailAdress).IsRequired();*/

            modelBuilder.Entity<Carrier>().HasOptional(s => s.PrefferedLanguage);

            modelBuilder.Entity<CarrierForm>().Property(p => p.DateFilled).IsOptional();
            modelBuilder.Entity<CarrierForm>().Property(p => p.DateSent).IsOptional();
            modelBuilder.Entity<CarrierFormTemplate>().HasMany(g => g.LocalizedTemplates).WithRequired(s => s.CarrierFormTemplate);
            //modelBuilder.Entity<CarrierFormTemplateLocalized>().HasMany(f => f.EmailAttachments).WithMany(e => e.LocalizedTemplates);

            //modelBuilder.Filter("DateDeleted", (ISoftDeleteEntity d) => d.DateDeleted, null);
        }

        public override int SaveChanges()
        {
            var trackedEntities = ChangeTracker.Entries().Where(e => e.Entity is IChangeTrackedEntity && e.State == EntityState.Modified).Select(e => (IChangeTrackedEntity)e.Entity);
            foreach (var te in trackedEntities)
            {
                te.DateModified = DateTime.Now;
                te.UpdatedBy = UserName;
            }

            trackedEntities = ChangeTracker.Entries().Where(e => e.Entity is IChangeTrackedEntity && e.State == EntityState.Added).Select(e => (IChangeTrackedEntity)e.Entity);
            foreach (var te in trackedEntities)
            {
                te.DateCreated = DateTime.Now;
                te.CreatedBy = UserName;
            }

            var sdEntities = ChangeTracker.Entries().Where(e => e.Entity is ISoftDeleteEntity && e.State == EntityState.Deleted);//.Select(e => (ISoftDeleteEntity)e.Entity);
            foreach (var sd in sdEntities)
            {
                SoftDelete(sd);
                /*te.DateModified = DateTime.Now;
                te.UpdatedBy = FM.DataContext.Utils.GetUsername();*/
            }

            return base.SaveChanges();
        }

        private void SoftDelete(DbEntityEntry entry)
        {
            var entryEntityType = entry.Entity.GetType();


            string tableName = GetTableName(entryEntityType);
            string primaryKeyName = GetPrimaryKeyName(entryEntityType);


            //string sql = $"UPDATE {tableName} SET DELETETIME = CURRENT_DATE, DELETEUSER = :deleteusr  WHERE {primaryKeyName} = :id";
            var sql = $"UPDATE {tableName} SET \"DateDeleted\" = now(), \"DeletedBy\" = @deleteusr  WHERE \"{primaryKeyName}\" = @Id";

            var uname = UserName;
            var uparam = new NpgsqlParameter("deleteusr", (String.IsNullOrEmpty(uname)) ? (object)DBNull.Value : uname);
            var idparam = new NpgsqlParameter("Id", entry.OriginalValues[primaryKeyName]);

            Database.ExecuteSqlCommand(
                sql,
                uparam,
                idparam);


            entry.State = EntityState.Detached;
        }

        private string GetTableName(Type type)
        {
            EntitySetBase es = GetEntitySet(type);
            return $"\"{es.MetadataProperties["Schema"].Value}\".\"{es.MetadataProperties["Table"].Value}\"";
        }

        private string GetPrimaryKeyName(Type type)
        {
            EntitySetBase es = GetEntitySet(type);
            return es.ElementType.KeyMembers[0].Name;
        }

        private static readonly Dictionary<Type, EntitySetBase> MappingCache = new Dictionary<Type, EntitySetBase>();

        private EntitySetBase GetEntitySet(Type type)
        {
            if (!MappingCache.ContainsKey(type))
            {
                ObjectContext octx = ((IObjectContextAdapter)this).ObjectContext;
                string typeName = ObjectContext.GetObjectType(type).Name;
                var es = octx.MetadataWorkspace
                    .GetItemCollection(DataSpace.SSpace)
                    .GetItems<EntityContainer>()
                    .SelectMany(c => c.BaseEntitySets
                        .Where(e => e.Name == typeName))
                    .FirstOrDefault();

                if (es == null)
                    throw new ArgumentException("Entity type not found in GetTableName", typeName);

                MappingCache.Add(type, es);
            }



            return MappingCache[type];
        }

        public CarrierForm CreateCarrierForm(Carrier carrier)
        {
            var carrierForm = new CarrierForm()
            {
                Carrier = carrier,
                FormState = FormState.Ready
            };
            CarrierForms.Add(carrierForm);
            return carrierForm;
        }
    }
}