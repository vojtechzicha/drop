namespace eReadiness.DataContext
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class PGInit : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "public.Disponents",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        DispoCode = c.String(),
                        Name = c.String(),
                        DeletedBy = c.String(),
                        DateDeleted = c.DateTime(),
                        DateCreated = c.DateTime(nullable: false),
                        DateModified = c.DateTime(nullable: false),
                        CreatedBy = c.String(),
                        UpdatedBy = c.String(),
                    })
                .PrimaryKey(t => t.Id);
            
            CreateTable(
                "public.EmailAttachments",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        Data = c.Binary(nullable: false),
                        FileName = c.String(),
                        DeletedBy = c.String(),
                        DateDeleted = c.DateTime(),
                        DateCreated = c.DateTime(nullable: false),
                        DateModified = c.DateTime(nullable: false),
                        CreatedBy = c.String(),
                        UpdatedBy = c.String(),
                    })
                .PrimaryKey(t => t.Id);
            
            CreateTable(
                "public.FormTemplateLocalizeds",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        MailSubject = c.String(),
                        MailBody = c.String(),
                        MailBodyUrgent = c.String(),
                        DeletedBy = c.String(),
                        DateDeleted = c.DateTime(),
                        DateCreated = c.DateTime(nullable: false),
                        DateModified = c.DateTime(nullable: false),
                        CreatedBy = c.String(),
                        UpdatedBy = c.String(),
                        Language_Id = c.Int(),
                        ParentTemplate_Id = c.Int(),
                    })
                .PrimaryKey(t => t.Id)
                .ForeignKey("public.Languages", t => t.Language_Id)
                .ForeignKey("public.FormTemplates", t => t.ParentTemplate_Id)
                .Index(t => t.Language_Id)
                .Index(t => t.ParentTemplate_Id);
            
            CreateTable(
                "public.FormTemplateLocalized_Question",
                c => new
                    {
                        FormTemplateLocalizedID = c.Int(nullable: false),
                        QuestionID = c.Int(nullable: false),
                        QuestionOrder = c.Int(nullable: false),
                    })
                .PrimaryKey(t => new { t.FormTemplateLocalizedID, t.QuestionID })
                .ForeignKey("public.Questions", t => t.QuestionID, cascadeDelete: true)
                .ForeignKey("public.FormTemplateLocalizeds", t => t.FormTemplateLocalizedID, cascadeDelete: true)
                .Index(t => t.FormTemplateLocalizedID)
                .Index(t => t.QuestionID);
            
            CreateTable(
                "public.Questions",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        QuestionText = c.String(),
                        ShowInReport = c.Boolean(nullable: false),
                        DeletedBy = c.String(),
                        DateDeleted = c.DateTime(),
                        DateCreated = c.DateTime(nullable: false),
                        DateModified = c.DateTime(nullable: false),
                        CreatedBy = c.String(),
                        UpdatedBy = c.String(),
                    })
                .PrimaryKey(t => t.Id);
            
            CreateTable(
                "public.Languages",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        LangCode = c.String(nullable: false),
                        DeletedBy = c.String(),
                        DateDeleted = c.DateTime(),
                        DateCreated = c.DateTime(nullable: false),
                        DateModified = c.DateTime(nullable: false),
                        CreatedBy = c.String(),
                        UpdatedBy = c.String(),
                    })
                .PrimaryKey(t => t.Id);
            
            CreateTable(
                "public.FormTemplates",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        TemplateName = c.String(),
                        DeletedBy = c.String(),
                        DateDeleted = c.DateTime(),
                        DateCreated = c.DateTime(nullable: false),
                        DateModified = c.DateTime(nullable: false),
                        CreatedBy = c.String(),
                        UpdatedBy = c.String(),
                    })
                .PrimaryKey(t => t.Id);
            
            CreateTable(
                "public.Forms",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        Code = c.String(maxLength: 100),
                        DateSent = c.DateTime(),
                        DateFilled = c.DateTime(),
                        Completition = c.Int(nullable: false),
                        FormState = c.Int(nullable: false),
                        MilestoneType = c.Int(nullable: false),
                        DeletedBy = c.String(),
                        DateDeleted = c.DateTime(),
                        DateCreated = c.DateTime(nullable: false),
                        DateModified = c.DateTime(nullable: false),
                        CreatedBy = c.String(),
                        UpdatedBy = c.String(),
                        Disponent_Id = c.Int(),
                        Project_Id = c.Int(nullable: false),
                        Supplier_Id = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.Id)
                .ForeignKey("public.Disponents", t => t.Disponent_Id)
                .ForeignKey("public.Projects", t => t.Project_Id, cascadeDelete: true)
                .ForeignKey("public.Suppliers", t => t.Supplier_Id, cascadeDelete: true)
                .Index(t => t.Code, unique: true)
                .Index(t => t.Disponent_Id)
                .Index(t => t.Project_Id)
                .Index(t => t.Supplier_Id);
            
            CreateTable(
                "public.Materials",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        Number = c.String(maxLength: 20),
                        ManualAdded = c.Boolean(nullable: false),
                        ManualDeleted = c.Boolean(nullable: false),
                        DeletedBy = c.String(),
                        DateDeleted = c.DateTime(),
                        DateCreated = c.DateTime(nullable: false),
                        DateModified = c.DateTime(nullable: false),
                        CreatedBy = c.String(),
                        UpdatedBy = c.String(),
                        Form_Id = c.Int(),
                    })
                .PrimaryKey(t => t.Id)
                .ForeignKey("public.Forms", t => t.Form_Id)
                .Index(t => t.Form_Id);
            
            CreateTable(
                "public.Notes",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        NoteText = c.String(),
                        DeletedBy = c.String(),
                        DateDeleted = c.DateTime(),
                        DateCreated = c.DateTime(nullable: false),
                        DateModified = c.DateTime(nullable: false),
                        CreatedBy = c.String(),
                        UpdatedBy = c.String(),
                        Form_Id = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.Id)
                .ForeignKey("public.Forms", t => t.Form_Id, cascadeDelete: true)
                .Index(t => t.Form_Id);
            
            CreateTable(
                "public.Projects",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        Name = c.String(),
                        SOP = c.DateTime(nullable: false),
                        PVS = c.DateTime(),
                        VFF = c.DateTime(),
                        OS = c.DateTime(),
                        DeletedBy = c.String(),
                        DateDeleted = c.DateTime(),
                        DateCreated = c.DateTime(nullable: false),
                        DateModified = c.DateTime(nullable: false),
                        CreatedBy = c.String(),
                        UpdatedBy = c.String(),
                        FormTemplate_Id = c.Int(nullable: false),
                        PID_Id = c.Int(),
                        WERK_Id = c.Int(),
                    })
                .PrimaryKey(t => t.Id)
                .ForeignKey("public.FormTemplates", t => t.FormTemplate_Id, cascadeDelete: true)
                .ForeignKey("public.PIDs", t => t.PID_Id)
                .ForeignKey("public.WERKs", t => t.WERK_Id)
                .Index(t => t.FormTemplate_Id)
                .Index(t => t.PID_Id)
                .Index(t => t.WERK_Id);
            
            CreateTable(
                "public.PIDs",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        ProjectCode = c.String(),
                        Name = c.String(),
                        DeletedBy = c.String(),
                        DateDeleted = c.DateTime(),
                        DateCreated = c.DateTime(nullable: false),
                        DateModified = c.DateTime(nullable: false),
                        CreatedBy = c.String(),
                        UpdatedBy = c.String(),
                    })
                .PrimaryKey(t => t.Id);
            
            CreateTable(
                "public.WERKs",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        WerkCode = c.String(),
                        Name = c.String(),
                        DeletedBy = c.String(),
                        DateDeleted = c.DateTime(),
                        DateCreated = c.DateTime(nullable: false),
                        DateModified = c.DateTime(nullable: false),
                        CreatedBy = c.String(),
                        UpdatedBy = c.String(),
                    })
                .PrimaryKey(t => t.Id);
            
            CreateTable(
                "public.Suppliers",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        DunsCode = c.String(),
                        Name = c.String(),
                        Email = c.String(),
                        DeletedBy = c.String(),
                        DateDeleted = c.DateTime(),
                        DateCreated = c.DateTime(nullable: false),
                        DateModified = c.DateTime(nullable: false),
                        CreatedBy = c.String(),
                        UpdatedBy = c.String(),
                        PrefferedLanguage_Id = c.Int(),
                    })
                .PrimaryKey(t => t.Id)
                .ForeignKey("public.Languages", t => t.PrefferedLanguage_Id)
                .Index(t => t.PrefferedLanguage_Id);
            
            CreateTable(
                "public.Responses",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        ResponseValue = c.Boolean(nullable: false),
                        ResponseReason = c.String(),
                        DeletedBy = c.String(),
                        DateDeleted = c.DateTime(),
                        DateCreated = c.DateTime(nullable: false),
                        DateModified = c.DateTime(nullable: false),
                        CreatedBy = c.String(),
                        UpdatedBy = c.String(),
                        Form_Id = c.Int(nullable: false),
                        Question_Id = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.Id)
                .ForeignKey("public.Forms", t => t.Form_Id, cascadeDelete: true)
                .ForeignKey("public.Questions", t => t.Question_Id, cascadeDelete: true)
                .Index(t => t.Form_Id)
                .Index(t => t.Question_Id);
            
            CreateTable(
                "public.FormTemplateLocalizedEmailAttachments",
                c => new
                    {
                        FormTemplateLocalized_Id = c.Int(nullable: false),
                        EmailAttachment_Id = c.Int(nullable: false),
                    })
                .PrimaryKey(t => new { t.FormTemplateLocalized_Id, t.EmailAttachment_Id })
                .ForeignKey("public.FormTemplateLocalizeds", t => t.FormTemplateLocalized_Id, cascadeDelete: true)
                .ForeignKey("public.EmailAttachments", t => t.EmailAttachment_Id, cascadeDelete: true)
                .Index(t => t.FormTemplateLocalized_Id)
                .Index(t => t.EmailAttachment_Id);
            
        }
        
        public override void Down()
        {
            DropForeignKey("public.Responses", "Question_Id", "public.Questions");
            DropForeignKey("public.Responses", "Form_Id", "public.Forms");
            DropForeignKey("public.Forms", "Supplier_Id", "public.Suppliers");
            DropForeignKey("public.Suppliers", "PrefferedLanguage_Id", "public.Languages");
            DropForeignKey("public.Forms", "Project_Id", "public.Projects");
            DropForeignKey("public.Projects", "WERK_Id", "public.WERKs");
            DropForeignKey("public.Projects", "PID_Id", "public.PIDs");
            DropForeignKey("public.Projects", "FormTemplate_Id", "public.FormTemplates");
            DropForeignKey("public.Notes", "Form_Id", "public.Forms");
            DropForeignKey("public.Materials", "Form_Id", "public.Forms");
            DropForeignKey("public.Forms", "Disponent_Id", "public.Disponents");
            DropForeignKey("public.FormTemplateLocalizeds", "ParentTemplate_Id", "public.FormTemplates");
            DropForeignKey("public.FormTemplateLocalizeds", "Language_Id", "public.Languages");
            DropForeignKey("public.FormTemplateLocalized_Question", "FormTemplateLocalizedID", "public.FormTemplateLocalizeds");
            DropForeignKey("public.FormTemplateLocalized_Question", "QuestionID", "public.Questions");
            DropForeignKey("public.FormTemplateLocalizedEmailAttachments", "EmailAttachment_Id", "public.EmailAttachments");
            DropForeignKey("public.FormTemplateLocalizedEmailAttachments", "FormTemplateLocalized_Id", "public.FormTemplateLocalizeds");
            DropIndex("public.FormTemplateLocalizedEmailAttachments", new[] { "EmailAttachment_Id" });
            DropIndex("public.FormTemplateLocalizedEmailAttachments", new[] { "FormTemplateLocalized_Id" });
            DropIndex("public.Responses", new[] { "Question_Id" });
            DropIndex("public.Responses", new[] { "Form_Id" });
            DropIndex("public.Suppliers", new[] { "PrefferedLanguage_Id" });
            DropIndex("public.Projects", new[] { "WERK_Id" });
            DropIndex("public.Projects", new[] { "PID_Id" });
            DropIndex("public.Projects", new[] { "FormTemplate_Id" });
            DropIndex("public.Notes", new[] { "Form_Id" });
            DropIndex("public.Materials", new[] { "Form_Id" });
            DropIndex("public.Forms", new[] { "Supplier_Id" });
            DropIndex("public.Forms", new[] { "Project_Id" });
            DropIndex("public.Forms", new[] { "Disponent_Id" });
            DropIndex("public.Forms", new[] { "Code" });
            DropIndex("public.FormTemplateLocalized_Question", new[] { "QuestionID" });
            DropIndex("public.FormTemplateLocalized_Question", new[] { "FormTemplateLocalizedID" });
            DropIndex("public.FormTemplateLocalizeds", new[] { "ParentTemplate_Id" });
            DropIndex("public.FormTemplateLocalizeds", new[] { "Language_Id" });
            DropTable("public.FormTemplateLocalizedEmailAttachments");
            DropTable("public.Responses");
            DropTable("public.Suppliers");
            DropTable("public.WERKs");
            DropTable("public.PIDs");
            DropTable("public.Projects");
            DropTable("public.Notes");
            DropTable("public.Materials");
            DropTable("public.Forms");
            DropTable("public.FormTemplates");
            DropTable("public.Languages");
            DropTable("public.Questions");
            DropTable("public.FormTemplateLocalized_Question");
            DropTable("public.FormTemplateLocalizeds");
            DropTable("public.EmailAttachments");
            DropTable("public.Disponents");
        }
    }
}
