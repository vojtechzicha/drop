﻿using System.Text.RegularExpressions;

namespace eReadiness.Utils
{
    public static class HtmlSanitizer
    {
        public static string RemoveScripts(string HTML)
        {
            if (string.IsNullOrEmpty(HTML))
                return HTML;
            string Pat = "<(script)\\b[^>]*?>.*?</\\1>";
            return Regex.Replace(HTML, Pat, "", RegexOptions.IgnoreCase | RegexOptions.Singleline);
        }

        /*
        private static readonly List<byte[]> SPECIAL_TAGS = new List<byte[]>
                                                            {
                                                                Encoding.ASCII.GetBytes("script"),
                                                                Encoding.ASCII.GetBytes("style"),
                                                                Encoding.ASCII.GetBytes("noscript")
                                                            };

        private static readonly List<byte[]> SPECIAL_TAGS_CLOSE = new List<byte[]>
                                                                  {
                                                                      Encoding.ASCII.GetBytes("/script"),
                                                                      Encoding.ASCII.GetBytes("/style"),
                                                                      Encoding.ASCII.GetBytes("/noscript")};

        public static string StripTagsCharArray(string source, bool toLowerCase)
        {
            var array = new char[source.Length];
            var arrayIndex = 0;
            var inside = false;
            var haveSpecialTags = false;
            var compareIndex = -1;
            var singleQouteMode = false;
            var doubleQouteMode = false;
            var matchMemory = SetDefaultMemory(SPECIAL_TAGS);
            for (int i = 0; i < source.Length; i++)
            {
                var let = source[i];
                if (inside && !singleQouteMode && !doubleQouteMode)
                {
                    compareIndex++;
                    if (haveSpecialTags)
                    {
                        var endTag = CheckSpecialTags(let, compareIndex, SPECIAL_TAGS_CLOSE, ref matchMemory);
                        if (endTag) haveSpecialTags = false;
                    }
                    if (!haveSpecialTags)
                    {
                        haveSpecialTags = CheckSpecialTags(let, compareIndex, SPECIAL_TAGS, ref matchMemory);
                    }
                }
                if (haveSpecialTags && let == '"')
                {
                    doubleQouteMode = !doubleQouteMode;
                }
                if (haveSpecialTags && let == '\'')
                {
                    singleQouteMode = !singleQouteMode;
                }
                if (let == '<')
                {
                    matchMemory = SetDefaultMemory(SPECIAL_TAGS);
                    compareIndex = -1;
                    inside = true;
                    continue;
                }
                if (let == '>')
                {
                    inside = false;
                    continue;
                }
                if (inside) continue;
                if (char.IsDigit(let)) continue;
                if (haveSpecialTags) continue;
                array[arrayIndex] = toLowerCase ? Char.ToLowerInvariant(let) : let;
                arrayIndex++;
            }
            return new string(array, 0, arrayIndex);
        }

        private static bool[] SetDefaultMemory(List<byte[]> specialTags)
        {
            var memory = new bool[specialTags.Count];
            for (int i = 0; i < memory.Length; i++)
            {
                memory[i] = true;
            }
            return memory;
        }
        */
        /*
        public string Process(string source)
        {
            var nodeWhiteList =  new string[] { };
            var attributeWhiteList =  new string[] { };

            HtmlDocument html = GetHtml(source);

            if (html == null)
            {
                return String.Empty;
            }

            // All the nodes
            HtmlNode allNodes = html.DocumentNode;

            // Scrub tags not in attributeWhitelist
            CleanNodes(allNodes, nodeWhiteList, attributeWhiteList);

            var ret = allNodes.InnerHtml;
            ret = HtmlEntity.DeEntitize(ret);

            return ret;
        }

        /// <summary>
        /// Recursively delete nodes not in the attributeWhitelist
        /// </summary>
        private HtmlNode CleanNodes(HtmlNode node, string[] nodeWhitelist, string[] attributeWhitelist)
        {
            if (SkipNode(node))
            {
                var nextNode = node.NextSibling;
                node.ParentNode.RemoveChild(node);

                return nextNode;
            }

            if (node.HasChildNodes)
            {
                var childNode = node.FirstChild;
                while (childNode != null)
                {
                    childNode = CleanNodes(childNode, nodeWhitelist, attributeWhitelist);
                }
            }

            if (node.NodeType == HtmlNodeType.Element)
            {
                var attribs = node.Attributes.ToList();
                foreach (var attrib in attribs)
                {
                    if (!attributeWhitelist.Contains(attrib.Name))
                    {
                        node.Attributes.Remove(attrib);
                    }
                }

                if (!nodeWhitelist.Contains(node.Name))
                {
                    var nodeList = node.ChildNodes.ToList();
                    foreach (var child in nodeList)
                    {
                        node.ParentNode.InsertBefore(child, node);
                    }

                    var nextNode = node.NextSibling;
                    node.ParentNode.RemoveChild(node);

                    return nextNode;
                }
            }

            return node.NextSibling;
        }

        private bool SkipNode(HtmlNode node)
        {
            if (node.NodeType == HtmlNodeType.Comment)
            {
                return true;
            }

            if (node.Name == "script" || node.Name == "style")
            {
                return true;
            }

            if (node.NodeType == HtmlNodeType.Text && String.IsNullOrWhiteSpace(node.InnerText))
            {
                return true;
            }

            return false;
        }

        /// <summary>
        /// Helper function that returns an HTML document from text
        /// </summary>
        private HtmlDocument GetHtml(string source)
        {
            HtmlDocument html = new HtmlDocument();
            html.OptionFixNestedTags = true;
            html.OptionAutoCloseOnEnd = true;
            html.OptionDefaultStreamEncoding = Encoding.UTF8;
            html.OptionWriteEmptyNodes = true;
            html.OptionOutputAsXml = true;

            html.LoadHtml(source);

            return html;
        }
        */
    }
}