﻿namespace eReadiness.Utils
{
    public enum FilterResultMode
    {
        Sent,
        NotReturned,
        ReturnedOK,
        NotSent,
        Returned,
        WithoutDisponent,
        Responses
    }

    public enum MaterialResultMode
    {
        MissingSupplier,
        WithSupplier,
        TotalParts,
        BRelease,
        Fakom
    }
}