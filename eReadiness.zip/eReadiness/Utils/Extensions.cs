﻿using eReadiness.DataContext.Models;
using eReadiness.DataContext.Models.Abstracts;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Linq.Expressions;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Threading;
using System.Web;

namespace eReadiness.Utils
{
    public static class KTExtensions
    {
        public static Func<DateTime, string> KTLambda = (s =>
        {
            var ci = new CultureInfo("cs-CZ");
            return ci.Calendar.GetWeekOfYear(s,
                    ci.DateTimeFormat.CalendarWeekRule,
                    ci.DateTimeFormat.FirstDayOfWeek) + "/" + s.Year.ToString().Substring(2);
        });

        public static string ToKT(this DateTime? arg)
        {
            if (!arg.HasValue)
                return string.Empty;
            return KTLambda(arg.Value);
        }

        public static string ToKT(this DateTime arg) => KTLambda(arg);

        public static DateTime? FromKT(this string kt)
        {
            if (String.IsNullOrEmpty(kt))
                return null;
            try
            {
                var split = kt.Split('/', '-');
                var weekOfYear = Int32.Parse(split[0]);
                var year = Int32.Parse(split[1]);
                if (year < 2000)
                    year += 2000;

                DateTime jan1 = new DateTime(year, 1, 1);
                int daysOffset = DayOfWeek.Thursday - jan1.DayOfWeek;

                // Use first Thursday in January to get first week of the year as
                // it will never be in Week 52/53
                DateTime firstThursday = jan1.AddDays(daysOffset);
                var cal = CultureInfo.CurrentCulture.Calendar;
                int firstWeek = cal.GetWeekOfYear(firstThursday, CalendarWeekRule.FirstFourDayWeek, DayOfWeek.Monday);

                var weekNum = weekOfYear;
                // As we're adding days to a date in Week 1,
                // we need to subtract 1 in order to get the right date for week #1
                if (firstWeek == 1)
                {
                    weekNum -= 1;
                }

                // Using the first Thursday as starting week ensures that we are starting in the right year
                // then we add number of weeks multiplied with days
                var result = firstThursday.AddDays(weekNum * 7);

                // Subtract 3 days from Thursday to get Monday, which is the first weekday in ISO8601
                return result.AddDays(-3);
            }
            catch (Exception e)
            {
                throw new KTParseException("KT from DateTime parse Failed!", e);
            }
        }

        public static string ReplacePlaceholdersWithProjectValues(this string source, Project project)
        {
            if (project == null)
                return source;

            source = source
                .Replace("{PROJEKT}", project.Name)
                .Replace("{VFF}", project.VFF.ToKT())
                .Replace("{PVS}", project.PVS.ToKT())
                .Replace("{0S}", project.OS.ToKT())
                .Replace("{SOP}", KTLambda(project.SOP));

            return source;
        }
    }

    public static class CollectionsExtensions
    {
        public static IEnumerable<TSource> DistinctBy<TSource, TKey>(this IEnumerable<TSource> source, Func<TSource, TKey> keySelector)
        {
            HashSet<TKey> seenKeys = new HashSet<TKey>();
            foreach (TSource element in source)
            {
                if (seenKeys.Add(keySelector(element)))
                {
                    yield return element;
                }
            }
        }

        public static void AddRange<TSource>(this ICollection<TSource> origin, IEnumerable<TSource> toAdd)
        {
            foreach (var v in toAdd)
            {
                origin.Add(v);
            }
        }

        /*public static void RemoveRange<TSource>(this ICollection<TSource> origin, IEnumerable<TSource> toRemove)
        {
            foreach (var v in toRemove)
            {
                origin.Remove(v);
            }
        }*/

        public static void ForEach<T>(this IEnumerable<T> source, Action<T> action)
        {
            if (source == null)
                throw new Exception("Source null");

            if (action == null)
                throw new Exception("Action null");

            foreach (T element in source)
            {
                action(element);
            }
        }

        public static IQueryable<T> NotRemoved<T>(this IEnumerable<T> source) where T : ISoftDeleteEntity
        {
            return source.SoftWhere(s => true);
        }

        public static IQueryable<T> SoftWhere<T>(this IEnumerable<T> source, Expression<Func<T, bool>> predicate) where T : ISoftDeleteEntity
        {
            Expression<Func<T, bool>> newPred = s => s.DateDeleted == null;
            predicate = Expression.Lambda<Func<T, bool>>(Expression.AndAlso(predicate.Body, newPred.Body), newPred.Parameters);
            return source.AsQueryable().Where(predicate);
        }
    }

    public static class Extensions
    {
        public static byte[] ReadStream(Stream input)
        {
            byte[] buffer = new byte[16 * 1024];
            using (MemoryStream ms = new MemoryStream())
            {
                int read;
                while ((read = input.Read(buffer, 0, buffer.Length)) > 0)
                {
                    ms.Write(buffer, 0, read);
                }
                return ms.ToArray();
            }
        }

        public static string GetUsername()
        {
            try
            {
                var oClaimsPrincipal = (ClaimsPrincipal)Thread.CurrentPrincipal;
                return oClaimsPrincipal.Claims.Where(x => x.Type.StartsWith(((ClaimsIdentity)oClaimsPrincipal.Identity).NameClaimType)).Select(x => x.Value).FirstOrDefault();
            }
            catch { return ""; }
        }
    }

    public class KTParseException : Exception
    {
        public KTParseException(string message, Exception inner) : base(message, inner)
        { }
    }


}