﻿using System;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using eReadiness.App_GlobalResources;
using eReadiness.Models;
//using NLog;

namespace eReadiness.Security
{
    [AttributeUsage(AttributeTargets.All)]
    public class SecurityRoleAuthorizeAttribute : AuthorizeAttribute
    {
        //private static Logger Log = LogManager.GetCurrentClassLogger();

        private readonly SecurityRole[] _securityRoles;

        public SecurityRoleAuthorizeAttribute(params SecurityRole[] roles)
        {
            _securityRoles = roles;
            Roles = string.Join(",", roles.Select(SecurityRoleHelper.GetRoleName));
        }

        protected override bool AuthorizeCore(HttpContextBase httpContext)
        {
            bool isAuthorized = false;
            if (string.IsNullOrEmpty(httpContext.User.Identity.AuthenticationType))
            {
                isAuthorized = httpContext.User.IsInAnyRole(_securityRoles);
            }
            else
                try
                {
                    isAuthorized = base.AuthorizeCore(httpContext);
                }
                catch (Exception ex)
                {
                    //Log.Error(ex);
#if DEBUG
                    isAuthorized = true; // Overide for offline testing
#endif
                }
            return isAuthorized;
        }

        protected override void HandleUnauthorizedRequest(AuthorizationContext filterContext)
        {
            if (!string.IsNullOrEmpty(filterContext.HttpContext.User.Identity.AuthenticationType) && !filterContext.HttpContext.User.Identity.IsAuthenticated)
            {
                base.HandleUnauthorizedRequest(filterContext);
            }
            else
            {
                string[] acceptedTypes = filterContext.HttpContext.Request.AcceptTypes;
                if (acceptedTypes != null)
                {
                    foreach (string type in acceptedTypes)
                    {
                        if (type.Contains("html"))
                        {
                            //filterContext.Result = new RedirectToRouteResult(
                            //    new RouteValueDictionary
                            //    {
                            //        { "action", "Index" },
                            //        { "controller", "Home" }
                            //    });

                            var error = new ErrorViewModel
                            {
                                Code = 403,
                                Title = GlobalRes.AccessDenied_Title,
                                Description = GlobalRes.AccessDenied_Description
                            };
                            if (filterContext.HttpContext.Request.IsAjaxRequest())
                                filterContext.Result = new PartialViewResult
                                {
                                    ViewName = "~/Views/Shared/ErrorPartial.cshtml",
                                    ViewData = new ViewDataDictionary(filterContext.Controller.ViewData)
                                    {
                                        Model = error
                                    }
                                };
                            else
                            {
                                var result = new ViewResult
                                {
                                    ViewName = "~/Views/Shared/Error.cshtml",
                                    ViewData = new ViewDataDictionary(filterContext.Controller.ViewData)
                                    {
                                        Model = error
                                    }
                                };
                                filterContext.Result = result;
                            }

                            break;
                        }

                        if (type.Contains("javascript"))
                        {
                            filterContext.Result = new JsonResult { Data = new { success = false, message = "Access denied." } };
                            break;
                        }

                        if (type.Contains("xml"))
                        {
                            filterContext.Result = new HttpUnauthorizedResult();
                        }
                    }
                }
            }
        }

    }
}