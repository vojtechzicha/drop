﻿using System;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace eReadiness.Security
{
    [AttributeUsage(AttributeTargets.Class | AttributeTargets.Method)]
    public class SecurityInitAttribute : AuthorizeAttribute
    {
        public ILDAPWSService LDAP { get; set; }

        public SecurityInitAttribute()
        {
            LDAP = new B2BUserRepositoryService();
        }

        public override void OnAuthorization(AuthorizationContext filterContext)
        {
            var context = filterContext.HttpContext;
            if (context.Session["User"] == null)
            {
                var user = context.User.Identity.Name;
                var webSealHeaderUser = ConfigurationManager.AppSettings["Security_WebSeal_Header"];
                if (!string.IsNullOrEmpty(webSealHeaderUser) && !string.IsNullOrEmpty(context.Request.Headers[webSealHeaderUser]))
                    user = context.Request.Headers[webSealHeaderUser];
                context.Session["User"] = user;

                if (LDAP != null && LDAP.IsConfigured)
                {
                    var roles = LDAP.RequestRoles(user);
                    context.Session["UserRoles"] = roles;

                    var userInfo = LDAP.RequestUserInfo(user);
                    if (userInfo != null)
                    {
                        context.Session["User"] = userInfo.ID;
                        context.Session["UserName"] = userInfo.FullName;
                        //if (HttpContext.Current.IsDebuggingEnabled)
                        //    context.Session["UserName"] = userInfo.FullName + " / " + (roles.Any() ? roles.Aggregate((current, next) => current + ", " + next) : "NO ROLES");
                    }
                }
            }
            base.OnAuthorization(filterContext);
        }

        protected override bool AuthorizeCore(HttpContextBase httpContext)
        {
            return true;
        }
    }
}