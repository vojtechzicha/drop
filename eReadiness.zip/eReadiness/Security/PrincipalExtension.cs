﻿using NLog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Principal;
using System.Web;

namespace eReadiness.Security
{
    public static class PrincipalExtension
    {
        private static Logger Log = LogManager.GetCurrentClassLogger();
        public static bool IsInAnyRole(this IPrincipal principal, IList<SecurityRole> roles)
        {
            if (roles == null || !roles.Any())
                return false;
            return IsInAnyRole(principal, roles.ToArray());
        }

        public static bool IsInAnyRole(this IPrincipal principal, params SecurityRole[] roles)
        {
            if (roles == null || roles.Length==0) return false;

            return roles.Any(principal.IsInRole);
        }

        public static bool IsInRole(this IPrincipal principal, SecurityRole role)
        {
            try
            {
                string roleName = SecurityRoleHelper.GetRoleName(role);
                if (roleName == null) return false;

                if (HttpContext.Current.Session["UserRoles"] is IEnumerable<string>)
                {
                    var userRoles = HttpContext.Current.Session["UserRoles"] as IEnumerable<string>;
                    foreach (var r in roleName.Split(','))
                        if (userRoles.Contains(r)) return true;
                }

                foreach (var r in roleName.Split(','))
                    if (principal.IsInRole(r)) return true;
                return false;
            }
            catch (Exception ex)
            {
                Log.Error(ex);
            }
            return false;
        }

        public static List<SecurityRole> GrantedRoles(this IPrincipal principal)
        {
            // Debug authorization
            var grantedRoles = new List<SecurityRole>();
            foreach (var role in SecurityRole.GetValues(typeof(SecurityRole)).Cast<SecurityRole>())
            {
                try
                {
                    //windows 
                    if (principal.IsInRole(SecurityRoleHelper.GetRoleName(role)))
                    {
                        grantedRoles.Add(role);
                    }
                }
                catch (Exception ex)
                {
                    Log.Error(ex);
                }
            }

            return grantedRoles;
        }

        public static string GetUserName(this IPrincipal principal)
        {
            var session = HttpContext.Current.Session;
            if (session["UserName"] != null)
                return session["UserName"].ToString();

            string userName = session["User"] as string ?? principal.Identity.Name;
            if (!string.IsNullOrEmpty(userName))
            {
                session["UserName"] = userName;
            }
            return userName;
        }
    }
}