﻿using System.Collections.Generic;
using System.Configuration;
using System.Linq;

namespace eReadiness.Security
{
    public enum SecurityRole
    {
        /// <summary>
        /// Dodavatel
        /// </summary>
        Supplier,
        /// <summary>
        /// Disponent
        /// </summary>
        Disponent,
        /// <summary>
        /// Projektovy manager
        /// </summary>
        ProjectManager,
        /// <summary>
        /// Škotrans specialista
        /// </summary>
        STSpecialist,
        /// <summary>
        /// Škotrans projektový manager
        /// </summary>
        STManager,   
        /// <summary>
        /// Škotrans dopravce
        /// </summary>
        STCarrier    
    }
  
    public class SecurityRoleHelper
    {
        private static readonly Dictionary<SecurityRole, string> SecurityRoleDictionary = new Dictionary<SecurityRole, string>
        {
            {SecurityRole.Supplier,    ConfigurationManager.AppSettings["Security_Group_Supplier"]},
            {SecurityRole.Disponent,             ConfigurationManager.AppSettings["Security_Group_Disponent"]},
            {SecurityRole.ProjectManager,    ConfigurationManager.AppSettings["Security_Group_Manager"]},
            {SecurityRole.STSpecialist,    ConfigurationManager.AppSettings["Security_Group_STSpecialist"]},
            {SecurityRole.STManager,    ConfigurationManager.AppSettings["Security_Group_STManager"]},
            {SecurityRole.STCarrier,    ConfigurationManager.AppSettings["Security_Group_STCarrier"]},
        };

        public static string GetRoleName(SecurityRole role)
        {
            return SecurityRoleDictionary.ContainsKey(role) ? SecurityRoleDictionary[role] : null;
        }

        public static SecurityRole GetSecurityRoleFromName(string role)
        {
            role = role.ToUpper();
            var record = SecurityRoleDictionary.FirstOrDefault(item => item.Value.ToUpper().Equals(role));
            return record.Value != null ? record.Key : SecurityRole.Supplier;
        }

    }
}