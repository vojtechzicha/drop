﻿using eReadiness.B2BUserRepository;
using eReadiness.DataContext;
using Newtonsoft.Json;
using NLog;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Net;
using System.Security.Cryptography.X509Certificates;
using System.ServiceModel;

namespace eReadiness.Security
{
    public class LDAPUserInfo
    {
        public string ID { get; set; }
        public string Name { get; set; }
        public string Surname { get; set; }
        public string Phone { get; set; }
        public string EMail { get; set; }
        public string Department { get; set; }
        public string PrefLang { get; set; }
        public string RoomNumber { get; set; }
        public string Title { get; set; }
        public string PersonalNumber { get; set; }

        public string FullName
        {
            get { return $"{Surname ?? ""} {Name ?? ""} ({ID ?? "???"})"; }
        }

        public string DecodedPersonalNumber
        {
            get
            {
                if (PersonalNumber.Length == 8)
                    return PersonalNumber.TrimStart('0');
                //decode hex ???
                return PersonalNumber;
            }
        }
    }

    public interface ILDAPWSService
    {
        bool IsConfigured { get; }
        List<string> RequestRoles(string userName);
        LDAPUserInfo RequestUserInfo(string userName);
    }

    public class B2BUserRepositoryService : ILDAPWSService
    {
        private static Logger Log = LogManager.GetCurrentClassLogger();

        private ERContext DbContext = new ERContext();

        public string Security_B2BUserRepo_CertificateThumbprint { get; set; }
        public string B2BUserRepo_AppName { get; set; }

        public bool IsConfigured
        {
            get { return !string.IsNullOrEmpty(Security_B2BUserRepo_CertificateThumbprint) && !string.IsNullOrEmpty(B2BUserRepo_AppName); }
        }
        public bool Debug { get; set; }

        public B2BUserRepositoryService()
        {
            Security_B2BUserRepo_CertificateThumbprint = ConfigurationManager.AppSettings["Security_B2BUserRepo_CertificateThumbprint"];
            B2BUserRepo_AppName = ConfigurationManager.AppSettings["Security_B2BUserRepo_AppName"];

            ServicePointManager.ServerCertificateValidationCallback = delegate { return true; };
        }

        public List<string> RequestRoles(string userName)
        {
            var roles = new List<string>();

            var fakeRoles = ConfigurationManager.AppSettings["Security_FakeRoles"];
            if (!string.IsNullOrEmpty(fakeRoles))
            {
                roles.AddRange(fakeRoles.Split(','));
                Log.Debug($"Fake roles for user '{userName}': '{fakeRoles}'.");
                return roles;
            }

            var user = DbContext.Users.Find(userName);
            if(user != null)
            {
                Log.Debug($"Db roles for user '{userName}': '{user.Roles}'.");
                roles.AddRange(user.Roles.Split(','));
                return roles;
            }

            if (!IsConfigured)
            {
                if (Debug) throw new InvalidOperationException("B2BUserRepository not configured");
                return null;
            }
            if (string.IsNullOrEmpty(userName))
            {
                if (Debug) throw new ArgumentNullException(nameof(userName), "UserName empty");
                return null;
            }

            Log.Debug($"Requesting roles from B2BUserRepository WS {userName}");
            try
            {
                organizationType organization;
                applicationType application;
                organizationType[] mandants;
                positionAssignmentsType positionAssignments;
                var b2BUserRepositoryClient = new B2BUserRepositoryClient();
                b2BUserRepositoryClient.ClientCredentials.ClientCertificate.SetCertificate(StoreLocation.LocalMachine, StoreName.My, X509FindType.FindByThumbprint, Security_B2BUserRepo_CertificateThumbprint);
                ((BasicHttpBinding)b2BUserRepositoryClient.Endpoint.Binding).Security.Mode = BasicHttpSecurityMode.Transport;
                ((BasicHttpBinding)b2BUserRepositoryClient.Endpoint.Binding).Security.Transport.ClientCredentialType = HttpClientCredentialType.Certificate;
                var result = b2BUserRepositoryClient.getUserInfo(userName, B2BUserRepo_AppName, out organization, out application, out mandants, out positionAssignments);
                if (application != null)
                {
                    foreach (var group in application.Group)
                    {
                        roles.Add(group.Code);
                    }
                }
            }
            catch (Exception e)
            {
                Log.Error(e, e.Message);
                if (Debug) throw e;
            }
            Log.Debug($"Roles for user '{userName}': '{string.Join(",", roles)}'.");
            return roles;
        }

        public LDAPUserInfo RequestUserInfo(string userName)
        {
#if DEBUG
            if (string.IsNullOrEmpty(userName) || userName.ToUpper() == "DZCJSQ3")
                return JsonConvert.DeserializeObject<LDAPUserInfo>("{ \"id\":\"DZCJRHR\",\"name\":\"Jiri\",\"surname\":\"Rizek\",\"phone\":\"+420-777-015583\",\"email\":\"rizek@komix.cz\",\"department\":\"TMI\",\"prefLang\":\"CS\",\"roomNumber\":null,\"title\":null,\"personalNumber\":\"184E23701132663D\"}");
#endif

            if (!IsConfigured)
            {
                if (Debug) throw new InvalidOperationException("B2BUserRepo not configured");
                return null;
            }
            if (string.IsNullOrEmpty(userName))
            {
                if (Debug) throw new ArgumentNullException(nameof(userName), "UserName empty");
                return null;
            }

            try
            {
                organizationType organization;
                applicationType application;
                organizationType[] mandants;
                positionAssignmentsType positionAssignments;
                var b2BUserRepositoryClient = new B2BUserRepositoryClient();
                b2BUserRepositoryClient.ClientCredentials.ClientCertificate.SetCertificate(StoreLocation.LocalMachine, StoreName.My, X509FindType.FindByThumbprint, Security_B2BUserRepo_CertificateThumbprint);
                ((BasicHttpBinding)b2BUserRepositoryClient.Endpoint.Binding).Security.Mode = BasicHttpSecurityMode.Transport;
                ((BasicHttpBinding)b2BUserRepositoryClient.Endpoint.Binding).Security.Transport.ClientCredentialType = HttpClientCredentialType.Certificate;
                var result = b2BUserRepositoryClient.getUserInfo(userName, B2BUserRepo_AppName, out organization, out application, out mandants, out positionAssignments);
                LDAPUserInfo userInfo = new LDAPUserInfo()
                {
                    ID = userName,
                    Name = result.FirstName,
                    Surname = result.SurName,
                    EMail = result.Contact?.Email,
                    Phone = result.Contact?.Phone,
                    Title = result.TitlePrefix,
                    Department = result.SkodaDetails?.Department,
                    PersonalNumber = result.SkodaDetails?.EmployeeNumber,
                    PrefLang = result.Language
                };
                return userInfo;
            }
            catch (Exception e)
            {
                Log.Error(e, e.Message);
                if (Debug) throw e;
            }
            return null;

        }
    }

}
