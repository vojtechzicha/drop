﻿using eReadiness.Models.ViewModels;

namespace eReadiness.ViewModels
{
    public class ControlParams
    {
        public string Legend { get; set; }
        public string Name { get; set; }
        public string Type { get; set; } = "text";
        public string Value { get; set; }
        public string SpecText { get; set; } = App_GlobalResources.CarrierRes.Specify;
        public CarrierFormViewModel Model { get; set; }
        public string Sufix { get; set; }
        public string FieldName => Model.Prefix != null ? Model.Prefix + "_" + Name + Sufix : Name + Sufix;
        public bool Required { get; set; } = false;
        public string Placeholder { get; set; }
        public bool RequiredSpec { get; set; } = false;

        public ControlParams(CarrierFormViewModel model)
        {
            Model = model;
        }
    }
}