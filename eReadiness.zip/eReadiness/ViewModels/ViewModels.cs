﻿using eReadiness.App_GlobalResources;
using eReadiness.DataContext.Models;
using eReadiness.Utils;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace eReadiness.Models.ViewModels
{
    public class LocalizedQuestionArrayViewModel
    {
        public int formTemplateId { get; set; }
        public LocalizedQuestionViewModel[] questions { get; set; }
    }

    public class LocalizedQuestionViewModel
    {
        public string langCode { get; set; }
        public string questionText { get; set; }
    }

    public class FormViewModel
    {
        public string SelectedLangCode { get; set; }
        public int Id { get; set; }
        public FormState FormState { get; set; }
        public ProjectViewModel Project { get; set; }
        public IEnumerable<NoteViewModel> Notes { get; set; }
        public IEnumerable<ResponseViewModel> Responses { get; set; }
        [Display(Name = "Parts", ResourceType = typeof(GlobalRes))]
        public IEnumerable<string> Parts { get; set; }
        [Display(Name = "Supplier", ResourceType = typeof(GlobalRes))]
        public SupplierViewModel Supplier { get; set; }
        public DisponentViewModel Disponent { get; set; }
        public string Code { get; set; }
        public IEnumerable<string> Languages { get; set; }
    }

    public class FormTemplateViewModel
    {
        [Display(Name = "TemplateName", ResourceType = typeof(GlobalRes))]
        public string TemplateName { get; set; }
        public int Id { get; set; }
        public IEnumerable<LocalizedFormTemplateViewModel> LocalizedFormTemplates { get; set; }
    }
    public class LocalizedFormTemplateViewModel
    {
        public int Id { get; set; }
        [Display(Name = "MailSubject", ResourceType = typeof(GlobalRes))]
        public string MailSubject { get; set; }
        [AllowHtml]
        [Display(Name = "MailBody", ResourceType = typeof(GlobalRes))]
        public string MailBody { get; set; }
        [AllowHtml]
        [Display(Name = "MailBodyUrgent", ResourceType = typeof(GlobalRes))]
        public string MailBodyUrgent { get; set; }
        public IEnumerable<QuestionViewModel> Questions { get; set; }
        public IEnumerable<EmailAttachmentViewModel> EmailAttachments { get; set; }
        public string LangCode { get; set; }
    }


    public class QuestionViewModel
    {
        public int Id { get; set; }
        public string QuestionText { get; set; }
        public int QuestionOrder { get; set; }
        public bool ShowInReport { get; set; }
        public ResponseViewModel Response { get; set; }
    }

    public class PIDsViewModel
    {
        public int Id { get; set; }
        public string ProjectCode { get; set; }
        public string Name { get; set; }
        public PIDType Type { get; set; }
    }
    public class ProjectViewModel
    {
        public int Id { get; set; }
        public string PID { get; set; }
        [Display(Name = "Name", ResourceType = typeof(GlobalRes))]
        public string Name { get; set; }
        public string SOP { get; set; }
        public FormTemplateViewModel FormTemplate { get; set; }
    }

    public class CUProjectViewModel
    {
        public int Id { get; set; }
        public int PID { get; set; }
        public int WERK { get; set; }
        public int FormTemplate { get; set; }
        public string Name { get; set; }
        public string SOP { get; set; }
        public string VFF { get; set; }
        public string PVS { get; set; }
        public string OS { get; set; }
    }

    public class SupplierViewModel
    {
        public int Id { get; set; }
        public string Duns { get; set; }
        [Display(Name = "Name", ResourceType = typeof(GlobalRes))]
        public string Name { get; set; }
        //[Display(Name = "Kontaktní osoba")]
        //public string ContactPerson { get; set; }
        [Display(Name = "Email", ResourceType = typeof(GlobalRes))]
        public string Email { get; set; }
        public string LangCode { get; set; }
        public string Contactemails { get; set; }
        public string ContactProjectManagement { get; set; }
        public string ContactRepresentationOfManager { get; set; }
        public string ContactLogistics247 { get; set; }
        public string ContactQuality { get; set; }
        public string ContactEscalation { get; set; }
    }
    public class NoteViewModel
    {
        public int Id { get; set; }
        public string NoteText { get; set; }
        public string CreatedBy { get; set; }
        public DateTime DateCreated { get; set; }
    }
    public class WERKViewModel
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string WerkCode { get; set; }
    }
    public class DisponentViewModel
    {
        public int? Id { get; set; }
        public string Name { get; set; }
        public string DispoCode { get; set; }
        public string Languages { get; set; }
    }

    public class FormFilterResultViewModel
    {
        public string Code { get; set; }
        public ProjectViewModel Project { get; set; }
        public SupplierViewModel Supplier { get; set; }
        public DisponentViewModel Disponent { get; set; }
        public MilestoneType Milestone { get; set; }
        public int State { get; set; }
        public IEnumerable<NoteViewModel> Notes { get; set; }
        public DateTime DateSent { get; set; }
        public DateTime DateModified { get; set; }
        public string SOP { get; set; }
        public DateTime DateFilled { get; set; }
        public string FilledBy { get; set; }
    }

    public class FilterViewModel
    {
        public List<int> PIDs = new List<int>();
        public List<int> WERKs = new List<int>();
        public List<string> SOP = new List<string>();
        public List<string> PVS = new List<string>();
        public List<string> VFF = new List<string>();
        public List<string> OS = new List<string>();
        public List<int?> Disponents = new List<int?>();
        public List<int?> Suppliers = new List<int?>();
        public bool Unfinished = false;

        public List<DateTime?> SOPDates { get { return SOP.Select(x => x.FromKT()).ToList(); } }
        public List<DateTime?> PVSDates { get { return PVS.Select(x => x.FromKT()).ToList(); } }
        public List<DateTime?> VFFDates { get { return VFF.Select(x => x.FromKT()).ToList(); } }
        public List<DateTime?> OSDates { get { return OS.Select(x => x.FromKT()).ToList(); } }
    }

    public class FilterParam
    {
        public List<int> PID { get; set; }
        public List<int> WK { get; set; }
        public List<string> SP { get; set; }
        public List<string> V { get; set; }
        public List<string> P { get; set; }
        public List<string> O { get; set; }
        public List<int> D { get; set; }
        public List<int> S { get; set; }
        public bool? Unfinished { get; set; }
        //public FilterResultMode? Mode { get; set; }

        public List<DateTime?> SOPDates { get { return SP.Select(x => x.FromKT()).ToList(); } }
        public List<DateTime?> PVSDates { get { return P == null ? new List<DateTime?>() : P.Select(x => x.FromKT()).ToList(); } }
        public List<DateTime?> VFFDates { get { return V == null ? new List<DateTime?>() : V.Select(x => x.FromKT()).ToList(); } }
        public List<DateTime?> OSDates { get { return O == null ? new List<DateTime?>() : O.Select(x => x.FromKT()).ToList(); } }
        public int? QuestionOrder { get; set; }
        public bool? ResponseValue { get; set; }
        public int Template { get; set; }
    }

    public class ResponseViewModel
    {
        public int Id { get; set; }
        public bool ResponseValue { get; set; }
        public string ResponseReason { get; set; }
        public int FormId { get; set; }
        public int QuestionId { get; set; }
        public int QuestionOrder { get; set; }
    }

    public class SubmitFormViewModel
    {
        public string Code { get; set; }
        //public int FormId { get; set; }
        public bool Final { get; set; }
        public string Comment { get; set; }
        public string LangCode { get; set; }
        public string ContactProjectManagement { get; set; }
        public string ContactRepresentationOfManager { get; set; }
        public string ContactLogistics247 { get; set; }
        public string ContactQuality { get; set; }
        public string ContactEscalation { get; set; }
        public List<ResponseViewModel> ResponseArray { get; set; }
    }

    public class EmailAttachmentViewModel
    {
        public int Id { get; set; }
        public string FileName { get; set; }
        public bool AsAttachment { get; set; }
    }

    public class ReportViewModel
    {
        public List<string> ProjectNames { get; set; }
        public string SOP { get; set; }
        public string VFF { get; set; }
        public string PVS { get; set; }
        public string OS { get; set; }
        public int SentForms { get; set; }
        public int FormNotReturnedIn5Days { get; set; }
        public int FormReturnedOK { get; set; }
        public int NotSent { get; set; }
        public int MissingSupplier { get; set; }
        public int WithSupplier { get; set; }
        public int WithoutDisponent { get; set; }
        public int TotalParts { get; set; }
        public int BRelease { get; set; }
        public int Fakom { get; set; }
        public int Returned { get; set; }
        public List<ResponseCountViewModel> ResponseCounts { get; set; }
        public string Werks { get; set; }
    }

    public class ResponseCountViewModel
    {
        public string QuestionText { get; set; }
        public int Yes { get; set; }
        public int No { get; set; }
        public int QuestionOrder { get; set; }
        public Question Question { get; set; }
        public int Template { get; set; }
    }

    public class SwapQuestionViewModel
    {
        public int originalPosition { get; set; }
        public int newPosition { get; set; }
        public int questionId { get; set; }
    }

    public class NumberNameViewModel
    {
        public string Number { get; set; }
        public string Name { get; set; }
    }

    public class CarrierFormViewModel
    {
        public string Code { get; set; }
        public FormState FormState { get; set; }
        public Carrier Carrier { get; set; }
        public FormCollection FormValues { get; set; }
        public IEnumerable<string> Languages { get; set; }
        public string SelectedLangCode { get; set; }
        public string Prefix { get; set; }

        public string GetFormValue(string name)
        {
            if (FormValues != null && FormValues.AllKeys.Contains(name))
                return FormValues[name];
            else
                return null;
        }
    }

    public class CarrierViewModel
    {
        public int Id { get; set; }
        public string DunsCode { get; set; }
        public string Name { get; set; }
        public string Address { get; set; }
        public string Email { get; set; }
        public string SAP { get; set; }
        public string LangCode { get; set; }
        public CarrierType CarrierType { get; set; }
    }

    public class CarrierFormTemplateViewModel
    {
        [Display(Name = "TemplateName", ResourceType = typeof(GlobalRes))]
        public string TemplateName { get; set; }
        public int Id { get; set; }
        public CarrierType CarrierType { get; set; }
        public IEnumerable<CarrierLocalizedFormTemplateViewModel> LocalizedFormTemplates { get; set; }
    }
    public class CarrierLocalizedFormTemplateViewModel
    {
        public int Id { get; set; }
        [Display(Name = "MailSubject", ResourceType = typeof(GlobalRes))]
        public string MailSubject { get; set; }
        [AllowHtml]
        [Display(Name = "MailBody", ResourceType = typeof(GlobalRes))]
        public string MailBody { get; set; }
        [AllowHtml]
        [Display(Name = "MailBodyUrgent", ResourceType = typeof(GlobalRes))]
        public string MailBodyUrgent { get; set; }
        public IEnumerable<EmailAttachmentViewModel> EmailAttachments { get; set; }
        public string LangCode { get; set; }
    }
}