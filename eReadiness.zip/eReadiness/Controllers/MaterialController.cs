﻿using eReadiness.DataContext.Models;
using eReadiness.Models.ViewModels;
using eReadiness.Security;
using eReadiness.Utils;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web.Mvc;

namespace eReadiness.Controllers
{
    [SecurityRoleAuthorize(SecurityRole.Disponent, SecurityRole.ProjectManager, Order = 1)]
    public class MaterialController : BaseController
    {
        //public ActionResult Index(string data, MaterialResultMode? mode)
        //{
        //    try
        //    {
        //        var projectQuery = GetProjects(data);

        //        var projects = projectQuery.ToList();

        //        var forms = DbContext.Forms
        //            .Include(x => x.Materials)
        //            .Where(x => projectQuery.Contains(x.Project));

        //        List<NumberNameViewModel> materials = new List<NumberNameViewModel>();

        //        var materialBomQuery = DbContext.MaterialBOMs.Join(
        //            projectQuery,
        //            s => new { s.PROD_ID, s.WK, s.SOPDATE },
        //            h => new { PROD_ID = h.PID.ProjectCode, WK = h.WERK.WerkCode, SOPDATE = h.SOP },
        //            (s, h) => s
        //            );

        //        var withSuppMaterial = forms
        //            .SelectMany(x => x.Materials.Where(y => y.DateDeleted == null && y.ManualDeleted != true))
        //            .Include(x => x.Form)
        //            .Include(x => x.Form.Project)
        //            .Include(x => x.Form.Project.PID)
        //            .Include(x => x.Form.Project.WERK)
        //            .ToList();

        //        var missingMaterial = new List<NumberNameViewModel>();

        //        foreach(var materialBom in materialBomQuery.ToList())
        //        {
        //            var s = withSuppMaterial
        //                .FirstOrDefault(
        //                    x => x.Number == materialBom.TEIL_NR &&
        //                    x?.Form?.Project?.PID?.ProjectCode == materialBom.PROD_ID &&
        //                    x?.Form?.Project?.WERK?.WerkCode == materialBom.WK &&
        //                    x?.Form?.Project?.SOP == materialBom.SOPDATE);
        //            if (s == null)
        //                missingMaterial.Add(new NumberNameViewModel() { Number = materialBom.TEIL_NR, Name = materialBom.BEN });
        //        }

        //        switch (mode)
        //        {
        //            case MaterialResultMode.MissingSupplier:
        //                materials = missingMaterial;
        //                break;
        //            case MaterialResultMode.WithSupplier:
        //                materials = withSuppMaterial.Select(x => new NumberNameViewModel() { Number = x.Number, Name = x.Name }).ToList();
        //                break;
        //            case MaterialResultMode.TotalParts:
        //                materials = materialBomQuery
        //                    .Select(x => new NumberNameViewModel() { Number = x.TEIL_NR, Name = x.BEN }).ToList();
        //                break;
        //            case MaterialResultMode.BRelease:
        //                materials = materialBomQuery.Where(x => x.NOTB == true)
        //                    .Select(x => new NumberNameViewModel() { Number = x.TEIL_NR, Name = x.BEN }).ToList();
        //                break;
        //            case MaterialResultMode.Fakom:
        //                materials = materialBomQuery.Where(x => x.NOTCOLOR == true)
        //                    .Select(x => new NumberNameViewModel() { Number = x.TEIL_NR, Name = x.BEN }).ToList();
        //                break;
        //            default:
        //                break;
        //        }

        //        return View(materials);
        //    }
        //    catch (Exception ex)
        //    {
        //        Log.Error(ex, "MaterialController.Index");
        //        throw;
        //    }
        //}

        public ActionResult Index(FilterParam param, MaterialResultMode? mode)
        {
            try
            {
                var projectQuery = GetProjects(param);

                var projects = projectQuery.ToList();

                var forms = DbContext.Forms.Where(x => projectQuery.Contains(x.Project) && (
                (param.PVSDates.Contains(x.Project.PVS) && x.MilestoneType == MilestoneType.PVS) ||
                    (param.VFFDates.Contains(x.Project.VFF) && x.MilestoneType == MilestoneType.VFF) ||
                    (param.OSDates.Contains(x.Project.OS) && x.MilestoneType == MilestoneType.S0)
                ));

                List<NumberNameViewModel> materials = new List<NumberNameViewModel>();

                var materialBomQuery = DbContext.MaterialBOMs.Join(
                    projectQuery,
                    s => new { s.PROD_ID, s.WK, s.SOPDATE },
                    h => new { PROD_ID = h.PID.ProjectCode, WK = h.WERK.WerkCode, SOPDATE = h.SOP },
                    (s, h) => s
                    );

                var withSuppMaterial = forms
                    .SelectMany(x => x.Materials.Where(y => y.DateDeleted == null && y.ManualDeleted != true))
                    .Include(x => x.Form)
                    .Include(x => x.Form.Project)
                    .Include(x => x.Form.Project.PID)
                    .Include(x => x.Form.Project.WERK)
                    .ToList();

                var missingMaterial = new List<NumberNameViewModel>();

                foreach (var materialBom in materialBomQuery.ToList())
                {
                    var s = withSuppMaterial
                        .FirstOrDefault(
                            x => x.Number == materialBom.TEIL_NR &&
                            x?.Form?.Project?.PID?.ProjectCode == materialBom.PROD_ID &&
                            x?.Form?.Project?.WERK?.WerkCode == materialBom.WK &&
                            x?.Form?.Project?.SOP == materialBom.SOPDATE);
                    if (s == null)
                        missingMaterial.Add(new NumberNameViewModel() { Number = materialBom.TEIL_NR, Name = materialBom.BEN });
                }

                switch (mode)
                {
                    case MaterialResultMode.MissingSupplier:
                        materials = missingMaterial.Distinct().ToList();
                        break;
                    case MaterialResultMode.WithSupplier:
                        materials = withSuppMaterial.DistinctBy(x => x.Number).Select(x => new NumberNameViewModel() { Number = x.Number, Name = x.Name }).ToList();
                        break;
                    case MaterialResultMode.TotalParts:
                        materials = materialBomQuery
                            .Select(x => new NumberNameViewModel() { Number = x.TEIL_NR, Name = x.BEN }).Distinct().ToList();
                        break;
                    case MaterialResultMode.BRelease:
                        materials = materialBomQuery.Where(x => x.NOTB == true)
                            .Select(x => new NumberNameViewModel() { Number = x.TEIL_NR, Name = x.BEN }).Distinct().ToList();
                        break;
                    case MaterialResultMode.Fakom:
                        materials = materialBomQuery.Where(x => x.NOTCOLOR == true)
                            .Select(x => new NumberNameViewModel() { Number = x.TEIL_NR, Name = x.BEN }).Distinct().ToList();
                        break;
                    default:
                        break;
                }

                return View(materials);
            }
            catch (Exception ex)
            {
                Log.Error(ex, "MaterialController.Index");
                throw;
            }
        }
    }
}