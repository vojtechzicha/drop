﻿using eReadiness.DataContext.Models;
using eReadiness.Models.ViewModels;
using eReadiness.Security;
using eReadiness.Utils;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace eReadiness.Controllers
{
    [SecurityRoleAuthorize(SecurityRole.Disponent, SecurityRole.ProjectManager, SecurityRole.STManager, SecurityRole.STSpecialist, Order = 1)]
    public class FilterController : BaseController
    {
        public ActionResult Index(string data)
        {
            if (User.IsInAnyRole(SecurityRole.STManager, SecurityRole.STSpecialist) && !User.IsInAnyRole(SecurityRole.ProjectManager, SecurityRole.Disponent))
            {
                return RedirectToAction("Index", "CarrierForms");
            }

            try
            {
                if (!String.IsNullOrEmpty(data))
                {
                    ViewBag.FilterModel = JsonConvert.DeserializeObject<FilterViewModel>(HttpUtility.UrlDecode(data));
                }

                var PIDs = DbContext.PIDs.NotRemoved().Select(p => new PIDsViewModel
                {
                    Id = p.Id,
                    ProjectCode = p.ProjectCode,
                    Name = p.Name
                });
                ViewBag.PIDs = PIDs;

                var WERKs = DbContext.WERKs.NotRemoved().Select(e => new WERKViewModel
                {
                    Id = e.Id,
                    WerkCode = e.WerkCode,
                    Name = e.Name
                });
                ViewBag.WERKs = WERKs;

                return View();
            }
            catch (Exception ex)
            {
                Log.Error(ex, "FilterController.Index");
                throw;
            }
        }

        [HttpPost]
        public ActionResult GetPrefilteredData(List<int> PIDs, List<int> WERKs, List<string> SOPs)
        {
            try
            {
                var projects = new List<Project>();
                var enterpriseProjects = new List<Project>();
                var resultProjects = new List<Project>();

                var pNull = false;
                var eNull = false;

                if (PIDs != null && PIDs.Count > 0)
                    projects = DbContext.Projects.NotRemoved().Include(p => p.PID).Where(p => PIDs.Contains(p.PID.Id)).ToList();
                else
                    pNull = true;

                if (WERKs != null && WERKs.Count > 0)
                    enterpriseProjects = DbContext.Projects.NotRemoved().Include(p => p.WERK).Where(p => WERKs.Contains(p.WERK.Id)).ToList();
                else
                    eNull = true;

                if (!pNull && !eNull)
                    resultProjects = projects.Join(enterpriseProjects, p => p.Id, q => q.Id, (p, q) => p).ToList();
                else if (pNull)
                    resultProjects = enterpriseProjects;
                else if (eNull)
                    resultProjects = projects;
                else
                    return Json("");

                IEnumerable<string> sopMilestones = null;
                if (SOPs != null && SOPs.Any())
                {
                    var sopDates = SOPs.Select(s => s.FromKT().Value).ToList();
                    resultProjects = resultProjects.Where(rp => sopDates.Contains(rp.SOP)).ToList();
                }
                else
                {
                    sopMilestones = resultProjects.Select(p => p.SOP).Where(d => d != DateTime.MinValue).Distinct().ToList().Select(KTExtensions.KTLambda).Distinct().ToList();
                }

                var resultProjectsIDs = resultProjects.Select(p => p.Id);

                var pvsMilestones = resultProjects.Where(rp => rp.PVS.HasValue && rp.PVS.Value != DateTime.MinValue).Select(rp => rp.PVS.Value).Distinct().ToList().Select(KTExtensions.KTLambda).Distinct().ToList();
                var vffMilestones = resultProjects.Where(rp => rp.VFF.HasValue && rp.VFF.Value != DateTime.MinValue).Select(rp => rp.VFF.Value).Distinct().ToList().Select(KTExtensions.KTLambda).Distinct().ToList();
                var osMilestones = resultProjects.Where(rp => rp.OS.HasValue && rp.OS.Value != DateTime.MinValue).Select(rp => rp.OS.Value).Distinct().ToList().Select(KTExtensions.KTLambda).Distinct().ToList();

                var forms = DbContext.Forms.NotRemoved()
                    .Include(f => f.Project)
                    .Include(f => f.Disponent)
                    .Include(f => f.Supplier)
                    .Include(f => f.Supplier.DunsCodes)
                    .Where(f => resultProjectsIDs.Contains(f.Project.Id));

                var disponents = forms.Select(f => new DisponentViewModel
                {
                    Id = f.Disponent.Id,
                    DispoCode = f.Disponent.DispoCode,
                    Name = f.Disponent.Name
                }).Distinct().ToList();

                var suppliers = forms.Where(x => x.Supplier != null).Select(x => x.Supplier).Distinct().ToList()
                    .Select(f => new SupplierViewModel
                    {
                        Id = f.Id,
                        Duns = f.DunsCode,
                        Email = f.Email,
                        Name = f.Name
                    }).ToList();

                /*var disponents = DbContext.Disponents.Include(d => d.Projects)
                    .Where(d => d.Projects.Any(p => resultProjectsPIDs.Contains(p.Id)))
                    .Select(d => new DisponentViewModel
                    {
                        Id = d.Id,
                        DispoMark = d.DispoMark,
                        Name = d.Name
                    });

                var suppliers = DbContext.Suppliers.Include(d => d.Projects)
                    .Where(s => s.Projects.Any(p => resultProjectsPIDs.Contains(p.Id)))
                    .Select(s => new SupplierViewModel
                {
                    Id = s.Id,
                    Duns = s.DunsCode,
                    Name = s.Name,
                    //ContactPerson = s.ContactPerson,
                    Email = s.Email
                });*/

                return Json(new
                {
                    sopMilestones,
                    pvsMilestones,
                    vffMilestones,
                    osMilestones,
                    disponents,
                    suppliers
                });
            }
            catch (Exception ex)
            {
                Log.Error(ex, "FilterController.GetPrefilteredData");
                throw;
            }
        }

        /*
                public ActionResult FilterResult(string data, FilterResultMode? mode)
                {
                    try
                    {
                        data = data.Replace("null", "");

                        var jsonSettings = new JsonSerializerSettings
                        {
                            NullValueHandling = NullValueHandling.Ignore
                        };

                        var filterModel = new FilterViewModel();
                        if (!String.IsNullOrEmpty(data))
                            filterModel = JsonConvert.DeserializeObject<FilterViewModel>(HttpUtility.UrlDecode(data), jsonSettings);

                        var formsQuery = DbContext.Forms
                            .Include(f => f.Supplier)
                            .Include(f => f.Disponent)
                            .Include(f => f.Project)
                            .Include(f => f.Notes);

                        if(mode.HasValue)
                        {
                            switch (mode)
                            {
                                case FilterResultMode.Sent:
                                    formsQuery = formsQuery.Where(x => x.FormState == FormState.Sent || x.FormState == FormState.Opened);
                                    break;
                                case FilterResultMode.NotReturned:
                                    var before5Day = DateTime.Now.AddDays(-5);
                                    formsQuery = formsQuery.Where(x => x.FormState == FormState.Sent && x.DateSent < before5Day);
                                    break;
                                case FilterResultMode.ReturnedOK:
                                    formsQuery = formsQuery.Where(x => x.FormState == FormState.Closed && x.Completition == 100);
                                    break;
                                case FilterResultMode.NotSent:
                                    formsQuery = formsQuery.Where(x => x.FormState == FormState.Ready);
                                    break;
                                case FilterResultMode.Returned:
                                    formsQuery = formsQuery.Where(x => x.FormState == FormState.Closed);
                                    break;
                                case FilterResultMode.WithoutDisponent:
                                    formsQuery = formsQuery.Where(x => x.Disponent == null);
                                    break;
                                default:
                                    break;
                            }
                        }

                        if (filterModel.PIDs.Any())
                            formsQuery = formsQuery.Where(x => filterModel.PIDs.Contains(x.Project.PID.Id));
                        if (filterModel.WERKs.Any())
                            formsQuery = formsQuery.Where(x => filterModel.WERKs.Contains(x.Project.WERK.Id));
                        if (filterModel.Suppliers.Any())
                            formsQuery = formsQuery.Where(x => filterModel.Suppliers.Contains(x.Supplier.Id));
                        if (filterModel.Disponents.Any())
                            formsQuery = formsQuery.Where(x => filterModel.Disponents.Contains(x.Disponent.Id));
                        if (filterModel.SOP.Any())
                            formsQuery = formsQuery.Where(x => filterModel.SOPDates.Contains(x.Project.SOP));
                        if (filterModel.PVS.Any())
                            formsQuery = formsQuery.Where(x => filterModel.PVSDates.Contains(x.Project.PVS));
                        if (filterModel.VFF.Any())
                            formsQuery = formsQuery.Where(x => filterModel.VFFDates.Contains(x.Project.VFF));
                        if (filterModel.OS.Any())
                            formsQuery = formsQuery.Where(x => filterModel.OSDates.Contains(x.Project.OS));
                        if (filterModel.Unfinished)
                            formsQuery = formsQuery.Where(x => x.FormState != FormState.Closed);

                        //var str = "abc";
                        //formsQuery = formsQuery.Where(x => DbFunctions.Like(x.Code, str));

                        var forms = formsQuery.ToList();

                        var resultModel = new List<FormFilterResultViewModel>();
                        foreach (var f in forms)
                        {
                            resultModel.Add(new FormFilterResultViewModel
                            {
                                Code = f.Code,
                                Supplier = new SupplierViewModel
                                {
                                    Id = f.Supplier.Id,
                                    Duns = f.Supplier.DunsCode,
                                    Name = f.Supplier.Name,
                                    Email = f.Supplier.Email
                                },
                                Disponent = new DisponentViewModel
                                {
                                    Id = f.Disponent?.Id,
                                    DispoCode = f.Disponent?.DispoCode,
                                    Name = f.Disponent?.Name
                                },
                                Project = new ProjectViewModel
                                {
                                    Id = f.Project.Id,
                                    Name = f.Project.Name,
                                    SOP = KTExtensions.KTLambda.Invoke(f.Project.SOP),
                                },
                                State = f.Completition,
                                Notes = f.Notes.Select(n => new NoteViewModel
                                {
                                    Id = n.Id,
                                    NoteText = n.NoteText
                                }),
                                DateSent = f.DateSent,
                                DateFilled = f.DateFilled,
                                Milestone = f.MilestoneType
                            });
                        }

                        return View(resultModel);
                    }
                    catch (Exception ex)
                    {
                        Log.Error(ex, "FilterController.FilterResult");
                        throw;
                    }
                }
        */
        public ActionResult FilterResult(FilterParam param, FilterResultMode? mode)
        {
            try
            {
                var formsQuery = DbContext.Forms
                    .Include(f => f.Supplier)
                    .Include(f => f.Supplier.DunsCodes)
                    .Include(f => f.Disponent)
                    .Include(f => f.Project)
                    .Include(f => f.Notes);

                if (mode.HasValue)
                {
                    switch (mode)
                    {
                        case FilterResultMode.Sent:
                            formsQuery = formsQuery.Where(x => x.FormState == FormState.Sent || x.FormState == FormState.Opened);
                            break;
                        case FilterResultMode.NotReturned:
                            var before5Day = DateTime.Now.AddDays(-5);
                            formsQuery = formsQuery.Where(x => x.FormState == FormState.Sent && x.DateSent < before5Day);
                            break;
                        case FilterResultMode.ReturnedOK:
                            formsQuery = formsQuery.Where(x => x.FormState == FormState.Closed && x.Completition == 100);
                            break;
                        case FilterResultMode.NotSent:
                            formsQuery = formsQuery.Where(x => x.FormState == FormState.Ready);
                            break;
                        case FilterResultMode.Returned:
                            formsQuery = formsQuery.Where(x => x.FormState == FormState.Closed);
                            break;
                        case FilterResultMode.WithoutDisponent:
                            formsQuery = formsQuery.Where(x => x.Disponent == null);
                            break;
                        case FilterResultMode.Responses:
                            //DbContext.FormTemplateLocalized_Questions.Where(y => y.QuestionOrder == 1);
                            //var respones = DbContext.Responses.NotRemoved().Where(x => x.Form.Project.Id == param.QuestionProject && x.Question.FormTemplateLocalized_Questions.Any(y => y.QuestionOrder == param.QuestionOrder && y.Question == x.Question && x.ResponseValue == param.ResponseValue));
                            var respones = DbContext.Responses.NotRemoved().Where(x => x.Question.FormTemplateLocalized_Questions.Any(y => y.QuestionOrder == param.QuestionOrder && y.Question == x.Question && x.ResponseValue == param.ResponseValue && y.LocalizedForm.ParentTemplate.Id == param.Template));
                            formsQuery = respones.Select(x => x.Form).Distinct()
                                .Where(x => x.FormState == FormState.Closed)
                                .Include(f => f.Supplier)
                                .Include(f => f.Disponent)
                                .Include(f => f.Project)
                                .Include(f => f.Notes);
                            break;
                        default:
                            break;
                    }
                }

                if (param.PID != null && param.PID.Any())
                    formsQuery = formsQuery.Where(x => param.PID.Contains(x.Project.PID.Id));
                if (param.WK != null && param.WK.Any())
                    formsQuery = formsQuery.Where(x => param.WK.Contains(x.Project.WERK.Id));
                if (param.S != null && param.S.Any())
                    formsQuery = formsQuery.Where(x => param.S.Contains(x.Supplier.Id));
                if (param.D != null && param.D.Any())
                    formsQuery = formsQuery.Where(x => param.D.Contains(x.Disponent.Id));

                //if (param.SP != null && param.SP.Any())
                //  formsQuery = formsQuery.Where(x => param.SOPDates.Contains(x.Project.SOP));
                //if (param.P != null && param.P.Any())
                //    formsQuery = formsQuery.Where(x => param.PVSDates.Contains(x.Project.PVS) && x.MilestoneType == MilestoneType.PVS);
                //if (param.V != null && param.V.Any())
                //    formsQuery = formsQuery.Where(x => param.VFFDates.Contains(x.Project.VFF) && x.MilestoneType == MilestoneType.VFF);
                //if (param.O != null && param.O.Any())
                //    formsQuery = formsQuery.Where(x => param.OSDates.Contains(x.Project.OS) && x.MilestoneType == MilestoneType.S0);

                if ((param.P != null && param.P.Any()) || (param.V != null && param.V.Any()) || (param.O != null && param.O.Any()))
                {
                    formsQuery = formsQuery.Where(x =>
                    (param.PVSDates.Contains(x.Project.PVS) && x.MilestoneType == MilestoneType.PVS) ||
                    (param.VFFDates.Contains(x.Project.VFF) && x.MilestoneType == MilestoneType.VFF) ||
                    (param.OSDates.Contains(x.Project.OS) && x.MilestoneType == MilestoneType.S0)
                    );
                }

                if (param.Unfinished == true)
                    formsQuery = formsQuery.Where(x => x.FormState != FormState.Closed);

                //var str = "abc";
                //formsQuery = formsQuery.Where(x => DbFunctions.Like(x.Code, str));

                var forms = formsQuery.OrderBy(x => x.Id).ToList();

                var resultModel = new List<FormFilterResultViewModel>();
                foreach (var f in forms)
                {
                    resultModel.Add(new FormFilterResultViewModel
                    {
                        Code = f.Code,
                        Supplier = new SupplierViewModel
                        {
                            Id = f.Supplier.Id,
                            Duns = f.Supplier.DunsCode,
                            Name = f.Supplier.Name,
                            Email = f.Supplier.Email
                        },
                        Disponent = new DisponentViewModel
                        {
                            Id = f.Disponent?.Id,
                            DispoCode = f.Disponent?.DispoCode,
                            Name = f.Disponent?.Name
                        },
                        Project = new ProjectViewModel
                        {
                            Id = f.Project.Id,
                            Name = f.Project.Name,
                            SOP = KTExtensions.KTLambda.Invoke(f.Project.SOP),
                        },
                        State = f.Completition,
                        Notes = f.Notes.Select(n => new NoteViewModel
                        {
                            Id = n.Id,
                            NoteText = n.NoteText
                        }),
                        DateSent = f.DateSent,
                        DateFilled = f.DateFilled,
                        Milestone = f.MilestoneType,
                        FilledBy = f.FilledBy
                    });
                }

                return View(resultModel);
            }
            catch (Exception ex)
            {
                Log.Error(ex, "FilterController.FilterResult");
                throw;
            }
        }
    }
}