﻿using eReadiness.DataContext.Models;
using eReadiness.Models.ViewModels;
using eReadiness.Security;
using eReadiness.Utils;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web.Mvc;

namespace eReadiness.Controllers
{
    [SecurityRoleAuthorize(SecurityRole.ProjectManager, Order = 1)]
    public class FormTemplatesController : BaseController
    {
        #region Displaying and Edit
        public ActionResult Index()
        {
            var ftvm = DbContext.FormTemplates.NotRemoved().Select(ft => new FormTemplateViewModel
            {
                Id = ft.Id,
                /*MailBody = ft.MailBody,
                MailSubject = ft.MailSubject,*/
                TemplateName = ft.TemplateName
            });
            return View(ftvm);
        }

        public ActionResult EditTemplate(int id = -1, string langKey = "CS")
        {
            //ViewBag.Questions = DbContext.Questions.NotRemoved();
            ViewBag.EmailAttachments = DbContext.EmailAttachments.NotRemoved().Select(s => new EmailAttachmentViewModel
            {
                Id = s.Id,
                FileName = s.FileName
            });
            ViewBag.LangKey = langKey;

            FormTemplateViewModel formTemplate;

            if (id == -1)
            {
                var ft = new FormTemplate();
                ft.TemplateName = "Nová šablona";

                DbContext.FormTemplates.Add(ft);
                DbContext.SaveChanges();

                var lft = new FormTemplateLocalized();
                lft.ParentTemplate = ft;
                lft.Language = DbContext.Languages.FirstOrDefault(l => l.LangCode == langKey);
                lft.FormTemplateLocalized_Questions = new List<FormTemplateLocalized_Question>();
                lft.EmailAttachments = new List<EmailAttachment>();

                DbContext.LocalizedTemplates.Add(lft);
                DbContext.SaveChanges();

                formTemplate = LoadFormTemplate(ft.Id);
            }
            else
            {
                formTemplate = LoadFormTemplate(id);
            }


            return View(formTemplate);
        }

        [HttpPost]
        public ActionResult UpdateTemplate(FormTemplateViewModel data)
        {
            var ft = DbContext.FormTemplates.Find(data.Id);
            if (ft == null)
                return HttpNotFound();

            /*ft.MailBody = data.MailBody;
            ft.MailBodyUrgent = data.MailBodyUrgent;
            ft.MailSubject = data.MailSubject;*/
            ft.TemplateName = data.TemplateName;

            DbContext.SaveChanges();
            return Json("OK");
        }

        [HttpPost]
        public ActionResult UpdateLocalizedTemplate(LocalizedFormTemplateViewModel data)
        {
            var template = DbContext.FormTemplates.Find(data.Id);
            if (template == null)
                return HttpNotFound();

            var localizedTemplate = template.LocalizedTemplates.FirstOrDefault(lt => lt.Language.LangCode == data.LangCode);

            localizedTemplate.MailBody = CleanScripts(data.MailBody); 
            localizedTemplate.MailBodyUrgent = CleanScripts(data.MailBodyUrgent);
            localizedTemplate.MailSubject = data.MailSubject;

            DbContext.SaveChanges();
            return Json("OK");
        }

        [HttpPost]
        public ActionResult DeleteFormTemplate(int[] ids)
        {
            foreach (var id in ids)
            {
                var ft = DbContext.FormTemplates.Find(id);
                if (ft == null)
                    continue;

                DbContext.FormTemplates.Remove(ft);
            }
            DbContext.SaveChanges();
            return RedirectToAction("Index");
        }

        [HttpPost]
        public ActionResult CreateLanguageMutation(int formTemplateId, int langId)
        {
            var formTemplate = DbContext.FormTemplates.Find(formTemplateId);

            if (formTemplate == null)
                return new HttpStatusCodeResult(System.Net.HttpStatusCode.NotFound);

            var language = DbContext.Languages.Find(langId);

            if (language == null)
                return new HttpStatusCodeResult(System.Net.HttpStatusCode.NotFound);

            var localizedTemplate = formTemplate.LocalizedTemplates.FirstOrDefault(lft => lft.Language.Id == langId);

            if (localizedTemplate != null)
                return new HttpStatusCodeResult(System.Net.HttpStatusCode.BadRequest);

            localizedTemplate = new FormTemplateLocalized
            {
                Language = language,
                ParentTemplate = formTemplate
            };

            DbContext.LocalizedTemplates.Add(localizedTemplate);
            DbContext.SaveChanges();

            var questionsToRecreate = formTemplate.LocalizedTemplates.FirstOrDefault().FormTemplateLocalized_Questions;

            foreach (var q in questionsToRecreate)
            {
                var newQuestion = new Question
                {
                    QuestionText = "Vygenerovaná otázka - prosím vyplňte / Autogenerated question - please fill",
                    ShowInReport = q.Question.ShowInReport
                };
                DbContext.Questions.Add(newQuestion);
                DbContext.SaveChanges();

                var newQuestionBinding = new FormTemplateLocalized_Question
                {
                    QuestionOrder = q.QuestionOrder,
                    Question = newQuestion,
                    LocalizedForm = localizedTemplate                    
                };

                DbContext.FormTemplateLocalized_Questions.Add(newQuestionBinding);
                DbContext.SaveChanges();
            }

            return Json("OK");
        }
        #endregion

        #region Attachments
        [HttpPost]
        public ActionResult CreateAttachment()
        {
            var templateId = Int32.Parse(Request.Form["Id"]);
            var langCode = Request.Form["LangCode"];

            var template = DbContext.FormTemplates.Find(templateId);
            
            if (template == null)
                return HttpNotFound();

            var localizedTemplate = template.LocalizedTemplates.FirstOrDefault(lt => lt.Language.LangCode == langCode);

            var eat = new List<EmailAttachment>();
            for (int i = 0; i < Request.Files.Count; i++)
            {
                var file = Request.Files[i];
                var fileContent = file.InputStream;

                eat.Add(new EmailAttachment
                {
                    FileName = file.FileName,
                    LocalizedTemplates = new List<FormTemplateLocalized> { localizedTemplate },
                    Data = Extensions.ReadStream(file.InputStream)
                });
            }

            DbContext.EmailAttachments.AddRange(eat);
            localizedTemplate.EmailAttachments.AddRange(eat);

            DbContext.SaveChanges();

            return Json(eat.Select(ea => new { Id = ea.Id, Name = ea.FileName }));
        }

        [HttpPost]
        public ActionResult BindAttachment(int[] attachmentIds, int formTemplateId, string langCode)
        {
            var formTemplate = DbContext.FormTemplates.Include(f => f.LocalizedTemplates).FirstOrDefault(f => f.Id == formTemplateId);
            var localizedFormTemplate = formTemplate.LocalizedTemplates.FirstOrDefault(lt => lt.Language.LangCode == langCode);
            var emailAttachments = DbContext.EmailAttachments.Where(ea => attachmentIds.Contains(ea.Id));

            if (formTemplate == null || emailAttachments == null || emailAttachments.Count() < 1)
                return HttpNotFound();

            if (localizedFormTemplate.EmailAttachments.Any(e => attachmentIds.Contains(e.Id)))
                return new HttpStatusCodeResult(System.Net.HttpStatusCode.BadRequest);

            localizedFormTemplate.EmailAttachments.AddRange(emailAttachments);
            localizedFormTemplate.DateModified = DateTime.Now;
            formTemplate.DateModified = DateTime.Now;

            DbContext.SaveChanges();
            return Json(emailAttachments.Select(ea => new { Id = ea.Id, Name = ea.FileName }));
        }

        [HttpPost]
        public ActionResult UnbindAttachment(int attachmentId, int formTemplateId, string langCode)
        {
            var formTemplate = DbContext.FormTemplates.Include(f => f.LocalizedTemplates).FirstOrDefault(f => f.Id == formTemplateId);
            var localizedTemplate = formTemplate.LocalizedTemplates.FirstOrDefault(lt => lt.Language.LangCode == langCode);
            var emailAttachment = DbContext.EmailAttachments.Find(attachmentId);

            if (formTemplate == null || localizedTemplate == null || emailAttachment == null)
                return HttpNotFound();

            if (!localizedTemplate.EmailAttachments.Any(ea => ea.Id == attachmentId))
                return new HttpStatusCodeResult(System.Net.HttpStatusCode.BadRequest);

            localizedTemplate.EmailAttachments.Remove(emailAttachment);
            localizedTemplate.DateModified = DateTime.Now;
            formTemplate.DateModified = DateTime.Now;

            DbContext.SaveChanges();

            return new HttpStatusCodeResult(System.Net.HttpStatusCode.OK);
        }

        [HttpPost]
        public ActionResult AsAttachment(int attachmentId, bool asAttachment, int formTemplateId)
        {
            var sizeLimit = 2000000;
            var emailAttachment = DbContext.EmailAttachments.Find(attachmentId);
            if (emailAttachment == null)
                return HttpNotFound();

            var formTemplate = DbContext.FormTemplates.Find(formTemplateId);

            //Count total size of files attached directly to email
            var allAttachments = formTemplate.LocalizedTemplates.SelectMany(lt => lt.EmailAttachments);
            var allInEmail = allAttachments.Where(ea => ea.AsAttachment);
            var sumSize = allInEmail.Select(ie => ie.Data).Sum(data => data.Length);

            sumSize += emailAttachment.Data.Length;

            if (sumSize > sizeLimit)
                return new HttpStatusCodeResult(System.Net.HttpStatusCode.RequestEntityTooLarge);

            emailAttachment.AsAttachment = asAttachment;
            DbContext.SaveChanges();

            //return new HttpStatusCodeResult(System.Net.HttpStatusCode.NotAcceptable, "To large");

            return new HttpStatusCodeResult(System.Net.HttpStatusCode.OK);
        }

        #endregion

        #region Questions
        [HttpPost]
        public ActionResult CreateQuestion(LocalizedQuestionArrayViewModel model)
        {
            var formTemplate = DbContext.FormTemplates.Include(f => f.LocalizedTemplates).FirstOrDefault(f => f.Id == model.formTemplateId);

            if (formTemplate == null)
                return HttpNotFound();

            var questionOrder = formTemplate.LocalizedTemplates.Max(lt => lt.FormTemplateLocalized_Questions.Count) + 1;

            var rv = new List<Tuple<int, string>>();

            foreach (var locQuestion in model.questions)
            {
                var localizedTemplate = formTemplate.LocalizedTemplates.FirstOrDefault(lt => lt.Language.LangCode == locQuestion.langCode);
                if (localizedTemplate == null)
                    return HttpNotFound();

                var question = new Question
                {
                    QuestionText = (String.IsNullOrEmpty(locQuestion.questionText) ? "Vygenerovaná otázka - prosím vyplňte / Autogenerated question - please fill" : locQuestion.questionText),
                    ShowInReport = true
                };

                DbContext.Questions.Add(question);
                DbContext.SaveChanges();

                var binding = new FormTemplateLocalized_Question
                {
                    FormTemplateLocalizedID = localizedTemplate.Id,
                    QuestionID = question.Id,
                    QuestionOrder = questionOrder
                };
                DbContext.FormTemplateLocalized_Questions.Add(binding);

                localizedTemplate.FormTemplateLocalized_Questions.Add(binding);
                question.FormTemplateLocalized_Questions.Add(binding);

                localizedTemplate.DateModified = DateTime.Now;
                formTemplate.DateModified = DateTime.Now;
                DbContext.SaveChanges();

                rv.Add(new Tuple<int, string>(question.Id, locQuestion.langCode));
            }

            return Json(rv);
        }

        [HttpPost]
        public ActionResult BindQuestion(int questionId, int formTemplateId, string langCode)
        {
            var formTemplate = DbContext.FormTemplates.Include(ft => ft.LocalizedTemplates).FirstOrDefault(f => f.Id == formTemplateId);
            var localizedTemplate = formTemplate.LocalizedTemplates.FirstOrDefault(lt => lt.Language.LangCode == langCode);
            var question = DbContext.Questions.FirstOrDefault(q => q.Id == questionId);
            if (formTemplate == null || localizedTemplate == null || question == null)
                return HttpNotFound();

            if (localizedTemplate.FormTemplateLocalized_Questions.Any(q => q.QuestionID == questionId))
                return new HttpStatusCodeResult(System.Net.HttpStatusCode.BadRequest);

            var binding = new FormTemplateLocalized_Question
            {
                FormTemplateLocalizedID = localizedTemplate.Id,
                QuestionID = question.Id,
                QuestionOrder = localizedTemplate.FormTemplateLocalized_Questions.Count + 1
            };

            localizedTemplate.FormTemplateLocalized_Questions.Add(binding);
            question.FormTemplateLocalized_Questions.Add(binding);

            localizedTemplate.DateModified = DateTime.Now;
            formTemplate.DateModified = DateTime.Now;
            DbContext.SaveChanges();

            //TODO: Bind localized mutations?

            return new HttpStatusCodeResult(System.Net.HttpStatusCode.OK);
        }

        [HttpPost]
        public ActionResult UnbindQuestion(int questionId, int formTemplateId, string langCode)
        {
            var formTemplate = DbContext.FormTemplates.Include(ft => ft.LocalizedTemplates).FirstOrDefault(f => f.Id == formTemplateId);
            var localizedTemplate = formTemplate.LocalizedTemplates.FirstOrDefault(lt => lt.Language.LangCode == langCode);
            var question = DbContext.Questions.FirstOrDefault(q => q.Id == questionId);
            if (formTemplate == null || localizedTemplate == null || question == null)
                return HttpNotFound();

            var questionOrder = DbContext.FormTemplateLocalized_Questions.FirstOrDefault(ftq => ftq.QuestionID == questionId && ftq.FormTemplateLocalizedID == localizedTemplate.Id).QuestionOrder;
            
            /*if (!localizedTemplate.FormTemplateLocalized_Questions.Any(q => q.QuestionID == questionId))
                return new HttpStatusCodeResult(System.Net.HttpStatusCode.BadRequest);*/

            foreach (var lt in formTemplate.LocalizedTemplates)
            {
                var binding = DbContext.FormTemplateLocalized_Questions.FirstOrDefault(ftq => ftq.QuestionOrder == questionOrder && ftq.FormTemplateLocalizedID == lt.Id);
                var bindingsToUpdate = DbContext.FormTemplateLocalized_Questions.Where(ftq => ftq.QuestionOrder > binding.QuestionOrder && ftq.FormTemplateLocalizedID == lt.Id).ToList();
                foreach (var b in bindingsToUpdate)
                    b.QuestionOrder--;

                lt.FormTemplateLocalized_Questions.Remove(binding);
                question.FormTemplateLocalized_Questions.Remove(binding);
                DbContext.FormTemplateLocalized_Questions.Remove(binding);

                lt.DateModified = DateTime.Now;
                formTemplate.DateModified = DateTime.Now;
            }

            DbContext.SaveChanges();

            return new HttpStatusCodeResult(System.Net.HttpStatusCode.OK);
        }

        [HttpPost]
        public ActionResult UpdateQuestion(int questionId, string questionText)
        {
            var question = DbContext.Questions.Find(questionId);
            if (question == null)
                return new HttpStatusCodeResult(System.Net.HttpStatusCode.NotFound);

            question.QuestionText = questionText;

            DbContext.SaveChanges();
            return Json("OK");
        }

        [HttpPost]
        public ActionResult SetShowQuestionInManagerReport(int questionId, bool show)
        {
            var question = DbContext.Questions.Find(questionId);
            question.ShowInReport = show;

            DbContext.SaveChanges();

            return Json("Ok");
        }

        [HttpPost]
        public ActionResult UpdateQuestionsPositions(int formId, IEnumerable<SwapQuestionViewModel> swaps)
        {
            var formTemplate = DbContext.FormTemplates.Find(formId);
            if (formTemplate == null)
                return new HttpStatusCodeResult(System.Net.HttpStatusCode.NotFound);

            var localizedTemplatesIDs = formTemplate.LocalizedTemplates.Select(lt => lt.Id);

            var allBindings = DbContext.FormTemplateLocalized_Questions.Where(binding => localizedTemplatesIDs.Contains(binding.FormTemplateLocalizedID));

            foreach (var swap in swaps)
            {
                allBindings.Where(binding => binding.QuestionOrder == swap.originalPosition).ForEach(b => b.QuestionOrder = swap.newPosition);
            }

            DbContext.SaveChanges();

            return Json("OK");
        }
        #endregion

        private string CleanScripts(string html)
        {
            var result = HtmlSanitizer.RemoveScripts(html);
            return result;
        }
    }
}