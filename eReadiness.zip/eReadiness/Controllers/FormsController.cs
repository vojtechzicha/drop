﻿using eReadiness.DataContext.Models;
using eReadiness.Models.ViewModels;
using eReadiness.Security;
using eReadiness.Utils;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web.Mvc;

namespace eReadiness.Controllers
{
    [SecurityRoleAuthorize(SecurityRole.Disponent, SecurityRole.ProjectManager, Order = 1)]
    public class FormsController : BaseController
    {
        #region Form completition
        [SecurityRoleAuthorize(SecurityRole.Disponent, SecurityRole.ProjectManager, SecurityRole.Supplier, Order = 1)]
        public ActionResult Fill(string Id, string SelectedLangCode = null)
        {
            try
            {
                if (SelectedLangCode == null)
                    SelectedLangCode = CurrentLanguageCode.ToUpper();
                var fvm = LoadForm(Id, SelectedLangCode);
                fvm.Responses = DbContext.Responses.NotRemoved()
                    .Include(r => r.Question)
                    .Where(r => r.Form.Id == fvm.Id)
                    .OrderByDescending(r => r.DateCreated)
                    .DistinctBy(r => r.Question.Id)
                    .Select(r => new ResponseViewModel
                    {
                        Id = r.Id,
                        FormId = fvm.Id,
                        QuestionId = r.Question.Id,
                        ResponseReason = r.ResponseReason,
                        ResponseValue = r.ResponseValue,
                        QuestionOrder = r.Question.FormTemplateLocalized_Questions.FirstOrDefault().QuestionOrder
                    }).ToList();

                ViewBag.AvailableDisponents = DbContext.Disponents.NotRemoved();
                ViewBag.SelectedDisponentId = fvm.Disponent?.Id;

                return View(fvm);
            }
            catch (Exception ex)
            {
                Log.Error(ex, "FormsController.Fill");
                throw;
            }
        }
        [HttpPost]
        [SecurityRoleAuthorize(SecurityRole.Disponent, SecurityRole.ProjectManager, SecurityRole.Supplier, Order = 1)]
        public ActionResult SubmitResponses(SubmitFormViewModel data)
        {
            try
            {
                var form = DbContext.Forms
                    .Include(f => f.Project)
                    .Include(f => f.Project.FormTemplate)
                    .Include(f => f.Project.FormTemplate.LocalizedTemplates)
                    .Include(f => f.Project.FormTemplate.LocalizedTemplates.Select(lft => lft.FormTemplateLocalized_Questions))
                    .FirstOrDefault(f => f.Code == data.Code);

                if (form == null)
                    return HttpNotFound();

                form.ContactProjectManagement = data.ContactProjectManagement;
                form.ContactRepresentationOfManager = data.ContactRepresentationOfManager;
                form.ContactLogistics247 = data.ContactLogistics247;
                form.ContactQuality = data.ContactQuality;
                form.ContactEscalation = data.ContactEscalation;

                form.FilledBy = System.Web.HttpContext.Current.User.GetUserName();

                var responses = new List<Response>();
                if (data.ResponseArray != null)
                {
                    foreach (var responseModel in data.ResponseArray)
                    {
                        var question = DbContext.Questions.Find(responseModel.QuestionId);
                        if (question == null)
                            return HttpNotFound();

                        var response = new Response
                        {
                            Form = form,
                            Question = question,
                            ResponseValue = responseModel.ResponseValue,
                            ResponseReason = (responseModel.ResponseValue) ? "OK" : responseModel.ResponseReason//(previousResponse == null || previousResponse.ResponseReason == responseModel.ResponseReason) ? "OK" : responseModel.ResponseReason;
                        };
                        responses.Add(response);
                    }
                }
                if (!String.IsNullOrEmpty(data.Comment))
                {
                    var note = new Note
                    {
                        Form = form,
                        NoteText = data.Comment,
                        //CreatedBy = 
                    };
                    DbContext.Notes.Add(note);
                }

                DbContext.Responses.Where(r => r.Form.Id == form.Id).ToList().ForEach(x => { x.DateDeleted = DateTime.Now; }); //delete all previous responses

                DbContext.Responses.AddRange(responses);
                DbContext.SaveChanges();

                var okResponses = DbContext.Responses.Where(r => r.Form.Id == form.Id && r.ResponseValue);
                if (okResponses != null && okResponses.Any()) { 
                    var okCnt = okResponses.OrderByDescending(r => r.DateCreated).DistinctBy(r => r.Question.Id).Count();
                    form.Completition = (int)(((double)okCnt / (double)form.Project.FormTemplate.LocalizedTemplates.FirstOrDefault(lt => lt.Language.LangCode == data.LangCode).FormTemplateLocalized_Questions.Count()) * 100);
                    form.FormState = data.Final ? FormState.Closed : FormState.Opened;
                    form.DateFilled = DateTime.Now;
                    DbContext.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                Log.Error(ex, "FormsController.SubmitResponses");
            }
            return Json("Ok");
        }
        #endregion
        [SecurityRoleAuthorize(SecurityRole.Disponent, SecurityRole.ProjectManager, SecurityRole.Supplier, Order = 1)]
        public ActionResult Send(string Id)
        {
            try
            {
                var form = DbContext.Forms.FirstOrDefault(f => f.Code == Id);

                if (form == null)
                    return HttpNotFound();

                if (!DbContext.EmailQuery.Any(x => x.Form.Id == form.Id && x.DateSent == null))
                {
                    form.DateSent = DateTime.Now;

                    var eqe = new EmailQueryEntry();
                    eqe.Form = form;

                    DbContext.EmailQuery.Add(eqe);

                    DbContext.SaveChanges();
                }
                return new HttpStatusCodeResult(System.Net.HttpStatusCode.OK);
            }
            catch (Exception ex)
            {
                Log.Error(ex, "FormsController.Send");
                throw;
            }
        }

        [HttpPost]
        public ActionResult SendSelected(string[] ids)
        {
            try
            {
                foreach (var id in ids)
                {
                    var form = DbContext.Forms.FirstOrDefault(f => f.Code == id);

                    if (form == null)
                        return HttpNotFound();

                    if (DbContext.EmailQuery.Any(x => x.Form.Id == form.Id && x.DateSent == null))
                        continue;

                    form.DateSent = DateTime.Now;

                    var eqe = new EmailQueryEntry();
                    eqe.Form = form; 

                    DbContext.EmailQuery.Add(eqe);
                }
                DbContext.SaveChanges();

                return Json("Ok");
            }
            catch (Exception ex)
            {
                Log.Error(ex, "FormsController.Send");
                throw;
            }
        }

        [HttpPost]
        public ActionResult BindMaterial(string formCode, string materialNumber)
        {
            var form = DbContext.Forms
                .Include(f => f.Project)
                .Include(f => f.Materials)
                .FirstOrDefault(f => f.Code == formCode);

            if (form == null || form.Project == null)
                return new HttpStatusCodeResult(System.Net.HttpStatusCode.NotFound);

            var newMaterial = new Material
            {
                ManualAdded = true,
                ManualDeleted = false,
                Number = materialNumber,
                Form = form
            };
            form.Materials.Add(newMaterial);
            DbContext.Materials.Add(newMaterial);

            DbContext.SaveChanges();

            return Json("OK");
        }

        [HttpPost]
        public ActionResult SetDisponent(string formCode, int? disponentId)
        {
            var form = DbContext.Forms
                .Include(f => f.Project)
                .Include(f => f.Materials)
                .FirstOrDefault(f => f.Code == formCode);

            if (form == null || form.Project == null)
                return new HttpStatusCodeResult(System.Net.HttpStatusCode.NotFound);

            if (disponentId == null)
                DbContext.Entry<Form>(form).Reference("Disponent").CurrentValue = null;
            else
                form.Disponent = DbContext.Disponents.Find(disponentId);

            DbContext.SaveChanges();

            return Json("OK");
        }

        [HttpPost]
        public ActionResult UnbindMaterial(string formCode, string materialNumber)
        {
            try
            {
                var form = DbContext.Forms
                    .Include(f => f.Project)
                    .Include(f => f.Materials)
                    .FirstOrDefault(f => f.Code == formCode);

                if (form == null || form.Project == null)
                    return new HttpStatusCodeResult(System.Net.HttpStatusCode.NotFound);

                var material = DbContext.Materials.FirstOrDefault(m => m.Number == materialNumber && m.Form.Id == form.Id);

                material.ManualDeleted = true;

                DbContext.SaveChanges();

                return Json("OK");
            }
            catch (Exception ex)
            {
                Log.Error(ex, "FormsController.UnbindMaterial");
                throw;
            }
        }

        [HttpPost]
        public ActionResult UnlockForm(string formCode)
        {
            var form = DbContext.Forms
               .FirstOrDefault(f => f.Code == formCode);

            if (form == null)
                return new HttpStatusCodeResult(System.Net.HttpStatusCode.NotFound);

            form.FormState = FormState.Opened;

            DbContext.SaveChanges();

            return Json("OK");
        }

        public FileResult DownloadAttachment(int id)
        {
            var attachment = DbContext.EmailAttachments.FirstOrDefault(x => x.Id == id);

            if (attachment == null)
                return null;

            byte[] fileBytes = attachment.Data;
            string fileName = attachment.FileName;

            return File(fileBytes, System.Net.Mime.MediaTypeNames.Application.Octet, fileName);
        }
    }
}