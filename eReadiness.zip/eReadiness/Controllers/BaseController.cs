﻿using eReadiness.DataContext;
using eReadiness.DataContext.Models;
using eReadiness.Models.ViewModels;
using eReadiness.Security;
using eReadiness.Utils;
using Newtonsoft.Json;
using NLog;
using System;
using System.Data.Entity;
using System.Globalization;
using System.Linq;
using System.Threading;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;

namespace eReadiness.Controllers
{
    [SecurityInit]
    public class BaseController : Controller
    {
        protected static Logger Log = LogManager.GetCurrentClassLogger();

        protected ERContext DbContext = new ERContext();

        protected string CurrentLanguageCode { get; set; }

        protected override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            DbContext.SetUser(System.Web.HttpContext.Current.User.GetUserName());
            base.OnActionExecuting(filterContext);
        }

        protected override void Initialize(RequestContext requestContext)
        {
            if (requestContext.RouteData.Values["lang"] != null && requestContext.RouteData.Values["lang"] as string != "null")
            {
                CurrentLanguageCode = (string)requestContext.RouteData.Values["lang"];
                if (CurrentLanguageCode != null)
                {
                    try
                    {
                        Thread.CurrentThread.CurrentCulture = Thread.CurrentThread.CurrentUICulture = new CultureInfo(CurrentLanguageCode);
                    }
                    catch (Exception)
                    {
                        throw new NotSupportedException($"Invalid language code '{CurrentLanguageCode}'.");
                    }
                }
            }
            else
            {
                var ul = requestContext.HttpContext.Request.UserLanguages;
                if (ul != null && ul.Any())
                {
                    foreach (var l in ul)
                    {
                        var lang = l;
                        if (l.Contains("-"))
                            lang = l.Split('-')[0];
                        if (l.Contains(";"))
                            lang = l.Split(';')[0];

                        if (lang == "cs" || lang == "en" || lang == "de")
                        {
                            CurrentLanguageCode = lang;
                            Thread.CurrentThread.CurrentCulture = Thread.CurrentThread.CurrentUICulture = new CultureInfo(CurrentLanguageCode);
                            break;
                        }
                    }
                }
            }
            base.Initialize(requestContext);
        }

        protected FormViewModel LoadForm(string code, string SelectedLangCode)
        {
            Log.Debug("var form=");
            var form = DbContext.Forms
                .Include(f => f.Materials)
                .Include(f => f.Project.FormTemplate.LocalizedTemplates)
                .Include(f => f.Project.FormTemplate.LocalizedTemplates.Select(lt => lt.FormTemplateLocalized_Questions))
                .Include(f => f.Supplier.PrefferedLanguage)
                .Include(f => f.Supplier.DunsCodes)
                .Include(f => f.Disponent.Languages)
                .Include(f => f.Notes)
                .FirstOrDefault(f => f.Code == code);
            Log.Debug("var ftlq_binding =");
            var ftlq_binding = form.Project.FormTemplate.LocalizedTemplates.SelectMany(lt => lt.FormTemplateLocalized_Questions).DistinctBy(ftlq => ftlq.QuestionID).Select(ftlq => ftlq.QuestionID);
            Log.Debug("var questions =");
            var questions = DbContext.Questions.NotRemoved().Include(q => q.FormTemplateLocalized_Questions).Where(q => ftlq_binding.Contains(q.Id)).ToList();
            Log.Debug("var returnValue =");
            var returnValue = new FormViewModel
            {
                Id = form.Id,
                Code = form.Code,
                Parts = form.Materials.NotRemoved().Where(x => x.ManualDeleted == false).Select(m => m.Number).ToList(),
                FormState = form.FormState,
                Languages = form.Disponent?.Languages.Join(form.Project.FormTemplate.LocalizedTemplates.Select(lt => lt.Language), d => d.LangCode, lt => lt.LangCode, (d, lt) => d.LangCode).ToList(),
                SelectedLangCode = SelectedLangCode
            };
            Log.Debug("System.Func<LocalizedFormTemplateViewModel, bool>");
            System.Func<LocalizedFormTemplateViewModel, bool> func = lt => true;
            if (returnValue.Languages?.Count() > 0 && form.Disponent != null)
                func = lt => form.Disponent.Languages.Select(l => l.LangCode).Contains(lt.LangCode);
            else
                returnValue.Languages = form.Project.FormTemplate.LocalizedTemplates.Select(lt => lt.Language.LangCode).ToList();
            Log.Debug("returnValue.Supplier =");
            returnValue.Supplier = new SupplierViewModel
            {
                Id = form.Supplier.Id,
                Duns = form.Supplier.DunsCode,
                Name = form.Supplier.Name,
                //ContactPerson = form.Project.Supplier.ContactPerson,
                Email = form.Supplier.Email,
                LangCode = form.Supplier.PrefferedLanguage.LangCode,
                ContactProjectManagement = form.ContactProjectManagement,
                ContactRepresentationOfManager = form.ContactRepresentationOfManager,
                ContactLogistics247 = form.ContactLogistics247,
                ContactQuality = form.ContactQuality,
                ContactEscalation = form.ContactEscalation
            };
            Log.Debug("returnValue.Disponent = ");
            returnValue.Disponent = new DisponentViewModel
            {
                Id = form.Disponent?.Id,
                Name = form.Disponent?.Name,
                DispoCode = form.Disponent?.DispoCode
            };
            Log.Debug("returnValue.Project = ");

            var localizedFormTemplates = form.Project.FormTemplate.LocalizedTemplates.Select(lt => new LocalizedFormTemplateViewModel
            {
                MailBody = lt.MailBody,
                MailSubject = lt.MailSubject,
                MailBodyUrgent = lt.MailBodyUrgent,
                LangCode = lt.Language.LangCode,
                Questions = questions.Where(q => q.FormTemplateLocalized_Questions.Select(s => s.FormTemplateLocalizedID).Contains(lt.Id)).Select(q => new QuestionViewModel
                {
                    Id = q.Id,
                    QuestionText = q.QuestionText.ReplacePlaceholdersWithProjectValues(form.Project),
                    QuestionOrder = q.FormTemplateLocalized_Questions.FirstOrDefault(ftq => ftq.QuestionID == q.Id && ftq.FormTemplateLocalizedID == lt.Id).QuestionOrder
                    //QuestionOrder = q.QuestionOrder
                }).OrderBy(qvm => qvm.QuestionOrder).ToList(),
                EmailAttachments = form.Project.FormTemplate.LocalizedTemplates
                        .FirstOrDefault(x => x.Language.LangCode == (SelectedLangCode == null ? form.Supplier.PrefferedLanguage.LangCode : SelectedLangCode))?
                        .EmailAttachments.Select(e => new EmailAttachmentViewModel
                        {
                            Id = e.Id,
                            FileName = e.FileName,
                            AsAttachment = e.AsAttachment
                        })
            }).Where(func).ToList();

            returnValue.Project = new ProjectViewModel
            {
                Id = form.Project.Id,
                Name = form.Project.Name,
                FormTemplate = new FormTemplateViewModel
                {
                    Id = form.Project.FormTemplate.Id,
                    TemplateName = form.Project.FormTemplate.TemplateName,
                    LocalizedFormTemplates = localizedFormTemplates
                },
            };
            Log.Debug("returnValue.Notes = ");
            returnValue.Notes = form.Notes.Select(n => new NoteViewModel
            {
                Id = n.Id,
                NoteText = n.NoteText,
                CreatedBy = n.CreatedBy,
                DateCreated = n.DateCreated
            }).ToList();

            return returnValue;
        }

        protected FormTemplateViewModel LoadFormTemplate(int id)
        {
            var formTemplate = DbContext.FormTemplates
                .Include(ft => ft.LocalizedTemplates)
                .Include(ft => ft.LocalizedTemplates.Select(lft => lft.FormTemplateLocalized_Questions))
                .Include(ft => ft.LocalizedTemplates.Select(lft => lft.Language))
                .FirstOrDefault(ft => ft.Id == id);

            var ftlq_binding = formTemplate.LocalizedTemplates.SelectMany(lt => lt.FormTemplateLocalized_Questions).Select(ftlq => ftlq.QuestionID);
            var questions = DbContext.Questions.Include(q => q.FormTemplateLocalized_Questions).Where(q => ftlq_binding.Contains(q.Id)).ToList();

            ViewBag.Languages = DbContext.Languages.NotRemoved().ToList().Except(formTemplate.LocalizedTemplates.Select(lt => lt.Language)).ToList();

            return new FormTemplateViewModel
            {
                Id = formTemplate.Id,
                TemplateName = formTemplate.TemplateName,
                LocalizedFormTemplates = formTemplate.LocalizedTemplates.Select(lft => new LocalizedFormTemplateViewModel
                {
                    Id = lft.Id,
                    MailBody = lft.MailBody,
                    MailSubject = lft.MailSubject,
                    MailBodyUrgent = lft.MailBodyUrgent,
                    LangCode = lft.Language.LangCode,
                    EmailAttachments = lft.EmailAttachments.Select(e => new EmailAttachmentViewModel
                    {
                        Id = e.Id,
                        FileName = e.FileName,
                        AsAttachment = e.AsAttachment
                    }),
                    Questions = questions.Where(question => lft.FormTemplateLocalized_Questions.Select(b => b.QuestionID).Contains(question.Id)).Select(q => new QuestionViewModel
                    {
                        Id = q.Id,
                        QuestionText = q.QuestionText,
                        QuestionOrder = lft.FormTemplateLocalized_Questions.FirstOrDefault(b => b.QuestionID == q.Id && b.FormTemplateLocalizedID == lft.Id).QuestionOrder,
                        ShowInReport = q.ShowInReport
                    }).OrderBy(qvm => qvm.QuestionOrder)
                })
            };
        }

        //protected IQueryable<Project> GetProjects(string data)
        //{
        //    var filterModel = new FilterViewModel();
        //    if (!String.IsNullOrEmpty(data))
        //        filterModel = JsonConvert.DeserializeObject<FilterViewModel>(HttpUtility.UrlDecode(data));

        //    var projectQuery = DbContext.Projects.NotRemoved();

        //    if (filterModel.PIDs.Any())
        //        projectQuery = projectQuery.Where(x => filterModel.PIDs.Contains(x.PID.Id));
        //    if (filterModel.WERKs.Any())
        //        projectQuery = projectQuery.Where(x => filterModel.WERKs.Contains(x.WERK.Id));
        //    if (filterModel.SOP.Any())
        //        projectQuery = projectQuery.Where(x => filterModel.SOPDates.Contains(x.SOP));
        //    if (filterModel.PVS.Any())
        //        projectQuery = projectQuery.Where(x => filterModel.PVSDates.Contains(x.PVS));
        //    if (filterModel.VFF.Any())
        //        projectQuery = projectQuery.Where(x => filterModel.VFFDates.Contains(x.VFF));
        //    if (filterModel.OS.Any())
        //        projectQuery = projectQuery.Where(x => filterModel.OSDates.Contains(x.OS));

        //    return projectQuery.NotRemoved();
        //}

        protected IQueryable<Project> GetProjects(FilterParam param)
        {
            var projectQuery = DbContext.Projects.NotRemoved();

            if (param.PID != null && param.PID.Any())
                projectQuery = projectQuery.Where(x => param.PID.Contains(x.PID.Id));
            if (param.WK != null && param.WK.Any())
                projectQuery = projectQuery.Where(x => param.WK.Contains(x.WERK.Id));
            
            //if (param.SP != null && param.SP.Any())
            //    projectQuery = projectQuery.Where(x => param.SOPDates.Contains(x.SOP));
            //if (param.P != null && param.P.Any())
            //    projectQuery = projectQuery.Where(x => param.PVSDates.Contains(x.PVS));
            //if (param.V != null && param.V.Any())
            //    projectQuery = projectQuery.Where(x => param.VFFDates.Contains(x.VFF));
            //if (param.O != null && param.O.Any())
            //    projectQuery = projectQuery.Where(x => param.OSDates.Contains(x.OS));

            if ((param.P != null && param.P.Any()) || (param.V != null && param.V.Any()) || (param.O != null && param.O.Any()))
            {
                projectQuery = projectQuery.Where(x =>
                (param.PVSDates.Contains(x.PVS) && x.PVS != null) ||
                (param.VFFDates.Contains(x.VFF) && x.VFF != null) ||
                (param.OSDates.Contains(x.OS) && x.OS != null)
                );
            }

            return projectQuery.NotRemoved();
        }

        protected CarrierFormViewModel LoadCarrierForm(string code, string SelectedLangCode = null)
        {
            try
            {
                Log.Debug("LoadCarrierForm");
                var form = DbContext.CarrierForms
                    .Include(f => f.Carrier)
                    //.Include(f => f.Carrier.PrefferedLanguage)
                    //.Include(f => f.CarrierFormNotes)
                    .FirstOrDefault(f => f.Code == code);

                //var templates = DbContext.CarrierFormTemplates.FirstOrDefault(x => x.CarrierType == form.Carrier.CarrierType);
                var templates = DbContext.CarrierFormTemplates.FirstOrDefault();

                var result = new CarrierFormViewModel()
                {
                    Code = form.Code,
                    Carrier = form.Carrier,
                    FormState = form.FormState,
                    FormValues = new FormCollection(),
                    Languages = new string[] { "CS", "EN", "DE" }, //templates.LocalizedTemplates.OrderBy(x=>x.Language.Id).Select(lt => lt.Language.LangCode).ToList(),
                    SelectedLangCode = SelectedLangCode
                };

                var responses = DbContext.CarrierResponses.Where(x => x.Form.Id == form.Id).ToList();
                foreach (var response in responses)
                {
                    result.FormValues.Add(response.Question, response.Value);
                }

                return result;
            }
            catch(Exception ex)
            {
                Log.Error(ex, "FormsController.Send");
                throw;
            }
        }

        protected CarrierFormTemplateViewModel CarrierLoadFormTemplate(int id)
        {
            var formTemplate = DbContext.CarrierFormTemplates
                .Include(ft => ft.LocalizedTemplates)
                .Include(ft => ft.LocalizedTemplates.Select(lft => lft.Language))
                .FirstOrDefault(ft => ft.Id == id);

            ViewBag.Languages = DbContext.Languages.NotRemoved().ToList().Except(formTemplate.LocalizedTemplates.Select(lt => lt.Language)).ToList();

            return new CarrierFormTemplateViewModel
            {
                Id = formTemplate.Id,
                TemplateName = formTemplate.TemplateName,
                LocalizedFormTemplates = formTemplate.LocalizedTemplates.Select(lft => new CarrierLocalizedFormTemplateViewModel
                {
                    Id = lft.Id,
                    MailBody = lft.MailBody,
                    MailSubject = lft.MailSubject,
                    MailBodyUrgent = lft.MailBodyUrgent,
                    //LangCode = lft.Language.LangCode,
                    //EmailAttachments = lft.EmailAttachments.Select(e => new EmailAttachmentViewModel
                    //{
                    //    Id = e.Id,
                    //    FileName = e.FileName,
                    //    AsAttachment = e.AsAttachment
                    //})
                })
            };
        }
    }
}