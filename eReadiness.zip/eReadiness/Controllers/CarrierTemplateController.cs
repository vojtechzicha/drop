﻿using eReadiness.DataContext.Models;
using eReadiness.Models.ViewModels;
using eReadiness.Security;
using eReadiness.Utils;
using System.Linq;
using System.Web.Mvc;

namespace eReadiness.Controllers
{
    [SecurityRoleAuthorize(SecurityRole.STManager, SecurityRole.STManager, Order = 1)]
    public class CarrierTemplateController : BaseController
    {
        #region Displaying and Edit
        public ActionResult Index()
        {
            var ftvm = DbContext.CarrierFormTemplates.NotRemoved().Select(x => new CarrierFormTemplateViewModel
            {
                Id = x.Id,
                CarrierType = x.CarrierType,
                /*MailBody = ft.MailBody,
                MailSubject = ft.MailSubject,*/
                TemplateName = x.TemplateName
            });
            return View(ftvm);
        }

        public ActionResult EditTemplate(int id = -1, string langKey = "CS")
        {
            //ViewBag.EmailAttachments = DbContext.EmailAttachments.NotRemoved().Select(s => new EmailAttachmentViewModel
            //{
            //    Id = s.Id,
            //    FileName = s.FileName
            //});
            ViewBag.LangKey = langKey;

            CarrierFormTemplateViewModel formTemplate;

            if (id == -1)
            {
                var ft = new CarrierFormTemplate();
                ft.TemplateName = "Nová šablona";

                DbContext.CarrierFormTemplates.Add(ft);
                DbContext.SaveChanges();

                var lft = new CarrierFormTemplateLocalized();
                lft.CarrierFormTemplate = ft;
                //lft.Language = DbContext.Languages.FirstOrDefault(l => l.LangCode == langKey);
                //lft.EmailAttachments = new List<EmailAttachment>();

                DbContext.CarrierLocalizedTemplates.Add(lft);
                DbContext.SaveChanges();

                formTemplate = CarrierLoadFormTemplate(ft.Id);
            }
            else
            {
                formTemplate = CarrierLoadFormTemplate(id);
            }


            return View(formTemplate);
        }


        [HttpPost]
        public ActionResult UpdateTemplate(CarrierFormTemplateViewModel data)
        {
            var ft = DbContext.CarrierFormTemplates.Find(data.Id);
            if (ft == null)
                return HttpNotFound();

            ft.TemplateName = data.TemplateName;

            DbContext.SaveChanges();
            return Json("OK");
        }

        [HttpPost]
        public ActionResult UpdateLocalizedTemplate(CarrierLocalizedFormTemplateViewModel data)
        {
            var template = DbContext.CarrierFormTemplates.Find(data.Id);
            if (template == null)
                return HttpNotFound();

            //var localizedTemplate = template.LocalizedTemplates.FirstOrDefault(lt => lt.Language.LangCode == data.LangCode);
            var localizedTemplate = template.LocalizedTemplates.FirstOrDefault();

            localizedTemplate.MailBody = CleanScripts(data.MailBody);
            localizedTemplate.MailBodyUrgent = CleanScripts(data.MailBodyUrgent);
            localizedTemplate.MailSubject = data.MailSubject;

            DbContext.SaveChanges();
            return Json("OK");
        }

        //[HttpPost]
        //public ActionResult CreateLanguageMutation(int formTemplateId, int langId)
        //{
        //    var formTemplate = DbContext.CarrierFormTemplates.Find(formTemplateId);

        //    if (formTemplate == null)
        //        return new HttpStatusCodeResult(System.Net.HttpStatusCode.NotFound);

        //    var language = DbContext.Languages.Find(langId);

        //    if (language == null)
        //        return new HttpStatusCodeResult(System.Net.HttpStatusCode.NotFound);

        //    var localizedTemplate = formTemplate.LocalizedTemplates.FirstOrDefault(lft => lft.Language.Id == langId);

        //    if (localizedTemplate != null)
        //        return new HttpStatusCodeResult(System.Net.HttpStatusCode.BadRequest);

        //    localizedTemplate = new CarrierFormTemplateLocalized
        //    {
        //        Language = language,
        //        CarrierFormTemplate = formTemplate
        //    };

        //    DbContext.CarrierLocalizedTemplates.Add(localizedTemplate);
        //    DbContext.SaveChanges();

        //    return Json("OK");
        //}

        /*

[HttpPost]
public ActionResult DeleteFormTemplate(int[] ids)
{
    foreach (var id in ids)
    {
        var ft = DbContext.FormTemplates.Find(id);
        if (ft == null)
            continue;

        DbContext.FormTemplates.Remove(ft);
    }
    DbContext.SaveChanges();
    return RedirectToAction("Index");
}


#endregion

#region Attachments
[HttpPost]
public ActionResult CreateAttachment()
{
    var templateId = Int32.Parse(Request.Form["Id"]);
    var langCode = Request.Form["LangCode"];

    var template = DbContext.FormTemplates.Find(templateId);

    if (template == null)
        return HttpNotFound();

    var localizedTemplate = template.LocalizedTemplates.FirstOrDefault(lt => lt.Language.LangCode == langCode);

    var eat = new List<EmailAttachment>();
    for (int i = 0; i < Request.Files.Count; i++)
    {
        var file = Request.Files[i];
        var fileContent = file.InputStream;

        eat.Add(new EmailAttachment
        {
            FileName = file.FileName,
            LocalizedTemplates = new List<FormTemplateLocalized> { localizedTemplate },
            Data = Extensions.ReadStream(file.InputStream)
        });
    }

    DbContext.EmailAttachments.AddRange(eat);
    localizedTemplate.EmailAttachments.AddRange(eat);

    DbContext.SaveChanges();

    return Json(eat.Select(ea => new { Id = ea.Id, Name = ea.FileName }));
}

[HttpPost]
public ActionResult BindAttachment(int[] attachmentIds, int formTemplateId, string langCode)
{
    var formTemplate = DbContext.FormTemplates.Include(f => f.LocalizedTemplates).FirstOrDefault(f => f.Id == formTemplateId);
    var localizedFormTemplate = formTemplate.LocalizedTemplates.FirstOrDefault(lt => lt.Language.LangCode == langCode);
    var emailAttachments = DbContext.EmailAttachments.Where(ea => attachmentIds.Contains(ea.Id));

    if (formTemplate == null || emailAttachments == null || emailAttachments.Count() < 1)
        return HttpNotFound();

    if (localizedFormTemplate.EmailAttachments.Any(e => attachmentIds.Contains(e.Id)))
        return new HttpStatusCodeResult(System.Net.HttpStatusCode.BadRequest);

    localizedFormTemplate.EmailAttachments.AddRange(emailAttachments);
    localizedFormTemplate.DateModified = DateTime.Now;
    formTemplate.DateModified = DateTime.Now;

    DbContext.SaveChanges();
    return Json(emailAttachments.Select(ea => new { Id = ea.Id, Name = ea.FileName }));
}

[HttpPost]
public ActionResult UnbindAttachment(int attachmentId, int formTemplateId, string langCode)
{
    var formTemplate = DbContext.FormTemplates.Include(f => f.LocalizedTemplates).FirstOrDefault(f => f.Id == formTemplateId);
    var localizedTemplate = formTemplate.LocalizedTemplates.FirstOrDefault(lt => lt.Language.LangCode == langCode);
    var emailAttachment = DbContext.EmailAttachments.Find(attachmentId);

    if (formTemplate == null || localizedTemplate == null || emailAttachment == null)
        return HttpNotFound();

    if (!localizedTemplate.EmailAttachments.Any(ea => ea.Id == attachmentId))
        return new HttpStatusCodeResult(System.Net.HttpStatusCode.BadRequest);

    localizedTemplate.EmailAttachments.Remove(emailAttachment);
    localizedTemplate.DateModified = DateTime.Now;
    formTemplate.DateModified = DateTime.Now;

    DbContext.SaveChanges();

    return new HttpStatusCodeResult(System.Net.HttpStatusCode.OK);
}

[HttpPost]
public ActionResult AsAttachment(int attachmentId, bool asAttachment, int formTemplateId)
{
    var sizeLimit = 2000000;
    var emailAttachment = DbContext.EmailAttachments.Find(attachmentId);
    if (emailAttachment == null)
        return HttpNotFound();

    var formTemplate = DbContext.FormTemplates.Find(formTemplateId);

    //Count total size of files attached directly to email
    var allAttachments = formTemplate.LocalizedTemplates.SelectMany(lt => lt.EmailAttachments);
    var allInEmail = allAttachments.Where(ea => ea.AsAttachment);
    var sumSize = allInEmail.Select(ie => ie.Data).Sum(data => data.Length);

    sumSize += emailAttachment.Data.Length;

    if (sumSize > sizeLimit)
        return new HttpStatusCodeResult(System.Net.HttpStatusCode.RequestEntityTooLarge);

    emailAttachment.AsAttachment = asAttachment;
    DbContext.SaveChanges();

    //return new HttpStatusCodeResult(System.Net.HttpStatusCode.NotAcceptable, "To large");

    return new HttpStatusCodeResult(System.Net.HttpStatusCode.OK);
}
*/
        #endregion

        private string CleanScripts(string html)
        {
            var result = HtmlSanitizer.RemoveScripts(html);
            return result;
        }
    }
}