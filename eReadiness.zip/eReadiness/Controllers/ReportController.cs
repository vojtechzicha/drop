﻿using eReadiness.DataContext.Models;
using eReadiness.Models.ViewModels;
using eReadiness.Security;
using eReadiness.Utils;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace eReadiness.Controllers
{
    [SecurityRoleAuthorize(SecurityRole.Disponent, SecurityRole.ProjectManager, Order = 1)]
    public class ReportController : BaseController
    {
        /*
        public ActionResult ReportResult(string data)
        {
            try
            {
                ViewBag.Data = data;

                var projectQuery = GetProjects(data);

                var projects = projectQuery.ToList();

                var forms = DbContext.Forms.Where(x => projectQuery.Contains(x.Project));

                var responses = DbContext.Responses.NotRemoved()
                    .Include(x => x.Question)
                    .Include(x => x.Question.FormTemplateLocalized_Questions)
                    .Where(x => forms.Contains(x.Form)).ToList();


                var materialBomQuery = DbContext.MaterialBOMs.Join(
                    projectQuery,
                    s => new { s.PROD_ID, s.WK, s.SOPDATE },
                    h => new { PROD_ID = h.PID.ProjectCode, WK = h.WERK.WerkCode, SOPDATE = h.SOP },
                    (s, h) => s
                    );

                var responseCount = new Dictionary<Question, ResponseCountViewModel>();
                foreach(var response in responses)
                {
                    var formTemplateLocalized_Question = 
                        response.Question.FormTemplateLocalized_Questions
                        .FirstOrDefault(x=>x.LocalizedForm.Language.LangCode.ToUpper() == CurrentLanguageCode.ToUpper());
                    if (formTemplateLocalized_Question == null)
                        formTemplateLocalized_Question = response.Question.FormTemplateLocalized_Questions.FirstOrDefault();
                    var questionOrder = formTemplateLocalized_Question.QuestionOrder;
                    var question = formTemplateLocalized_Question.Question;
                    if (!responseCount.ContainsKey(question))
                        responseCount.Add(question, new ResponseCountViewModel()
                        {
                            QuestionText = formTemplateLocalized_Question.Question.QuestionText.ReplacePlaceholdersWithProjectValues(response.Form.Project)
                        });
                    if (response.ResponseValue)
                        responseCount[question].Yes++;
                    else
                        responseCount[question].No++;
                }

                var before5Day = DateTime.Now.AddDays(-5);
                var formsList = forms.ToList();

                var reportResult = new ReportViewModel
                {
                    BRelease = materialBomQuery.Where(x => x.NOTB == true).Count(),
                    Fakom = materialBomQuery.Where(x => x.NOTCOLOR == true).Count(),
                    FormNotReturnedIn5Days = formsList.Where(x => x.FormState == FormState.Sent && x.DateSent < before5Day).Count(),
                    FormReturnedOK = formsList.Where(x => x.FormState == FormState.Closed && x.CompleteOk).Count(),
                    NotSent = formsList.Where(x => x.FormState == FormState.Ready).Count(),
                    OS = string.Join(", ", projects.Where(x => x.OS != null).Select(x => x.OS?.ToKT())),
                    PVS = string.Join(", ", projects.Where(x => x.PVS != null).Select(x => x.PVS?.ToKT())),
                    SentForms = formsList.Where(x => x.FormState == FormState.Sent || x.FormState == FormState.Opened).Count(),
                    SOP = string.Join(", ", projects.Select(x => x.SOP.ToKT())),
                    TotalParts = materialBomQuery.Count(),
                    VFF = string.Join(", ", projects.Where(x => x.VFF != null).Select(x => x.VFF?.ToKT())),
                    WithSupplier = formsList.SelectMany(x => x.Materials.Where(y => y.DateDeleted == null && y.ManualDeleted != true)).Count(),
                    ProjectNames = projects.Select(x => x.Name).ToList(),
                    ResponseCounts = responseCount.Values.ToList(),
                    Returned = formsList.Where(x => x.FormState == FormState.Closed).Count(),
                    WithoutDisponent = formsList.Where(x => x.Disponent == null).Count(),
                    MissingSupplier = 
                    materialBomQuery.Count() - formsList.SelectMany(x => x.Materials.Where(y => y.DateDeleted == null && y.ManualDeleted != true)).Count()
                };
                return View(reportResult);
            }
            catch (Exception ex)
            {
                Log.Error(ex, "ReportResult.ReportResult");
                throw;
            }
        }
        */

        public ActionResult ReportResult(FilterParam param)
        {
            try
            {
                var projectQuery = GetProjects(param);

                var projects = projectQuery.ToList();

                var forms = DbContext.Forms.Where(x => projectQuery.Contains(x.Project) && (
                (param.PVSDates.Contains(x.Project.PVS) && x.MilestoneType == MilestoneType.PVS) ||
                    (param.VFFDates.Contains(x.Project.VFF) && x.MilestoneType == MilestoneType.VFF) ||
                    (param.OSDates.Contains(x.Project.OS) && x.MilestoneType == MilestoneType.S0)
                ));

                var responses = DbContext.Responses.NotRemoved()
                    .Include(x => x.Question)
                    .Include(x => x.Question.FormTemplateLocalized_Questions)
                    .Where(x=>x.Question.ShowInReport == true)
                    .Where(x => forms.Contains(x.Form) && x.Form.FormState == FormState.Closed).ToList();


                var materialBomQuery = DbContext.MaterialBOMs.Join(
                    projectQuery,
                    s => new { s.PROD_ID, s.WK, s.SOPDATE },
                    h => new { PROD_ID = h.PID.ProjectCode, WK = h.WERK.WerkCode, SOPDATE = h.SOP },
                    (s, h) => s
                    ).ToList();

                var withSuppMaterial = forms
                    .SelectMany(x => x.Materials.Where(y => y.DateDeleted == null && y.ManualDeleted != true))
                    .Include(x => x.Form)
                    .Include(x => x.Form.Project)
                    .Include(x => x.Form.Project.PID)
                    .Include(x => x.Form.Project.WERK)
                    .ToList();

                var missingMaterial = new List<NumberNameViewModel>();

                foreach (var materialBom in materialBomQuery)
                {
                    var s = withSuppMaterial
                        .FirstOrDefault(
                            x => x.Number == materialBom.TEIL_NR &&
                            x?.Form?.Project?.PID?.ProjectCode == materialBom.PROD_ID &&
                            x?.Form?.Project?.WERK?.WerkCode == materialBom.WK &&
                            x?.Form?.Project?.SOP == materialBom.SOPDATE);
                    if (s == null)
                        missingMaterial.Add(new NumberNameViewModel() { Number = materialBom.TEIL_NR, Name = materialBom.BEN });
                }

                var responseCount = new Dictionary<string, ResponseCountViewModel>();
                foreach (var response in responses)
                {
                    var template = response.Form.Project.FormTemplate;
                    var formTemplateLocalized_Question =
                        response.Question.FormTemplateLocalized_Questions
                        .FirstOrDefault(x => x.LocalizedForm.Language.LangCode.ToUpper() == CurrentLanguageCode.ToUpper());
                    if (formTemplateLocalized_Question == null)
                        formTemplateLocalized_Question = response.Question.FormTemplateLocalized_Questions.FirstOrDefault();
                    var questionOrder = formTemplateLocalized_Question.QuestionOrder;
                    var question = formTemplateLocalized_Question.Question;
                    var templateIdQuestionOrder = string.Format("{0}-{1}", template.Id, questionOrder);
                    //if (!responseCount.ContainsKey(question))
                    //    responseCount.Add(question, new ResponseCountViewModel()
                    //    {
                    //        QuestionText = formTemplateLocalized_Question.Question.QuestionText.ReplacePlaceholdersWithProjectValues(response.Form.Project),
                    //        QuestionOrder = questionOrder,
                    //        Template = formTemplateLocalized_Question.LocalizedForm.ParentTemplate.Id
                    //    });
                    //if (response.ResponseValue)
                    //    responseCount[question].Yes++;
                    //else
                    //    responseCount[question].No++;
                    var localizedTemplate = template.LocalizedTemplates.FirstOrDefault(x => x.Language.LangCode.ToUpper() == CurrentLanguageCode.ToUpper());
                    var questionText = localizedTemplate?.FormTemplateLocalized_Questions.FirstOrDefault(x => x.QuestionOrder == questionOrder)?.Question?.QuestionText;
                    if (!responseCount.ContainsKey(templateIdQuestionOrder))
                        responseCount.Add(templateIdQuestionOrder, new ResponseCountViewModel()
                        {
                            QuestionText = (questionText != null) ? questionText : formTemplateLocalized_Question.Question.QuestionText.ReplacePlaceholdersWithProjectValues(response.Form.Project),
                            QuestionOrder = questionOrder,
                            Template = formTemplateLocalized_Question.LocalizedForm.ParentTemplate.Id
                        });
                    if (response.ResponseValue)
                        responseCount[templateIdQuestionOrder].Yes++;
                    else
                        responseCount[templateIdQuestionOrder].No++;
                }

                var before5Day = DateTime.Now.AddDays(-5);
                var formsList = forms.ToList();

                var reportResult = new ReportViewModel
                {
                    BRelease = materialBomQuery.Where(x => x.NOTB == true).DistinctBy(x=>x.TEIL_NR).Count(),
                    Fakom = materialBomQuery.Where(x => x.NOTCOLOR == true).DistinctBy(x => x.TEIL_NR).Count(),
                    FormNotReturnedIn5Days = formsList.Where(x => x.FormState == FormState.Sent && x.DateSent < before5Day).Count(),
                    FormReturnedOK = formsList.Where(x => x.FormState == FormState.Closed && x.CompleteOk).Count(),
                    NotSent = formsList.Where(x => x.FormState == FormState.Ready).Count(),
                    OS = string.Join(", ", projects.Where(x => param.OSDates.Contains(x.OS)).Where(x => x.OS != null).Select(x => x.OS?.ToKT())),
                    PVS = string.Join(", ", projects.Where(x=>param.PVSDates.Contains(x.PVS)).Where(x => x.PVS != null).Select(x => x.PVS?.ToKT())),
                    SentForms = formsList.Where(x => x.FormState == FormState.Sent || x.FormState == FormState.Opened).Count(),
                    SOP = string.Join(", ", projects.Select(x => x.SOP.ToKT())),
                    VFF = string.Join(", ", projects.Where(x => param.VFFDates.Contains(x.VFF)).Where(x => x.VFF != null).Select(x => x.VFF?.ToKT())),
                    TotalParts = materialBomQuery.DistinctBy(x => x.TEIL_NR).Count(),
                    WithSupplier = withSuppMaterial.DistinctBy(x => x.Number).Select(x => new NumberNameViewModel() { Number = x.Number, Name = x.Name }).Count(),
                    MissingSupplier = missingMaterial.Distinct().Count(),
                    ProjectNames = projects.Select(x => x.Name).ToList(),
                    ResponseCounts = responseCount.Values.OrderBy(x=>x.QuestionOrder).ToList(),
                    Returned = formsList.Where(x => x.FormState == FormState.Closed).Count(),
                    WithoutDisponent = formsList.Where(x => x.Disponent == null).Count(),
                    Werks = string.Join(", ", projects?.Select(x => x.WERK.Name).Distinct())
                };
                return View(reportResult);
            }
            catch (Exception ex)
            {
                Log.Error(ex, "ReportResult.ReportResult");
                return View(new ReportViewModel());
            }
        }
    }
}