﻿using eReadiness.DataContext.Models;
using eReadiness.Security;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace eReadiness.Controllers
{
    [SecurityRoleAuthorize(SecurityRole.STManager, SecurityRole.STManager, SecurityRole.STCarrier, Order = 1)]
    public class CarrierFormsController : BaseController
    {
        [SecurityRoleAuthorize(SecurityRole.STManager, SecurityRole.STManager, Order = 1)]
        // GET: CarrierForms
        public ActionResult Index()
        {
            return View(DbContext.CarrierForms.OrderByDescending(x => x.Id).ToList());
        }

        [SecurityRoleAuthorize(SecurityRole.STManager, SecurityRole.STManager, SecurityRole.STCarrier, Order = 1)]
        public ActionResult Fill(string Id, string SelectedLangCode = null)
        {
            var model = LoadCarrierForm(Id, SelectedLangCode);

            return View(model);
        }

        [SecurityRoleAuthorize(SecurityRole.STManager, SecurityRole.STManager, SecurityRole.STCarrier, Order = 1)]
        [HttpPost]
        public ActionResult SubmitResponses(FormCollection collection)
        {
            var form = SaveResponses(collection);

            if (form == null)
                return HttpNotFound();

            DbContext.SaveChanges();
            return View("Fill", LoadCarrierForm(form.Code));
        }

        [SecurityRoleAuthorize(SecurityRole.STManager, SecurityRole.STManager, SecurityRole.STCarrier, Order = 1)]
        [HttpPost]
        public ActionResult SubmitFinal(FormCollection collection)
        {
            var form = SaveResponses(collection);

            if (form == null)
                return HttpNotFound();

            form.FormState = FormState.Closed;
            form.ValidUntil = DateTime.Now.AddYears(1);

            DbContext.SaveChanges();
            return View("Fill", LoadCarrierForm(form.Code));
        }

        private CarrierForm SaveResponses(FormCollection collection)
        {
            var code = collection["Code"];
            var form = DbContext.CarrierForms.FirstOrDefault(f => f.Code == code);

            if (form == null)
                return null;

            var responses = DbContext.CarrierResponses.Where(x => x.Form.Id == form.Id).ToList();

            foreach (var item in collection.AllKeys)
            {
                //if (string.IsNullOrEmpty(collection[item]))
                //    continue;
                var response = responses.FirstOrDefault(x => x.Question == item);
                if (response != null)
                    response.Value = collection[item];
                else
                {
                    response = new CarrierResponse()
                    {
                        Form = form,
                        Question = item,
                        Value = collection[item]
                    };
                    DbContext.CarrierResponses.Add(response);
                    responses.Add(response);
                }
            }
            form.FormState = FormState.Opened;
            form.DateFilled = DateTime.Now;
            form.FilledBy = DbContext.UserName;

            return form;
        }

        [SecurityRoleAuthorize(SecurityRole.STManager, SecurityRole.STManager, Order = 1)]
        public ActionResult Send(string Id)
        {
            try
            {
                var form = DbContext.CarrierForms.FirstOrDefault(f => f.Code == Id);

                if (form == null)
                    return HttpNotFound();

                if (!DbContext.CarrierEmailQuery.Any(x => x.CarrierForm.Id == form.Id && x.DateSent == null))
                {
                    form.DateSent = DateTime.Now;

                    var ceqe = new CarrierEmailQueryEntry();
                    ceqe.CarrierForm = form;

                    DbContext.CarrierEmailQuery.Add(ceqe);

                    DbContext.SaveChanges();
                }
                return new HttpStatusCodeResult(System.Net.HttpStatusCode.OK);
            }
            catch (Exception ex)
            {
                Log.Error(ex, "FormsController.Send");
                throw;
            }
        }

        [SecurityRoleAuthorize(SecurityRole.STManager, SecurityRole.STManager, Order = 1)]
        [HttpPost]
        public ActionResult SendSelected(string[] ids)
        {
            try
            {
                if (ids != null)
                {
                    foreach (var id in ids)
                    {
                        var form = DbContext.CarrierForms.FirstOrDefault(f => f.Code == id);

                        if (form == null)
                            return HttpNotFound();

                        if (DbContext.CarrierEmailQuery.Any(x => x.CarrierForm.Id == form.Id && x.DateSent == null))
                            continue;

                        form.DateSent = DateTime.Now;

                        var eqe = new CarrierEmailQueryEntry();
                        eqe.CarrierForm = form;

                        DbContext.CarrierEmailQuery.Add(eqe);
                    }
                    DbContext.SaveChanges();
                }
                return Json("Ok");
            }
            catch (Exception ex)
            {
                Log.Error(ex, "CarrierFormsController.SendSelected");
                throw;
            }
        }


        [HttpPost]
        public ActionResult UnlockForm(string code)
        {
            var form = DbContext.CarrierForms.FirstOrDefault(f => f.Code == code);

            if (form == null)
                return new HttpStatusCodeResult(System.Net.HttpStatusCode.NotFound);

            form.FormState = FormState.Opened;

            DbContext.SaveChanges();

            var model = LoadCarrierForm(code);

            return View("Fill", model);
        }
    }
}