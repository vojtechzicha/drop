﻿using eReadiness.DataContext.Models;
using eReadiness.Models.ViewModels;
using eReadiness.Security;
using eReadiness.Utils;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web.Mvc;

namespace eReadiness.Controllers
{
    [SecurityRoleAuthorize(SecurityRole.ProjectManager, Order = 1)]
    public class ControlTableController : BaseController
    {
        public ActionResult Index()
        {
            return View();
        }
        
        #region PID
        public ActionResult Pids()
        {
            return View(DbContext.PIDs.NotRemoved().OrderBy(x => x.Id));
        }
        [HttpPost]
        public ActionResult CreatePid(PIDsViewModel model)
        {
            if (!String.IsNullOrEmpty(model.ProjectCode) && !String.IsNullOrEmpty(model.Name))
            {
                DbContext.PIDs.Add(new PID
                {
                    ProjectCode = model.ProjectCode,
                    Name = model.Name,
                    Type = model.Type
                });

                DbContext.SaveChanges();
                return Json("Ok");
            }
            else
                return new HttpStatusCodeResult(System.Net.HttpStatusCode.NotAcceptable);
        }
        [HttpPost]
        public ActionResult UpdatePid(PIDsViewModel model)
        {
            if (!String.IsNullOrEmpty(model.ProjectCode) && !String.IsNullOrEmpty(model.Name))
            {
                var old = DbContext.PIDs.Find(model.Id);
                old.ProjectCode = model.ProjectCode;
                old.Name = model.Name;
                old.Type = model.Type;
                DbContext.SaveChanges();

                return Json("Ok");
            }
            else
                return new HttpStatusCodeResult(System.Net.HttpStatusCode.NotAcceptable);
        }
        [HttpPost]
        public ActionResult DeletePid(int[] ids)
        {
            foreach (var id in ids)
            {
                var old = DbContext.PIDs.Find(id);
                DbContext.PIDs.Remove(old);
            }

            DbContext.SaveChanges();

            return Json("Ok");
        }
        #endregion

        #region WERK
        public ActionResult Werks()
        {
            return View(DbContext.WERKs.NotRemoved().OrderBy(x => x.Id));
        }
        [HttpPost]
        public ActionResult CreateWerk(WERKViewModel model)
        {
            if (!String.IsNullOrEmpty(model.WerkCode) && !String.IsNullOrEmpty(model.Name))
            {
                DbContext.WERKs.Add(new WERK
                {
                    WerkCode = model.WerkCode,
                    Name = model.Name
                });

                DbContext.SaveChanges();

                return Json("Ok");
            }
            else
                return new HttpStatusCodeResult(System.Net.HttpStatusCode.NotAcceptable);
        }
        [HttpPost]
        public ActionResult UpdateWerk(WERKViewModel model)
        {
            if (!String.IsNullOrEmpty(model.WerkCode) && !String.IsNullOrEmpty(model.Name))
            {
                var old = DbContext.WERKs.Find(model.Id);
                old.Name = model.Name;
                old.WerkCode = model.WerkCode;
                DbContext.SaveChanges();

                return Json("Ok");
            }
            else
                return new HttpStatusCodeResult(System.Net.HttpStatusCode.NotAcceptable);
        }
        [HttpPost]
        public ActionResult DeleteWerk(int[] ids)
        {
            foreach(var id in ids)
            {
                var old = DbContext.WERKs.Find(id);
                DbContext.WERKs.Remove(old);
            }
            DbContext.SaveChanges();

            return Json("Ok");
        }
        #endregion

        #region Project
        public ActionResult Projects()
        {
            ViewBag.PIDs = DbContext.PIDs.NotRemoved().ToList();
            ViewBag.WERKs = DbContext.WERKs.NotRemoved().ToList();
            ViewBag.FormTemplates = DbContext.FormTemplates.NotRemoved().ToList();

            return View(DbContext.Projects.NotRemoved().Include(p => p.WERK).Include(p => p.PID).Include(p => p.FormTemplate).OrderBy(x => x.Id));
        }
        [HttpPost]
        public ActionResult CreateProject(CUProjectViewModel model)
        {
            var pid = DbContext.PIDs.Find(model.PID);
            var werk = DbContext.WERKs.Find(model.WERK);
            var formTemplate = DbContext.FormTemplates.Find(model.FormTemplate);

            if (pid == null || werk == null || formTemplate == null)
                return new HttpStatusCodeResult(System.Net.HttpStatusCode.NotFound);

            if (!String.IsNullOrEmpty(model.Name) && !String.IsNullOrEmpty(model.SOP))
            {
                try
                {
                    var sop = model.SOP.FromKT();
                    if (sop.HasValue)
                    {
                        var project = new Project
                        {
                            PID = pid,
                            WERK = werk,
                            FormTemplate = formTemplate,
                            Name = model.Name,
                            SOP = sop.Value,//(model.SOP.FromKT() != null) ? model.SOP.FromKT().Value : DateTime.MinValue,
                            PVS = model.PVS.FromKT(),
                            VFF = model.VFF.FromKT(),
                            OS = model.OS.FromKT()
                        };

                        DbContext.Projects.Add(project);
                        DbContext.SaveChanges();

                        return Json("OK");
                    }
                    else
                    {
                        return new HttpStatusCodeResult(System.Net.HttpStatusCode.NotAcceptable);
                    }
                }
                catch (KTParseException e)
                {
                    return new HttpStatusCodeResult(System.Net.HttpStatusCode.NotAcceptable);
                }
            }
            else
                return new HttpStatusCodeResult(System.Net.HttpStatusCode.NotAcceptable);
        }
        [HttpPost]
        public ActionResult UpdateProject(CUProjectViewModel model)
        {
            var project = DbContext.Projects.Find(model.Id);

            if (project == null)
                return new HttpStatusCodeResult(System.Net.HttpStatusCode.NotFound);

            var pid = DbContext.PIDs.Find(model.PID);
            var werk = DbContext.WERKs.Find(model.WERK);
            var formTemplate = DbContext.FormTemplates.Find(model.FormTemplate);

            if (pid == null || werk == null || formTemplate == null)
                return new HttpStatusCodeResult(System.Net.HttpStatusCode.NotFound);

            if (!String.IsNullOrEmpty(model.Name) && !String.IsNullOrEmpty(model.SOP))
            {
                try
                {
                    var sop = model.SOP.FromKT();
                    if (sop.HasValue)
                    {
                        project.PID = pid;
                        project.WERK = werk;
                        project.FormTemplate = formTemplate;
                        project.Name = model.Name;
                        project.SOP = sop.Value;
                        project.PVS = model.PVS.FromKT();
                        project.VFF = model.VFF.FromKT();
                        project.OS = model.OS.FromKT();

                        DbContext.SaveChanges();

                        return Json("OK");
                    }
                    else
                        return new HttpStatusCodeResult(System.Net.HttpStatusCode.NotAcceptable);
                }
                catch (KTParseException e)
                {
                    return new HttpStatusCodeResult(System.Net.HttpStatusCode.NotAcceptable);
                }
            }
            else
                return new HttpStatusCodeResult(System.Net.HttpStatusCode.NotAcceptable);
        }
        [HttpPost]
        public ActionResult DeleteProject(int[] ids)
        {
            foreach (var id in ids)
            {
                var old = DbContext.Projects.Find(id);
                DbContext.Projects.Remove(old);
            }
            DbContext.SaveChanges();

            return Json("Ok");
        }
        #endregion

        #region Supplier
        [SecurityRoleAuthorize(SecurityRole.Disponent, SecurityRole.ProjectManager, Order = 1)]
        public ActionResult Suppliers()
        {
            ViewBag.AvailableDisponents = DbContext.Disponents.NotRemoved();
            return View(DbContext.Suppliers.NotRemoved().Include(s => s.DunsCodes).Include(s => s.SupplierContacts.Select(se => se.Disponent)));
        }

        [SecurityRoleAuthorize(SecurityRole.Disponent, SecurityRole.ProjectManager, Order = 1)]
        [HttpPost]
        public ActionResult CreateSupplier(SupplierViewModel model)
        {
            if (!String.IsNullOrEmpty(model.Duns) && !String.IsNullOrEmpty(model.Name) && !String.IsNullOrEmpty(model.Email))
            {
                var supp = new Supplier
                {
                    //DunsCode = model.Duns,
                    Name = model.Name,
                    Email = model.Email,
                    SupplierContacts = new List<SupplierContacts>(),
                    //ContactPerson = model.ContactPerson
                    PrefferedLanguage = DbContext.Languages.FirstOrDefault() //PrefferedLanguage - k cemu je? Pohrobek?
                };
                DbContext.Suppliers.Add(supp);

                if (!String.IsNullOrEmpty(model.Contactemails))
                {
                    /*try
                    {*/
                        var eArr = model.Contactemails.TrimEnd(',').Split(',');

                        foreach (var pair in eArr)
                        {
                            if (!String.IsNullOrEmpty(pair))
                            {
                                var discode = pair.Split('/')[0];
                                var email = pair.Split('/')[1];

                                var ce = new SupplierContacts
                                {
                                    Disponent = DbContext.Disponents.FirstOrDefault(d => d.DispoCode == discode),
                                    Email = email
                                };

                                DbContext.SupplierContacts.Add(ce);
                                supp.SupplierContacts.Add(ce);
                            }
                        }
                    /*}
                    catch (Exception) { }*/
                }
                DbContext.SaveChanges();
                return Json("Ok");
            }
            else
                return new HttpStatusCodeResult(System.Net.HttpStatusCode.NotAcceptable);
        }

        [SecurityRoleAuthorize(SecurityRole.Disponent, SecurityRole.ProjectManager, Order = 1)]
        [HttpPost]
        public ActionResult UpdateSupplier(SupplierViewModel model)
        {
            if (!String.IsNullOrEmpty(model.Duns) && !String.IsNullOrEmpty(model.Name) && !String.IsNullOrEmpty(model.Email))
            {
                var old = DbContext.Suppliers.Find(model.Id);

                if (old == null)
                    return new HttpStatusCodeResult(System.Net.HttpStatusCode.NotFound);

                old.Name = model.Name;
                old.Email = model.Email;
                //old.ContactPerson = model.ContactPerson;
                //old.DunsCode = model.Duns;

                var dunsList = model.Duns.Split('\n', ' ').Where(x=>!string.IsNullOrWhiteSpace(x)).ToList();
                var toDelete = old.DunsCodes.Where(x => !dunsList.Contains(x.DunsCode)).ToList();
                toDelete.ForEach(x => 
                {
                    old.DunsCodes.Remove(x);
                    DbContext.SupplierDuns.Remove(x);
                });
                foreach (var duns in dunsList)
                {
                    if (duns.Length != 9)
                        return new HttpStatusCodeResult(System.Net.HttpStatusCode.NotAcceptable,"Duns must be 9");
                    if (!old.DunsCodes.Any(x => x.DunsCode == duns))
                        old.DunsCodes.Add(new SupplierDuns() { DunsCode = duns });
                }

                if (!String.IsNullOrEmpty(model.Contactemails))
                {
                    /*try
                    {*/
                        var eArr = model.Contactemails.TrimEnd(',').Split(',');
                        old.SupplierContacts.Clear();

                        foreach (var pair in eArr)
                        {
                            var discode = pair.Split('/')[0];
                            var email = pair.Split('/')[1];

                            var ce = new SupplierContacts
                            {
                                Disponent = DbContext.Disponents.FirstOrDefault(d => d.DispoCode == discode),
                                Email = email
                            };

                            /*if (old.SupplierContacts.Any(c => c.Disponent == ce.Disponent && c.Email == ce.Email))
                                continue;*/

                            DbContext.SupplierContacts.Add(ce);
                            old.SupplierContacts.Add(ce);
                        }
                    /*}
                    catch (Exception e)
                    {
                        var v = e.Message;
                    }*/
                }

                DbContext.SaveChanges();

                return Json("Ok");
            }
            else
                return new HttpStatusCodeResult(System.Net.HttpStatusCode.NotAcceptable);
        }

        [SecurityRoleAuthorize(SecurityRole.Disponent, SecurityRole.ProjectManager, Order = 1)]
        [HttpPost]
        public ActionResult DeleteSupplier(int[] ids)
        {
            foreach(var id in ids)
            {
                var old = DbContext.Suppliers.Find(id);
                DbContext.Suppliers.Remove(old);
            }
            DbContext.SaveChanges();

            return Json("Ok");
        }
        #endregion

        #region Disponent
        public ActionResult Disponents()
        {
            ViewBag.Languages = DbContext.Languages.NotRemoved();
            return View(DbContext.Disponents.NotRemoved().Include(d => d.Languages));
        }
        [HttpPost]
        public ActionResult CreateDisponent(DisponentViewModel model)
        {
            if (!String.IsNullOrEmpty(model.DispoCode) && !String.IsNullOrEmpty(model.Name))
            {
                var disponent = new Disponent
                {
                    DispoCode = model.DispoCode,
                    Name = model.Name
                };
                DbContext.Disponents.Add(disponent);

                disponent.Languages = new List<Language>();

                if (model.Languages != null && model.Languages.Any())
                {
                    foreach (var langCode in model.Languages.Split('-').Where(s => !String.IsNullOrEmpty(s)))
                    {
                        var langEntity = DbContext.Languages.FirstOrDefault(l => l.LangCode == langCode);
                        if (langEntity != null)
                            disponent.Languages.Add(langEntity);
                    }
                }

                DbContext.SaveChanges();
                return Json("Ok");
            }
            else
                return new HttpStatusCodeResult(System.Net.HttpStatusCode.NotAcceptable);
        }
        [HttpPost]
        public ActionResult UpdateDisponent(DisponentViewModel model)
        {
            if (!String.IsNullOrEmpty(model.DispoCode) && !String.IsNullOrEmpty(model.Name))
            {
                var old = DbContext.Disponents.Find(model.Id);

                if (old == null)
                    return new HttpStatusCodeResult(System.Net.HttpStatusCode.NotFound);

                old.Name = model.Name;
                old.DispoCode = model.DispoCode;

                old.Languages.Clear();

                if (model.Languages.Any())
                {
                    foreach (var langCode in model.Languages.Split('-').Where(s => !String.IsNullOrEmpty(s)))
                    {
                        var langEntity = DbContext.Languages.FirstOrDefault(l => l.LangCode == langCode);
                        if (langEntity != null)
                            old.Languages.Add(langEntity);
                    }
                }

                DbContext.SaveChanges();

                return Json("Ok");
            }
            else
                return new HttpStatusCodeResult(System.Net.HttpStatusCode.NotAcceptable);
        }
        [HttpPost]
        public ActionResult DeleteDisponent(int[] ids)
        {
            if (DbContext.Forms.Any(f => ids.Contains(f.Disponent.Id) && f.FormState != FormState.Closed))
                return new HttpStatusCodeResult(System.Net.HttpStatusCode.Conflict);

            foreach (var id in ids)
            {
                var old = DbContext.Disponents.Find(id);
                DbContext.Disponents.Remove(old);
            }
            DbContext.SaveChanges();

            return Json("Ok");
        }
        #endregion

        #region Language
        public ActionResult Languages()
        {
            return View(DbContext.Languages.NotRemoved());
        }
        [HttpPost]
        public ActionResult CreateLanguage(string languageCode)
        {
            if (!String.IsNullOrEmpty(languageCode))
            {
                DbContext.Languages.Add(new Language
                {
                    LangCode = languageCode
                });

                DbContext.SaveChanges();
                return Json("Ok");
            }
            else
                return new HttpStatusCodeResult(System.Net.HttpStatusCode.NotAcceptable);
        }
        [HttpPost]
        public ActionResult UpdateLanguage(int Id, string languageCode)
        {
            if (!String.IsNullOrEmpty(languageCode))
            {
                var old = DbContext.Languages.Find(Id);
                if (old == null)
                    return new HttpStatusCodeResult(System.Net.HttpStatusCode.NotFound);

                old.LangCode = languageCode;

                DbContext.SaveChanges();

                return Json("Ok");
            }
            else
                return new HttpStatusCodeResult(System.Net.HttpStatusCode.NotAcceptable);
        }
        [HttpPost]
        public ActionResult DeleteLanguage(int[] ids)
        {
            foreach (var id in ids)
            {
                var old = DbContext.Languages.Find(id);
                DbContext.Languages.Remove(old);
            }
            DbContext.SaveChanges();

            return Json("Ok");
        }
        #endregion

        #region Carriers
        [SecurityRoleAuthorize(SecurityRole.STManager, SecurityRole.STSpecialist, Order = 1)]
        public ActionResult Carriers()
        {
            return View(DbContext.Carriers.NotRemoved());
        }

        [SecurityRoleAuthorize(SecurityRole.STManager, SecurityRole.STSpecialist, Order = 1)]
        [HttpPost]
        public ActionResult UpdateCarrier(CarrierViewModel model)
        {
            if (!String.IsNullOrEmpty(model.Name) && !String.IsNullOrEmpty(model.Email))
            {
                var old = DbContext.Carriers.Find(model.Id);

                if (old == null)
                    return new HttpStatusCodeResult(System.Net.HttpStatusCode.NotFound);

                old.Name = model.Name;
                old.Email = model.Email;
                old.DunsCode = model.DunsCode;
                old.Address = model.Address;
                old.SAP = model.SAP;
                old.CarrierType = model.CarrierType;

                DbContext.SaveChanges();

                return Json("Ok");
            }
            else
                return new HttpStatusCodeResult(System.Net.HttpStatusCode.NotAcceptable);
        }

        [SecurityRoleAuthorize(SecurityRole.STManager, SecurityRole.STSpecialist, Order = 1)]
        [HttpPost]
        public ActionResult CreateCarrier(CarrierViewModel model)
        {
            if (!String.IsNullOrEmpty(model.Name) && !String.IsNullOrEmpty(model.Email))
            {
                var carrier = new Carrier
                {
                    Name = model.Name,
                    Email = model.Email,
                    DunsCode = model.DunsCode,
                    Address = model.Address,
                    SAP = model.SAP,
                    CarrierType = model.CarrierType
                };
                DbContext.Carriers.Add(carrier);
                DbContext.CreateCarrierForm(carrier);

                DbContext.SaveChanges();
                return Json("Ok");
            }
            else
                return new HttpStatusCodeResult(System.Net.HttpStatusCode.NotAcceptable);
        }


        [SecurityRoleAuthorize(SecurityRole.STManager, SecurityRole.STSpecialist, Order = 1)]
        [HttpPost]
        public ActionResult DeleteCarrier(int[] ids)
        {
            foreach (var id in ids)
            {
                var old = DbContext.Carriers.Find(id);
                DbContext.Carriers.Remove(old);
            }
            DbContext.SaveChanges();

            return Json("Ok");
        }
        #endregion
    }
}