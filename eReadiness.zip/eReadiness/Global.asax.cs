﻿using NLog;
using System;
using System.Collections.Generic;
using System.Data.Entity.Migrations;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Optimization;
using System.Web.Routing;

namespace eReadiness
{
    public class MvcApplication : System.Web.HttpApplication
    {
        protected static Logger Log = LogManager.GetCurrentClassLogger();

        protected void Application_Start()
        {
            AreaRegistration.RegisterAllAreas();
            FilterConfig.RegisterGlobalFilters(GlobalFilters.Filters);
            RouteConfig.RegisterRoutes(RouteTable.Routes);
            BundleConfig.RegisterBundles(BundleTable.Bundles);

            /*var config = new Migrations.Configuration();
            var migrator = new DbMigrator(config);
            migrator.Update();*/
        }

        protected void Application_Error()
        {
            var ex = Server.GetLastError();
            Log.Error(ex);
        }
    }
}
