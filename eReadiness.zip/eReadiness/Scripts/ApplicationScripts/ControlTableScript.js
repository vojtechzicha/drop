﻿$(document).ready(function () {
    $("#control_result").DataTable({
        "paging": false,
        "oLanguage": {
            "sSearch": "",
            "sInfo": ""
        }
    });

    $("#control_result_filter").prepend($("#control_buttons"));
    $("#control_buttons").css("height", "38px");
    $("#control_result_filter label").css("width", "60%");
    $("#control_result_filter label").css("float", "right");
    $("#control_result_filter label").css("position", "absolute");
    $("#control_result_filter label").css("right", 0);
    $("#control_result_filter label").css("height", "38px");
    $("#control_result_filter label").css("margin-bottom", "0px");
    $("#control_result_filter label input").css("width", "100%");
    $("#control_result_filter label input").css("height", "100%");
    $("#control_result_filter").css("width", "100%");
    $("#control_result_filter").css("display", "flex");

    $("#btn_delete").prop("disabled", "disabled");

    $("#btn_delete").click(function () {
        $("#modal_loading").modal("show");
        var ids = [];
        $.each($("#control_result input[type=checkbox]:checked"), function (index, element) {
            ids.push(parseInt($(element).attr("id").split("_")[1]));
        });

        if ($("#targetEntity").val() == "FormTemplate") {
            var delUrl = "FormTemplates/DeleteFormTemplate"
        } else {
            var delUrl = "ControlTable/Delete" + $("#targetEntity").val()
        }

        $.ajax({
            url: rootPath + delUrl,
            type: "POST",
            data: JSON.stringify(ids),
            contentType: "application/json; charset=utf-8",
            dataType: 'json',
            success: function (r, s, x) {
                defaultAjaxCallback(r, s, x, null, function () { window.location.reload() });
            },
            error: function (r, s, x) {
                if ($("#targetEntity").val() == "Disponent") {
                    if (r.status == 409) {
                        $("#modal_loading .running").hide();
                        $("#modal_loading #disponentDeleteFailed").show();
                        return;
                    }
                }
                defaultAjaxCallback(r, s, x, null, function () { window.location.reload() });
            }
        });
    });

    $("#btn_add").click(function () {
        if ($("#targetEntity").val() == "FormTemplate") {
            window.location = rootPath + "FormTemplates/EditTemplate";
        } else {
            var valuesArray = buildFieldNamesArray();
            new CUModal("./Create" + $("#targetEntity").val(),
                function () { window.location.reload() },
                function (r, s, x) { alert("Create " + $("#targetEntity").val() + " failed!"); alert(s); },
                langDict.Create + " " + $("#modal_add .modal-title").text().split(" ")[1],
                valuesArray,
                null);
        }
    })

    $("table .chbx-positive").change(function () {
        if ($("#control_result input[type=checkbox]:checked").length) {
            $("#btn_delete").prop("disabled", false);
        } else {
            $("#btn_delete").prop("disabled", true);
        }
    });

    $("tr").click(function (event) {
        if (event.target.className == "css-label" || event.target.className == "css-checkbox chbx-positive")
            return;

        var target = $(event.target);
        while (target[0].nodeName != "TR")
            target = target.parent();

        if ($("#targetEntity").val() == "FormTemplate") {
            var id = $("input", target).attr("id").split("_")[1];
            window.location = rootPath + "FormTemplates/EditTemplate?id=" + id;
        } else {
            var valuesArray = buildFieldNamesArray();
            $.each(valuesArray, function (index, subArray) {
                subArray[1] = $("td", target)[index + 1].innerText.trim();
            });
            new CUModal("./Update" + $("#targetEntity").val(),
                function () { window.location.reload() },
                function (r, s, x) { alert("Update " + $("#targetEntity").val() + " failed!"); alert(s); },
                langDict.Edit + " " + $("#modal_add .modal-title").text().split(" ")[1],
                valuesArray,
                $("td input", target).attr("id").split("_")[1]
            );
        }
    });

    $("#div_contactMailsHolder img").click(function (event) {
        var copy = $(".div_supplierContactHolder.prototype").clone();
        copy.removeClass("prototype");
        copy.css("display", "flex");

        $(".close", copy).click(function (e) { removeEmailRow(e); });
        $(".row", $(event.target).parent().parent()).append(copy);
    });
});

function removeEmailRow(event) {
    var target = $(event.target);
    target.parent().parent().remove();
}