﻿var modal;
var currentLangCode;

$(document).ready(function () {
    currentLangCode = $("#langKey").val();
    $(".localized-form-container:not(#" + currentLangCode + ")").hide();

    $(".btn_addQuestion").click(function () {
        //$("#chbx_existingQuestion")[0].checked = false;
        //$("#chbx_newQuestion")[0].checked = false;
        //$("#sel_existingQuestion").val("placeholder");
        $("#in_newQuestionText").val("");
        modal = $("#modal_addQuestion").modal();

        $("#modal_addQuestion #modal_localization_" + currentLangCode).show();
        $("#modal_addQuestion #chbxmodal_" + currentLangCode).prop("checked", "checked");
    });

    $("#sel_existingQuestion").change(function () {
        $("#chbx_existingQuestion")[0].checked = true;
        $("#chbx_newQuestion")[0].checked = false;
    });

    /*$(".ta_localizedQuestionText textarea").bind('input propertychange', function () {
        $("#chbx_newQuestion")[0].checked = true;
        $("#chbx_existingQuestion")[0].checked = false;
    });*/

    $("#chbx_newQuestion").change(function () {
        if ($("#chbx_newQuestion")[0].checked)
            $("#chbx_existingQuestion")[0].checked = false;
        else
            $("#chbx_existingQuestion")[0].checked = true;
    });

    $("#chbx_existingQuestion").change(function () {
        if ($("#chbx_existingQuestion")[0].checked)
            $("#chbx_newQuestion")[0].checked = false;
        else
            $("#chbx_newQuestion")[0].checked = true;
    });

    $(".btn_addAttachment").click(function () {
        $("#chbx_existingAttachment")[0].checked = false;
        $("#chbx_newAttachment")[0].checked = false;
        $("#sel_existingAttachment").val("placeholder");
        $("#in_newAttachment").val("");
        modal = $("#modal_addAttachment").modal();
    });

    $("#sel_existingAttachment").change(function () {
        $("#chbx_existingAttachment")[0].checked = true;
        $("#chbx_newAttachment")[0].checked = false;
    });

    $(".in-newAttachmentFile").bind('input propertychange', function inChange() {
        $("#chbx_newAttachment")[0].checked = true;
        $("#chbx_existingAttachment")[0].checked = false;

        var next = $(".new-file-input.prototype").clone().removeClass("prototype");
        $(".in-newAttachmentFile", next).bind('input propertychange', inChange);
        $("#modal_addAttachment .modal-body div").append(next);

        $("span", $(this).parent()).text(this.files[0].name);
        $("button", $(this).parent()).show();
        $("button", $(this).parent()).click(function () {
            $(this).parent().remove();
        });
        $(this).prop("disabled", "disabled");
    });

    $("#chbx_newAttachment").change(function () {
        if ($("#chbx_newAttachment")[0].checked)
            $("#chbx_existingAttachment")[0].checked = false;
        else
            $("#chbx_existingAttachment")[0].checked = true;
    });

    $("#chbx_existingAttachment").change(function () {
        if ($("#chbx_existingAttachment")[0].checked)
            $("#chbx_newAttachment")[0].checked = false;
        else
            $("#chbx_newAttachment")[0].checked = true;
    });

    $("#btn_saveAttachment").click(function () {
        $("#modal_loading").modal("show");

        if ($("#chbx_newAttachment")[0].checked) {
            var formData = new FormData();
            var fileInputs = $(".in-newAttachmentFile:not(:last)", $("#div_attachmentsHolder"));//[0].files[0];

            $.each(fileInputs, function () {
                if (this.files[0])
                    formData.append(this.files[0].name, this.files[0]);
            });

            formData.append("Id", $("#Id").val())
            formData.append("LangCode", currentLangCode);
            $.ajax({
                url: "/FormTemplates/CreateAttachment",
                type: "POST",
                data: formData,
                cache: false,
                contentType: false,
                processData: false,
                success: function (r, s, x) {
                    defaultAjaxCallback(r, s, x, function (r, s, x) {
                        $("#modal_addAttachment").modal("hide");

                        $.each(r, function () {
                            //var element = $('<div style="margin-bottom: 16px; display: flex;"><label class="control-label col-2" style="display: flex; align-items: center; margin: 0 auto;">Příloha:</label><div class="col-10" style="display: flex"><input class="form-control col-10" disabled value="' + this.Name + '"><input value="Odstranit" class="btn btn-danger col-2 btn_unbindFile" id="' + this.Id + '" /></div></div>');
                            var element = $('<div style="margin-bottom: 16px; display: flex;"><div class="col-2" style="padding-top: 7px;"><input type="checkbox" class="css-checkbox chbx-positive" id="chbx_AsAttachment_' + this.Id + '")><label class="css-label" for="chbx_AsAttachment_' + this.Id + '" style="display: flex; align-items: center; margin: 0 auto;">' + langDict.AttachToMail + '</label></div><div class="col-10" style="display: flex"><input class="form-control col-10" disabled value="' + this.Name + '"><input value="' + langDict.Remove + '" class="btn btn-danger col-2 btn_unbindFile" id="' + this.Id + '" /></div></div></div>');
                            $("#div_filesHolder", $("#" + currentLangCode)).append(element);
                            $(".btn_unbindFile", element).click(unbindFile);
                            $("input[type=checkbox]", element).change(asAttachment);
                        });
                    });
                },
                error: function (r, s, x) {
                    defaultAjaxCallback(r, s, x, function (r, s, x) {
                        alert(x);
                        $("#modal_addAttachment").modal("hide");
                    });
                }
            });
        } else if ($("#chbx_existingAttachment")[0].checked) {
            var atts = [];
            $.each($("#sel_existingAttachment option:selected"), function () {
                atts.push($(this).val());
            });
            $.ajax({
                url: "/FormTemplates/BindAttachment",
                type: "POST",
                data: {
                    attachmentIds: $("#sel_existingAttachment").val(),
                    formTemplateId: $("#Id").val(),
                    langCode: currentLangCode
                },
                success: function (r, s, x) {
                    defaultAjaxCallback(r, s, x, function (r, s, x) {
                        $("#modal_addAttachment").modal("hide");

                        $.each(r, function () {
                            var element = $('<div style="margin-bottom: 16px; display: flex;"><label class="control-label col-2" style="display: flex; align-items: center; margin: 0 auto;">Příloha:</label><div class="col-10" style="display: flex"><input class="form-control col-10" disabled value="' + this.Name + '"><input value="Odstranit" class="btn btn-danger col-2 btn_unbindFile" id="' + this.Id + '" /></div></div>');
                            $("#div_filesHolder", $("#" + currentLangCode)).append(element);
                            $(".btn_unbindFile", element).click(unbindFile);
                        });
                    });
                },
                error: function (r, s, x) {
                    defaultAjaxCallback(r, s, x, function (r, s, x) {
                        if (r.status == 400)
                            alert("Question already in form.");
                        else if (r.status == 404)
                            alert("Question or form Id invalid.");
                        $("#modal_addAttachment").modal("hide");
                    });
                }
            })
        }
    });

    $("#btn_saveQuestion").click(function () {
        $("#modal_loading").modal("show");

        //if ($("#chbx_newQuestion")[0].checked) {
            var model = {};
            model.questions = [];
            model.formTemplateId = $("#Id").val();

            $.each($(".ta_localizedQuestionText textarea"), function (index, element) {
                var langCode = $(element).attr("id").split("_")[2]
                model.questions.push({
                    langCode: langCode,
                    questionText: $("#in_newQuestionText_" + langCode).val()
                });                
            });       
            $.ajax({
                url: rootPath + "FormTemplates/CreateQuestion",
                type: "POST",
                data: model,
                success: function (r, s, x) {
                    defaultAjaxCallback(r, s, x, null, redirectToLocalizedLocation);/*function (r, s, x) {
                        $.each(r, function (index, tuple) {
                            var element = $(
                                '<div class="row">' +
                                    '<label class="control-label col-2" style="display: flex; align-items: center; margin: 0 auto;">Otázka:</label>' +
                                    '<div class="col-10" style="display: flex">' +
                                        '<textarea class="form-control col-10" disabled>' +
                                            $("#in_newQuestionText_" + tuple.Item2).val() +
                                        '</textarea>' +
                                        '<input value="Odstranit" class="btn btn-danger col-2 btn_unbindQuestion" id="' + tuple.Item1 + '" />' +
                                    '</div>' +
                                '</div > ');

                            var element = $(
                                '<div class="row">' +
                                    '<div class="col-3" style="margin-top: 5px;" >' +
                                        '<input type="checkbox" class="css-checkbox chbx-positive" id="chbx_showInReport_' + tuple.Item1 + '") />' +
                                        '<label class="css-label" for="chbx_showInReport_' + tuple.Item1 + '">Zobrazit v reportu</label>' +
                                    '</div >' +
                                    '<div class="col-9" style="display: flex">' +
                                    '<textarea class="form-control col-10" disabled>' + $("#in_newQuestionText_" + tuple.Item2).val() + '</textarea>' +
                                        '<div class="col-2">' +
                                            '<button class="btn btn-danger btn_unbindQuestion" id="' + tuple.Item1 + '" style="width: 100%">Odstranit</button>' +
                                            '<button class="btn btn-primary btn_editQuestion" id="' + tuple.Item1 + '" style="width: 100%">Upravit</button>' +
                                        '</div>' +
                                    '</div>' +
                                '</div>'
                            );

                            $("#div_questionsHolder", $("#" + tuple.Item2)).append(element);
                            $(".btn_unbindQuestion", element).click(unbindQuestion);
                            $(".btn_editQuestion", element).click(editQuestion);

                            $("#chbx_showInReport_" + tuple.Item1).prop("checked", true);
                            $("#chbx_showInReport_" + tuple.Item1).change(setShowInReport);
                        });
                        $("#modal_addQuestion").modal("hide");
                    });*/
                },
                error: function (r, s, x) {
                    defaultAjaxCallback(r, s, x, function (r, s, x) {
                        alert(x);
                        $("#modal_addQuestion").modal("hide");
                    });
                }
            });
        /*} else if ($("#chbx_existingQuestion")[0].checked) {
            $.ajax({
                url: rootPath + "FormTemplates/BindQuestion",
                type: "POST",
                data: {
                    questionId: $("#sel_existingQuestion").val(),
                    formTemplateId: $("#Id").val(),
                    langCode: currentLangCode
                },
                success: function (r, s, x) {
                    defaultAjaxCallback(r, s, x, function (r, s, x) {
                        var element = $('<div class="row"><label class="control-label col-2" style="display: flex; align-items: center; margin: 0 auto;">Otázka:</label><div class="col-10" style="display: flex"><textarea class="form-control col-10" disabled>' + $("#sel_existingQuestion :selected").text() + ' </textarea><input value="Odstranit" class="btn btn-danger col-2 btn_unbindQuestion" id="' + $("#sel_existingQuestion").val() + '"/></div></div>');
                        $("#div_questionsHolder", $("#" + currentLangCode)).append(element);
                        $(".btn_unbindQuestion", element).click(unbindQuestion);
                        $("#modal_addQuestion").modal("hide");
                    });
                },
                error: function (r, s, x) {
                    defaultAjaxCallback(r, s, x, function (r, s, x) {
                        if (r.status == 400)
                            alert("Question already in form.");
                        else if (r.status == 404)
                            alert("Question or form Id invalid.");
                        $("#modal_addQuestion").modal("hide");
                    });
                }
            })
        }*/
    });

    $(".btn_saveTemplate").click(function () {
        $("#modal_loading").modal("show");
        $.ajax({
            url: rootPath + "FormTemplates/UpdateLocalizedTemplate",
            type: "POST",
            data: {
                Id: $("#Id").val(),
                MailSubject: $("#localized_MailSubject", $("#" + currentLangCode)).val(),
                MailBody: $("#localized_MailBody", $("#" + currentLangCode)).val(),
                MailBodyUrgent: $("#localized_MailBodyUrgent", $("#" + currentLangCode)).val(),
                LangCode: currentLangCode
            },
            success: function (r, s, x) {
                defaultAjaxCallback();
            },
            error: function (r, s, x) {
                defaultAjaxCallback(r, s, x, function (r, s, x) {
                    if (r.status == 404)
                        alert("Form ID invalid");
                    else
                        alert(x);
                });
            }
        });
    });

    $("#btn_renameTemplate").click(function () {
        $("#modal_loading").modal("show");
        $.ajax({
            url: rootPath + "FormTemplates/UpdateTemplate",
            type: "POST",
            data: {
                Id: $("#Id").val(),
                TemplateName: $("#TemplateName").val()
            },
            success: function (r, s, x) {
                defaultAjaxCallback();
            },
            error: function (r, s, x) {
                defaultAjaxCallback(r, s, x, function (r, s, x) {
                    if (r.status == 404)
                        alert("Form ID invalid");
                    else
                        alert(x);
                });
            }
        });
    });

    $(".btn_unbindQuestion").click(unbindQuestion);

    $(".btn_unbindFile").click(unbindFile);

    $("#div_localizationSwitch .chbx-positive").change(function (event) {
        $("#div_localizationSwitch input[type=checkbox]").each(function (index, element) {
            $(element).prop("checked", false)
        });
        $(event.target).prop("checked", true);

        $(".localized-form-container").hide();

        currentLangCode = $(event.target).attr("id").split("_")[1];
        $("#" + currentLangCode).show();


        $("#div_modalLocalizationSwitch input[type=checkbox]").each(function (index, element) {
            $(element).prop("checked", false)
        });

        $("#chbxmodal_" + currentLangCode).prop("checked", true);

        $(".ta_localizedQuestionText").hide();
        $("#modal_localization_" + currentLangCode).show();
    });

    $("#div_modalLocalizationSwitch .chbx-positive").change(function (event) {
        $("#div_modalLocalizationSwitch input[type=checkbox]").each(function (index, element) {
            $(element).prop("checked", false);
        });
        $(event.target).prop("checked", true);

        $(".ta_localizedQuestionText").hide();

        currentLangCode = $(event.target).attr("id").split("_")[1];
        $("#modal_localization_" + currentLangCode).show();
    });

    $("#btn_addLangMutation").click(function () {
        $("#modal_addLang").modal("show");
    });

    $("#btn_addLang").click(function () {
        $("#modal_loading").modal("show");
        currentLangCode = $("#sel_existingLanguage option:selected").text();
        $.ajax({
            url: rootPath + "FormTemplates/CreateLanguageMutation",
            type: "POST",
            data: {
                formTemplateId: $("#Id").val(),
                langId: $("#sel_existingLanguage option:selected").val()
            },
            success: function (r, s, x) {
                defaultAjaxCallback(r, s, x, function (r, s, x) {
                    redirectToLocalizedLocation();
                });
            },
            error: function (r, s, x) {
                defaultAjaxCallback(r, s, x, function (r, s, x) {
                    window.location.reload();
                });
            }
        });
    });

    $("#btn_addLangCarrier").click(function () {
        $("#modal_loading").modal("show");
        currentLangCode = $("#sel_existingLanguage option:selected").text();
        $.ajax({
            url: rootPath + "CarrierTemplate/CreateLanguageMutation",
            type: "POST",
            data: {
                formTemplateId: $("#Id").val(),
                langId: $("#sel_existingLanguage option:selected").val()
            },
            success: function (r, s, x) {
                defaultAjaxCallback(r, s, x, function (r, s, x) {
                    redirectToLocalizedLocation();
                });
            },
            error: function (r, s, x) {
                defaultAjaxCallback(r, s, x, function (r, s, x) {
                    window.location.reload();
                });
            }
        });
    });

    $(".ta_localizedQuestionText img").click(function (event) {
        var targetIndex = -1;
        $("#div_modalLocalizationSwitch input[type=checkbox]").each(function (index, element) {
            $(element).prop("checked", false);
            if ($(element).attr("id").split("_")[1] == currentLangCode) {
                if ($(event.target).hasClass("left")) {
                    targetIndex = index - 1;
                } else {
                    targetIndex = index + 1;
                }
            }
        });

        if (targetIndex < 0) {
            targetIndex = $("#div_modalLocalizationSwitch input[type=checkbox]").length - 1;
        } else if (targetIndex == $("#div_modalLocalizationSwitch input[type=checkbox]").length) {
            targetIndex = 0;
        }

        $($("#div_modalLocalizationSwitch input[type=checkbox]")[targetIndex]).trigger("change");
    });

    $("#div_questionsHolder input[type=checkbox]").change(setShowInReport);

    $(".btn_editQuestion").click(editQuestion);

    $(".sortable").sortable({
        deactivate: function (event, ui) {
            var swaps = [];
            var target = $(ui.item);
            $.each($(".row", target.parent()), function (index, element) {
                var tmp_element = $(element);
                var original_position = parseInt($("input[type='text']", tmp_element).val());
                var question_id = $(".btn_unbindQuestion", tmp_element).attr("id");

                if (original_position != (index + 1)) {
                    swaps.push({
                        originalPosition: original_position,
                        newPosition: (index + 1),
                        questionId: question_id
                    });
                    $("input[type='text']", tmp_element).val(index + 1);
                }
            });

            if (swaps.length) {
                $("#modal_loading").modal("show");
                $.ajax({
                    url: rootPath + "FormTemplates/UpdateQuestionsPositions",
                    type: "POST",
                    data: {
                        formId: $("#Id").val(),
                        swaps: swaps
                    },
                    success: function (r, s, x) {
                        defaultAjaxCallback(r, s, x, null, function () {
                            redirectToLocalizedLocation();
                        });
                    },
                    error: function (r, s, x) {
                        defaultAjaxCallback(r, s, x);
                    }
                });
            }
        }
    });

    $("#div_filesHolder input[type=checkbox]").change(asAttachment);

});

function setShowInReport(event) {
    $("#modal_loading").modal("show");

    var target = $(event.target);

    $.ajax({
        url: rootPath + "FormTemplates/SetShowQuestionInManagerReport",
        type: "POST",
        data: {
            questionId: target.attr("id").split("_")[2],
            show: target[0].checked
        },
        success: function (r, s, x) {
            defaultAjaxCallback(r, s, x);
        },
        error: function (r, s, x) {
            defaultAjaxCallback(r, s, x);
        }
    });
}

function unbindQuestion(event) {
    $("#modal_loading").modal("show");
    $.ajax({
        url: rootPath + "FormTemplates/UnbindQuestion",
        type: "POST",
        data: {
            questionId: $(event.target).attr("id"),
            formTemplateId: $("#Id").val(),
            langCode: currentLangCode
        },
        success: function (r, s, x) {
            defaultAjaxCallback(r, s, x, null, function () {
                redirectToLocalizedLocation();
            });
        },
        error: function (r, s, x) {
            defaultAjaxCallback(r, s, x, function (r, s, x) {
                if (r.status == 400)
                    alert("No such question.");
                alert(x);
            });
        }
    });
}

function editQuestion(event) {
    event.preventDefault();
    var target = $(event.target);
    if ($("textarea", target.parent().parent()).prop("disabled")) {
        $("textarea", target.parent().parent()).prop("disabled", false);
        target.text("Uložit");
    } else {
        $("#modal_loading").modal("show");
        $("textarea", target.parent().parent()).prop("disabled", true);
        target.text("Upravit");
        $.ajax({
            url: rootPath + "FormTemplates/UpdateQuestion",
            type: "POST",
            data: {
                questionId: target.attr("id"),
                questionText: $("textarea", target.parent().parent()).val()
            },
            success: function (r, s, x) {
                defaultAjaxCallback(r, s, x);
            },
            error: function (r, s, x) {
                defaultAjaxCallback(r, s, x, function () {
                    alert("Error!");
                });
            }
        });
    }
}

function unbindFile(event) {
    $("#modal_loading").modal("show");
    $.ajax({
        url: rootPath + "FormTemplates/UnbindAttachment",
        type: "POST",
        data: {
            attachmentId: $(event.target).attr("id"),
            formTemplateId: $("#Id").val(),
            langCode: currentLangCode
        },
        success: function (r, s, x) {
            defaultAjaxCallback(r, s, x, function (r, s, x) {
                $(event.target).parent().parent().remove();
            });
        },
        error: function (r, s, x) {
            defaultAjaxCallback(r, s, x, function (r, s, x) {
                if (r.status == 400)
                    alert("No such attachment.");
                alert(x);
            });
        }
    });
}

function asAttachment(event) {
    $("#modal_loading").modal("show");

    var target = $(event.target);

    $.ajax({
        url: rootPath + "FormTemplates/AsAttachment",
        type: "POST",
        data: {
            attachmentId: target.attr("id").split("_")[2],
            asAttachment: target[0].checked,
            formTemplateId: $("#Id").val()
        },
        success: function (r, s, x) {
            defaultAjaxCallback(r, s, x);
        },
        error: function (r, s, x) {
            if (r.status == 413) {
                $("#modal_loading .running").hide();
                $("#modal_loading #attachmentTooLarge").show();
                target.prop("checked", false);
                return;
            }
            defaultAjaxCallback(r, s, x, null, function () { window.location.reload() });
        }
    });
}

function redirectToLocalizedLocation() {
    var href = window.location.href;
    if (href.indexOf("&") > 0) {
        href = href.substr(0, href.indexOf("&") + 1);
        href += currentLangCode;
    } else {
        if (!(href.indexOf("?") > 0)) {
            href += "?Id=" + $("#Id").val();
        }
        href += "&langKey=" + currentLangCode;
    }

    window.location.href = href;
}