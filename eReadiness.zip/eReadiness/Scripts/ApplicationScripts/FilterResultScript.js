﻿$(document).ready(function () {
    $("#forms_result").DataTable({
        "paging": false,
        "oLanguage": {
            "sSearch": "",
            "sInfo": ""
        }
    });

    $("#forms_result_filter").prepend($("#forms_buttons"));
    $("#control_buttons").css("height", "38px");
    $("#btn_sendAll").css("margin-left", "0px");
    $("#forms_result_filter label").css("width", "70%");
    $("#forms_result_filter label").css("height", "38px");
    $("#forms_result_filter label").css("margin-bottom", "0px");
    $("#forms_result_filter label input").css("width", "100%");
    $("#forms_result_filter label input").css("height", "100%");
    $("#forms_result_filter").css("width", "100%");
    $("#forms_result_filter").css("display", "flex");


    $(".state-color").each(function () {
        $(this).css("color", getGradientColor(this.innerText.trim().substr(0, this.innerText.trim().length - 1)));
    });

    $(".btn-send").click(function (event) {
        var tgt = $(event.target);
        $("#modal_sendEmail").modal('show');
        $("#modal_sendEmail #btn_send").off('click');
        $("#modal_sendEmail #btn_send").click(function () {
            $("#modal_loading").modal("show");
            var updateTarget = $($("td", tgt.parent().parent())[9]);
            $.ajax({
                url: rootPath + "Forms/Send/" + tgt.attr("id"),
                success: function (r, s, x) {
                    defaultAjaxCallback(r, s, x, function (r, s, x) {
                        $("#modal_sendEmail").modal('hide');
                        updateTarget.text(getFormattedDate());
                    });
                },
                error: function (r, s, x) {
                    $("#modal_sendEmail").modal('hide');
                    defaultAjaxCallback(r, s, x, function (r, s, x) { alert(x); })
                }
            });
        });
    });

    $(".btn-carriersend").click(function (event) {
        var tgt = $(event.target);
        $("#modal_sendEmail").modal('show');
        $("#modal_sendEmail #btn_send").off('click');
        $("#modal_sendEmail #btn_send").click(function () {
            $("#modal_loading").modal("show");
            var updateTarget = $($("td", tgt.parent().parent())[9]);
            $.ajax({
                url: rootPath + "CarrierForms/Send/" + tgt.attr("id"),
                success: function (r, s, x) {
                    defaultAjaxCallback(r, s, x, function (r, s, x) {
                        $("#modal_sendEmail").modal('hide');
                        updateTarget.text(getFormattedDate());
                    });
                },
                error: function (r, s, x) {
                    $("#modal_sendEmail").modal('hide');
                    defaultAjaxCallback(r, s, x, function (r, s, x) { alert(x); })
                }
            });
        });
    });

    $("#btn_sendAll").click(function () {
        $("#modal_sendEmail").modal('show');
        $("#modal_sendEmail #btn_send").off('click');
        $("#modal_sendEmail #btn_send").click(function () {
            $("#modal_loading").modal("show");
            var ids = [];
            $.each($("#forms_result input[type=checkbox]:checked"), function (index, element) {
                ids.push($(element).attr("id").split("_")[1]);
            });

            $.ajax({
                url: rootPath + "Forms/SendSelected",
                type: "POST",
                data: JSON.stringify(ids),
                contentType: "application/json; charset=utf-8",
                dataType: 'json',
                success: function (r, s, x) {
                    $("#modal_sendEmail").modal('hide');
                    defaultAjaxCallback(r, s, x, null, function () { window.location.reload() });
                },
                error: function (r, s, x) {
                    $("#modal_sendEmail").modal('hide');
                    defaultAjaxCallback(r, s, x, null, function () { window.location.reload() });
                }
            });
        });
    });

    $("#btn_CarrierSendAll").click(function () {
        $("#modal_sendEmail").modal('show');
        $("#modal_sendEmail #btn_send").off('click');
        $("#modal_sendEmail #btn_send").click(function () {
            $("#modal_loading").modal("show");
            var ids = [];
            $.each($("#forms_result input[type=checkbox]:checked"), function (index, element) {
                ids.push($(element).attr("id").split("_")[1]);
            });

            $.ajax({
                url: rootPath + "CarrierForms/SendSelected",
                type: "POST",
                data: JSON.stringify(ids),
                contentType: "application/json; charset=utf-8",
                dataType: 'json',
                success: function (r, s, x) {
                    $("#modal_sendEmail").modal('hide');
                    defaultAjaxCallback(r, s, x, null, function () { window.location.reload() });
                },
                error: function (r, s, x) {
                    $("#modal_sendEmail").modal('hide');
                    defaultAjaxCallback(r, s, x, null, function () { window.location.reload() });
                }
            });
        });
    });

    $(".btn-fill").click(function () {
        $("#modal_loading").modal("show");
        window.location = rootPath + "Forms/Fill/" + $(this).attr("id");
    });

    $(".btn-carrierfill").click(function () {
        $("#modal_loading").modal("show");
        window.location = rootPath + "CarrierForms/Fill/" + $(this).attr("id");
    });

    $(".chbx-positive").change(function () {
        if ($("#forms_result input[type=checkbox]:checked").length) {
            $("#btn_sendAll").val(decodeHtmlCharCodes(langDict.SendSelected));
        } else {
            $("#btn_sendAll").val(decodeHtmlCharCodes(langDict.SendAll));
        }
    });

    $("#a_back").click(function () {
        $("#modal_loading").modal("show");
        var filterData = window.location.href.split("?")[1];

        window.location = rootPath + "Filter/Index" + (filterData ? "?" + filterData : "");
    });
});