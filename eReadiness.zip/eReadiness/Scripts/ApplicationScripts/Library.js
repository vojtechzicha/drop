﻿var validateModal;

window.addEventListener("pageshow", function (event) {
    var historyTraversal = event.persisted ||
        (typeof window.performance != "undefined" &&
            window.performance.navigation.type === 2);
    if (historyTraversal) {
        // Handle page restore.
        window.location.reload();
    }
});

$(document).ready(function () {
    $("a").click(function () {
        $("#modal_loading").modal("show");
    });

    $('textarea:not(.modal_textarea)').each(function () {
        this.setAttribute('style', 'height:' + (this.scrollHeight) + 'px;overflow-y:hidden;');
    }).on('input', function () {
        this.style.height = 'auto';
        this.style.height = (this.scrollHeight) + 'px';
    });

    $(".btn").attr('spellcheck', false);
});
function defaultAjaxCallback(r, s, x, before, after) {
    if (before)
        before(r, s, x);

    $("#modal_loading .running").hide();
    $("#modal_loading .completed").show();

    setTimeout(function () {
        $("#modal_loading").modal("hide");
        $("#modal_loading .running").show();
        $("#modal_loading .completed").hide();
    }, 500);

    if (after)
        after(r, s, x);
}

function openNav() {
    $("#side-nav")[0].style.width = "220px";
}

function closeNav() {
    $("#side-nav")[0].style.width = "0";
    defaultAjaxCallback();
}

function getGradientColor(percent) {
    if (percent == 100) {
        return "#4BA82E";
    } else if (percent > 0) {
        return "#FF8000";
    } else {
        return "#DC3545";
    }

    /*if (percent > 1)
        percent = percent / 100;

    var start_color = "DC3545";
    var end_color = "4BA82E";
    // get colors
    var start_red = parseInt(start_color.substr(0, 2), 16),
        start_green = parseInt(start_color.substr(2, 2), 16),
        start_blue = parseInt(start_color.substr(4, 2), 16);

    var end_red = parseInt(end_color.substr(0, 2), 16),
        end_green = parseInt(end_color.substr(2, 2), 16),
        end_blue = parseInt(end_color.substr(4, 2), 16);

    // calculate new color
    var diff_red = end_red - start_red;
    var diff_green = end_green - start_green;
    var diff_blue = end_blue - start_blue;

    diff_red = ((diff_red * percent) + start_red).toString(16).split('.')[0];
    diff_green = ((diff_green * percent) + start_green).toString(16).split('.')[0];
    diff_blue = ((diff_blue * percent) + start_blue).toString(16).split('.')[0];

    // ensure 2 digits by color
    if (diff_red.length == 1) diff_red = '0' + diff_red
    if (diff_green.length == 1) diff_green = '0' + diff_green
    if (diff_blue.length == 1) diff_blue = '0' + diff_blue

    return '#' + diff_red + diff_green + diff_blue;*/
};

function getFormattedDate() {
    var today = new Date();

    var YY = today.getFullYear().toString().substring(2, 4);
    var MM = (today.getMonth() + 1 < 10) ? "0" + (today.getMonth() + 1) : (today.getMonth() + 1);
    var dd = (today.getDate() < 10) ? "0" + (today.getDate()) : today.getDate();

    return [YY, MM, dd].join("/");
}

function isFunction(functionToCheck) {
    return functionToCheck && {}.toString.call(functionToCheck) === '[object Function]';
}

function CUModal(_submitAddress, _successCallback, _errorCallback, modalTitle, valuesArray, Id) {
    var instance = this;
    this.submitAdress = _submitAddress;
    this.successCallback = _successCallback;
    this.errorCallback = _errorCallback;
    this.Id = Id;
    this.valuesArray = valuesArray;

    this.modal = $("#modal_add");
    //this.modal.on("hidden.bs.modal", () => { delete this; });

    this.inputs = $(".modal-body input:not(.chbx-positive):not(.btn), textarea", this.modal)
    this.selects = $(".modal-body select:not(.supplierContactSelect)", this.modal);
    this.checkBoxes = $(".modal-body .chbx-positive", this.modal);

    $.each(this.checkBoxes, function (z, chbx) {
        $(chbx).prop("checked", false);
    });

    $(".modal-title", this.modal).text(modalTitle);

    $("#btn_save", this.modal).off("click");
    $("#btn_save", this.modal).click(function() { instance.submit() });

    for (var index = 0; index < this.inputs.length; index++) {
        $(this.inputs[index]).val("");
        $(this.inputs[index]).removeClass("error-input");
    }

    for (var index = 0; index < this.selects.length; index++) {
        $(this.selects[index]).val($("option:first", $(this.selects[index])).val());
    }

    if (this.selects.length) {
        for (var index = 0; index < Math.min(this.selects.length, valuesArray.length); index++) {
            $(this.selects[index]).val(valuesArray[index][1]);
        }

        for (; index < Math.min(this.inputs.length + this.selects.length, valuesArray.length); index++) {
            $(this.inputs[index - this.selects.length]).val(valuesArray[index][1]);
        }
    } else if (this.checkBoxes.length) {
        for (var index = 0; index < Math.min(this.inputs.length, valuesArray.length); index++) {
            $(this.inputs[index]).val(valuesArray[index][1]);
        }

        var langArr = valuesArray[index][1].split(",");

        for (var i = 0; i < langArr.length; i++) {
            var langCode = langArr[i].trim();

            for (var j = 0; j < this.checkBoxes.length; j++) {
                var elem = $(this.checkBoxes[j]);
                if (elem.attr("id") == ("chbxmodal_" + langCode)) {
                    elem.prop("checked", "checked");
                }
            }
        }
    } else {
        for (var index = 0; index < valuesArray.length; index++) {
            if (valuesArray[index][0] == "contactemails") {
                var contactsArray = valuesArray[index][1].split(",");
                var rows_holder = $("#div_contactMailsHolder .row");
                rows_holder.empty();
                if (!isEmptyOrSpaces(contactsArray[0])) {
                    $.each(contactsArray, function(index, value) {
                        rows_holder.append($('<div class="col-12 div_supplierContactHolder" style="display: flex;"><div class="col-5"><input disabled class="form-control" value="' + value.split("/")[2] + '" /></div><input disabled class="form-control col-6" value=' + value.split("/")[1] + ' /><div class="col-1" style="display: flex; align-items: center;"><button type="button" class="close" style="color: red; width: 100%;">×</button></div></div>'));
                    });
                }
                var copy = $(".div_supplierContactHolder.prototype").clone();
                copy.removeClass("prototype");
                copy.css("display", "flex");
                rows_holder.append(copy);

                $("#div_contactMailsHolder .close").click(function (e) { removeEmailRow(e) });
            } else {
                $(this.inputs[index]).val(valuesArray[index][1]);
            }
        }
    }

    this.modal.modal("show");
}
CUModal.prototype.submit = function() {
    $("#modal_loading").modal("show");
    var instance = this;
    var dataObject = {};
    if (this.selects.length) {
        for (var index = 0; index < Math.min(this.selects.length, this.valuesArray.length); index++) {
            if ($("option:selected", this.selects[index]).attr("id"))
                dataObject[this.valuesArray[index][0]] = $("option:selected", this.selects[index]).attr("id").split("_")[1];
            else {
                alert("Some option is not selected!")
                return;
            }
        }
        for (; index < Math.min(this.inputs.length + this.selects.length, this.valuesArray.length); index++) {
            dataObject[this.valuesArray[index][0]] = $(this.inputs[index - this.selects.length]).val();
        }
    } else if (this.checkBoxes.length) {
        for (var index = 0; index < Math.min(this.inputs.length, this.valuesArray.length); index++) {
            dataObject[this.valuesArray[index][0]] = $(this.inputs[index]).val();
        }

        dataObject[this.valuesArray[index][0]] = "";
        for (var i = 0; i < this.checkBoxes.length; i++) {
            if ($(this.checkBoxes[i]).is(":checked"))
                dataObject[this.valuesArray[index][0]] += $(this.checkBoxes[i]).attr("id").split("_")[1] + "-";
        }
    } else {
        for (var index = 0; index < this.valuesArray.length; index++) {
            if (this.valuesArray[index][0] == "contactemails") {
                var pairs = "";
                $.each($(".div_supplierContactHolder", this.modal), function (j, elem) {
                    if ($(".col-6", $(elem)).val()) {
                        if ($("select", $(elem)).length) {
                            pairs += $(".col-5 select", $(elem)).val() + "/" + $(".col-6", $(elem)).val() + ",";
                        } else {
                            pairs += $(".col-5 input", $(elem)).val() + "/" + $(".col-6", $(elem)).val() + ",";
                        }
                    }
                });
                dataObject[this.valuesArray[index][0]] = pairs;
            } else {
                dataObject[this.valuesArray[index][0]] = $(this.inputs[index]).val();
            }
        }
    }

    if (this.Id)
        dataObject.Id = this.Id;

    if (validateModal && isFunction(validateModal)) {
        if (validateModal()) {
            $.ajax({
                url: this.submitAdress,
                type: "POST",
                data: JSON.stringify(dataObject),
                contentType: "application/json; charset=utf-8",
                dataType: 'json',
                success: function (r, s, x) {
                    defaultAjaxCallback(r, s, x, null, instance.successCallback);
                },
                error: function (r, s, x) {
                    defaultAjaxCallback(r, s, x, null, instance.errorCallback);
                }
            });
        } else {
            $("#modal_loading").modal("hide");
        }
    } else {
        $.ajax({
            url: this.submitAdress,
            type: "POST",
            data: JSON.stringify(dataObject),
            contentType: "application/json; charset=utf-8",
            dataType: 'json',
            success: function (r, s, x) {
                defaultAjaxCallback(r, s, x, null, instance.successCallback);
            },
            error: function (r, s, x) {
                defaultAjaxCallback(r, s, x, null, instance.errorCallback);
            }
        });
    }    
}

function buildFieldNamesArray() {
    var table = $("#control_result");
    if (table) {
        var header = $("tr:first", table);
        var arr = [];
        $.each($("td:not(:first)", header), function (index, element) {
            arr.push([$(element).attr("fieldname"), ""]);
        });
        return arr;
    }
}

function isEmptyOrSpaces(str) {
    return str === null || str.match(/^ *$/) !== null;
}

function SetHideableBlock(blockid, fieldname) {
    if ($('input[name=' + fieldname + ']:checked', '#carrierform').val() === "Y") {
        $(blockid).show();
    }
    else {
        $(blockid).hide();
    }
    $('#carrierform input').on('change', function () {
        if ($('input[name=' + fieldname + ']:checked', '#carrierform').val() === "Y") {
            $(blockid).show();
        }
        else {
            $(blockid).hide();
        }
    });
}

function SetCheckboxBlock(blockid, fieldname) {
    if ($('input[name=' + fieldname + ']', '#carrierform').is(':checked')) {
        $(blockid).show();
    }
    else {
        $(blockid).hide();
    }
    $('#carrierform input').on('change', function () {
        if ($('input[name=' + fieldname + ']', '#carrierform').is(':checked')) {
            $(blockid).show();
        }
        else {
            $(blockid).hide();
        }
    });
}

function SetMultiCheckboxBlock(blockid, fieldname, value) {
    $('.' + fieldname + ' :checkbox').each(function () {
        if ($(this).val() === value) {
            if ($(this).is(':checked')) {
                $(blockid).show();
            }
            else {
                $(blockid).hide();
            }
        }
    });  
    $('#carrierform input').on('change', function () {
        $('.' + fieldname + ' :checkbox').each(function () {
            if ($(this).val() === value) {
                if ($(this).is(':checked')) {
                    $(blockid).show();
                }
                else {
                    $(blockid).hide();
                }
            }
        });  
    });
}

function SetRequiredSpec(fieldname, checkvalue) {
    var requiredSpec = $('#' + fieldname + '_Spec');

    if ($('input[name=' + fieldname + ']:checked', '#carrierform').val() === checkvalue) {
        requiredSpec.attr('required', 'required');
    }
    else {
        requiredSpec.removeAttr('required');
    }

    $('#carrierform input').on('change', function () {
        var requiredSpec = $('#' + fieldname + '_Spec');
        if ($('input[name=' + fieldname + ']:checked', '#carrierform').val() === checkvalue) {
            requiredSpec.attr('required', 'required');
        }
        else {
            requiredSpec.removeAttr('required');
        }
    });
}