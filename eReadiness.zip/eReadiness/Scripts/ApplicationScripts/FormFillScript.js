﻿var currentLangCode;

$(document).ready(function () {
    $("input[type='checkbox']", $("#div_questionsHolder")).change(function (event) {
        var event_target = $(event.target);
        var target_parent = event_target.parent().parent();

        if (event_target.hasClass("chbx-positive")) {
            if (event_target.prop("checked")) {
                $(".chbx-negative", target_parent).prop("checked", false);
                $(".in-responseReason", target_parent).prop("disabled", true);
                $(".in-responseReason", target_parent).val("");
            }
            else {
                $(".chbx-negative", target_parent).prop("checked", true);
                $(".in-responseReason", target_parent).prop("disabled", false);
            }
        }
        else {
            if (event_target.prop("checked")) {
                $(".chbx-positive", target_parent).prop("checked", false);
                $(".in-responseReason", target_parent).prop("disabled", false);
            }
            else {
                $(".chbx-positive", target_parent).prop("checked", true);
                $(".in-responseReason", target_parent).prop("disabled", true);
                $(".in-responseReason", target_parent).val("");
            }
        }
    });
    $("#btn_saveResponses").click(function () { submitResponses(false) });
    $("#btn_submitResponses").click(function () {
        if (!validateForm()) {
            return;
        }
        $("#modal_confirm").modal("show");
    });
    $("#btn_confirmSubmit").click(function () { submitResponses(true) });
    if ($("#FormState").val() == "Closed") {
        $("input").not(".chbx-lang").attr("disabled", "disabled");
        $("textarea").attr("disabled", "disabled")

        $(".sticky-footer").show();
        $("#btn_unlockForm").prop("disabled", "");

        $("#btn_unlockForm").click(function () {
            $("#modal_loading").modal("show");

            $.ajax({
                url: rootPath + "Forms/UnlockForm",
                type: "POST",
                data: JSON.stringify({
                    "formCode": $("#Code").val()
                }),
                dataType: "json",
                contentType: "application/json; charset=utf-8",
                success: function (r, s, x) {
                    defaultAjaxCallback(r, s, x, function () {
                        window.location.reload();
                    });
                },
                error: function (r, s, x) {
                    defaultAjaxCallback(r, s, x, function () {
                        alert(x);
                    });
                }
            });
        });
    } else {

        $("#in_addMaterial").on("keypress", function (e) {
            if (e.which == 13) {
                submitMaterial();
            }
        });

        $("#btn_addMaterial").click(function() {
            submitMaterial();
        });

        $("#btn_setDisponent").click(function () {
            setDisponent();
        });

        $("button.close").click(function (event) {
            unbindMaterial(event.target);
        });
    }

    $("#div_localizationSwitch .chbx-positive").change(function (event) {
        /*$("#div_localizationSwitch input[type=checkbox]").each(function (index, element) {
            $(element).prop("checked", false)
        });
        $(event.target).prop("checked", true);

        $(".localized-form-container").hide();*/
        $("#modal_loading").modal("show");
        currentLangCode = $(event.target).attr("id").split("_")[1];
        //$("#" + currentLangCode).show();

        /*$.each($(".localized-form-container"), (i, e) => {
            var tgt = $(e);
            if (tgt.attr("langcode") == currentLangCode)
                tgt.show();
        });

        $("#div_modalLocalizationSwitch input[type=checkbox]").each(function (index, element) {
            $(element).prop("checked", false)
        });

        $("#chbxmodal_" + currentLangCode).prop("checked", true);

        $(".ta_localizedQuestionText").hide();
        $("#modal_localization_" + currentLangCode).show();*/

        lang = currentLangCode;
        rootPath = root + lang + "/";
        var path = rootPath + "Forms/Fill/?Id=" + $("#Code").val() + "&SelectedLangCode=" + lang;

        window.location = path;
    });
});

function submitMaterial() {
    $("#modal_loading").modal("show");

    $.ajax({
        url: rootPath + "Forms/BindMaterial",
        type: "POST",
        data: JSON.stringify({
            "formCode": $("#Code").val(),
            "materialNumber": $("#div_partsHeader input").val()
        }),
        dataType: "json",
        contentType: "application/json; charset=utf-8",
        success: function (r, s, x) {
            defaultAjaxCallback(r, s, x, function () {
                var element = $('<div class="col-4"><span>' + $("#div_partsHeader input").val() + '</span><button type="button" class="close" style="color: red;">×</button></div>');
                $("#div_partsHolder").append(element);
                $("#in_addMaterial").val("");

                $("button", element).click(function(e) { unbindMaterial(e.target); });
            });
        }
    });
}

function setDisponent() {
    $("#modal_loading").modal("show");

    $.ajax({
        url: rootPath + "Forms/SetDisponent",
        type: "POST",
        data: JSON.stringify({
            "formCode": $("#Code").val(),
            "disponentId": $("#div_dispoHeader select").val()
        }),
        dataType: "json",
        contentType: "application/json; charset=utf-8",
        success: function (r, s, x) {
            defaultAjaxCallback(r, s, x, function () {
            });
        }
    });
}

function unbindMaterial(element) {
    $("#modal_loading").modal("show");
    var parentElement = $(element).parent();
    var materialNumber = $("span", parentElement).text();

    $.ajax({
        url: rootPath + "Forms/UnbindMaterial",
        type: "POST",
        data: JSON.stringify({
            "formCode": $("#Code").val(),
            "materialNumber": materialNumber
        }),
        dataType: "json",
        contentType: "application/json; charset=utf-8",
        success: function (r, s, x) {
            defaultAjaxCallback(r, s, x, function () {
                parentElement.remove();
            });
        },
        error: function (r, s, x) {
            defaultAjaxCallback(r, s, x, function () {
                alert(x);
            });
        }
    });
}

function validateForm() {
    var result = true;
    $.each($(':input[required]:visible'), function () {
        if ($(this).val() === "") {
            $(this).addClass("is-invalid");
            $(this).focus();
            result = false;
        }
        else {
            $(this).removeClass("is-invalid");
        }
    });
    return result;
}

function submitResponses(final) {
    $("#modal_loading").modal("show");
    var questions_rows = $("#div_questionsHolder > div");
    var responseObject = {};
    responseObject.Code = $("#Code").val();
    responseObject.Final = final;
    responseObject.Comment = $("#ta_currentComment").val();
    responseObject.ResponseArray = [];
    responseObject.LangCode = $("#Supplier_LangCode").val();
    responseObject.ContactProjectManagement = $("#ContactProjectManagement").val();
    responseObject.ContactRepresentationOfManager = $("#ContactRepresentationOfManager").val();
    responseObject.ContactLogistics247 = $("#ContactLogistics247").val();
    responseObject.ContactQuality = $("#ContactQuality").val();
    responseObject.ContactEscalation = $("#ContactEscalation").val();
    $.each(questions_rows, function () {
        var question_response = {};
        var thisObject = $(this);
        if ($(".chbx-positive", thisObject).prop("checked") || $(".chbx-negative", thisObject).prop("checked")) {
            question_response.QuestionId = thisObject.attr("id");
            question_response.FormId = responseObject.FormId;
            question_response.ResponseValue = $(".chbx-positive", thisObject).prop("checked");
            question_response.ResponseReason = $(".in-responseReason", thisObject).val();
            responseObject.ResponseArray.push(question_response);
        }
    });

    $.ajax({
        url: rootPath + "Forms/SubmitResponses",
        type: "POST",
        data: JSON.stringify(responseObject),
        dataType: "json",
        contentType: "application/json; charset=utf-8",
        success: function (r, s, x) {
            defaultAjaxCallback(r, s, x, function () {
                //window.location = "/Forms/Display/" + responseObject.FormId;
                location.reload();
            });
        },
        error: function (r, s, x) {
            defaultAjaxCallback(r, s, x, function () {
                alert(x);
            });
        }
    });
}