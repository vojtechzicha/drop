﻿$(document).ready(function () {
    initFilter();
    
    $("#div_PID input[type=checkbox]").change(getPrefilteredData);
    $("#div_WERK input[type=checkbox]").change(getPrefilteredData);
    $("#div_SOP select").change(function () { getPrefilteredData(null, true); });

    $("#btn_overview").click(function () {
        $("#modal_loading").modal("show");
        var filter = fillFilter();
        window.location = rootPath + "Filter/FilterResult?data=" + encodeURIComponent(JSON.stringify(filter));
    });
    $("#btn_managerOverview").click(function () {
        $("#modal_loading").modal("show");
        var filter = fillFilter();
        window.location = rootPath + "Report/ReportResult?data=" + encodeURIComponent(JSON.stringify(filter));
    });
});

function initFilter() {
    var inFilter = $.parseJSON($("#in_filter").val());
    if (inFilter) {
        $.each(inFilter.PIDs, function () {
            if ($("#div_PID #" + this).length) {
                $("#div_PID #" + this + " input[type=checkbox]").prop('checked', true);
            }
        });

        $.each(inFilter.WERKs, function () {
            if ($("#div_WERK #" + this).length) {
                $("#div_WERK #" + this + " input[type=checkbox]").prop('checked', true);
            }
        });

        if (inFilter.Unfinished)
            $("#div_unfinished input[type=checkbox]").prop("checked", true);

        getPrefilteredData(function () {
            $("select option:selected").prop("selected", false);

            if (inFilter.OS && inFilter.OS.length > 0) {
                $.each(inFilter.OS, function (index, element) {
                    var opts = $("#div_OS select option");
                    $.each(opts, function () {
                        var thisObj = $(this);
                        if (thisObj.text() == element) {
                            thisObj.prop("selected", true);
                            return false;
                        }
                    });
                });
            }

            if (inFilter.PVS && inFilter.PVS.length > 0) {
                $.each(inFilter.PVS, function (index, element) {
                    var opts = $("#div_PVS select option");
                    $.each(opts, function () {
                        var thisObj = $(this);
                        if (thisObj.text() == element) {
                            thisObj.prop("selected", true);
                            return false;
                        }
                    });
                });
            }

            if (inFilter.SOP && inFilter.SOP.length > 0) {
                $.each(inFilter.SOP, function (index, element) {
                    var opts = $("#div_SOP select option");
                    $.each(opts, function () {
                        var thisObj = $(this);
                        if (thisObj.text() == element) {
                            thisObj.prop("selected", true);
                            return false;
                        }
                    });
                });
            }

            if (inFilter.VFF && inFilter.VFF.length > 0) {
                $.each(inFilter.VFF, function (index, element) {
                    var opts = $("#div_VFF select option");
                    $.each(opts, function () {
                        var thisObj = $(this);
                        if (thisObj.text() == element) {
                            thisObj.prop("selected", true);
                            return false;
                        }
                    });
                });
            }

            if (inFilter.Disponents && inFilter.Disponents.length > 0) {
                $.each(inFilter.Disponents, function () {
                    $("#div_disponents select #" + this).prop("selected", true);
                });
            }

            if (inFilter.Suppliers && inFilter.Suppliers.length > 0) {
                $.each(inFilter.Suppliers, function () {
                    $("#div_suppliers select #" + this).prop("selected", true);
                });
            }
        });
    }
}

function fillFilter() {
    var model = {};

    var checkedProjects = $("#div_PID input[type=checkbox]:checked");
    if (checkedProjects.length) {
        model.PIDs = [];
        $.each(checkedProjects, function () {
            model.PIDs.push($(this).parent().attr("Id"));
        });
    }

    var checkedWERKs = $("#div_WERK input[type=checkbox]:checked");
    if (checkedWERKs.length) {
        model.WERKs = [];
        $.each(checkedWERKs, function () {
            model.WERKs.push($(this).parent().attr("Id"));
        });
    }

    var selectedSOP = $("#div_SOP option:selected");
    if (selectedSOP.length) {
        model.SOP = [];
        $.each(selectedSOP, function () {
            model.SOP.push(this.label);
        });
    }
    var selectedPVS = $("#div_PVS option:selected");
    if (selectedPVS.length) {
        model.PVS = [];
        $.each(selectedPVS, function () {
            model.PVS.push(this.label);
        });
    }
    var selectedVFF = $("#div_VFF option:selected");
    if (selectedVFF.length) {
        model.VFF = [];
        $.each(selectedVFF, function () {
            model.VFF.push(this.label);
        });
    }
    var selected0S = $("#div_OS option:selected");
    if (selected0S.length) {
        model.OS = [];
        $.each(selected0S, function () {
            model.OS.push(this.label);
        });
    }

    var selectedDisponents = $("#div_disponents option:selected");
    if (selectedDisponents.length) {
        model.Disponents = [];
        $.each(selectedDisponents, function () {
            model.Disponents.push($(this).attr("id"));
        });
    }

    var selectedSuppliers = $("#div_suppliers option:selected");
    if (selectedSuppliers.length) {
        model.Suppliers = [];
        $.each(selectedSuppliers, function () {
            model.Suppliers.push($(this).attr("id"));
        });
    }

    model.Unfinished = $("#div_unfinished input[type=checkbox]:checked").length > 0;
    return model;
}

function getPrefilteredData(successCallback, includeSop) {
    $("#modal_loading").modal("show");
    var model = {
        PIDs: [],
        WERKs: [],
        //SOPs: []
    };
    var checkedProjects = $("#div_PID input[type=checkbox]:checked");
    if (checkedProjects.length) {
        $.each(checkedProjects, function () {
            model.PIDs.push($(this).parent().attr("Id"));
        });
    }

    var checkedWERKs = $("#div_WERK input[type=checkbox]:checked");
    if (checkedWERKs.length) {
        $.each(checkedWERKs, function () {
            model.WERKs.push($(this).parent().attr("Id"));
        });
    }

    if (includeSop) {
        model.SOPs = [];
        var selectedSOPs = $("#div_SOP select option:selected");
        if (selectedSOPs.length) {
            $.each(selectedSOPs, function () {
                model.SOPs.push($(this).val());
            });
        }
    }

    if (checkedWERKs.length || checkedProjects.length) {
        var dataStr = JSON.stringify(model);//includeSop ? JSON.stringify({ PIDs: model.PIDs, WERKs: model.WERKs, SOPs: model. }) : JSON.stringify({ PIDs: model.PIDs, WERKs: model.WERKs });
        $.ajax({
            url: rootPath + "Filter/GetPrefilteredData",
            type: "POST",
            data: dataStr,
            contentType: "application/json; charset=utf-8",
            dataType: 'json',
            success:
                function (r, s, x) {
                    defaultAjaxCallback(r, s, x,
                        function (r, s, x) {
                            $(".filter-container").show();
                            $("#div_VFF select").empty();
                            $.each(r.vffMilestones, function () {
                                var option = $("<option value='" + this.replace("/", "-") + "'>" + this + "</option>");
                                option.prop("selected", "selected");
                                $("#div_VFF select").append(option);
                            });

                            if (r.sopMilestones && r.sopMilestones.length) {
                                $("#div_SOP select").empty();
                                $.each(r.sopMilestones, function () {
                                    var option = $("<option value='" + this.replace("/","-") + "'>" + this + "</option>");
                                    option.prop("selected", "selected");
                                    $("#div_SOP select").append(option);
                                });
                            }

                            $("#div_PVS select").empty();
                            $.each(r.pvsMilestones, function () {
                                var option = $("<option value='" + this.replace("/", "-") + "'>" + this + "</option>");
                                option.prop("selected", "selected");
                                $("#div_PVS select").append(option);
                            });

                            $("#div_OS select").empty();
                            $.each(r.osMilestones, function () {
                                var option = $("<option value='" + this.replace("/", "-") + "'>" + this + "</option>");
                                option.prop("selected", "selected");
                                $("#div_OS select").append(option);
                            });

                            $("#div_disponents select").empty();
                            $.each(r.disponents, function () {
                                var option = $("<option id='" + this.Id + "' value='" + this.Id + "'>" + this.Name + "</option>");
                                option.prop("selected", "selected");
                                $("#div_disponents select").append(option);
                            });

                            $("#div_suppliers select").empty();
                            $.each(r.suppliers, function () {
                                var option = $("<option id='" + this.Id + "' value='" + this.Id + "'>" + this.Name + "</option>");
                                option.prop("selected", "selected");
                                $("#div_suppliers select").append(option);
                            });

                            if (isFunction(successCallback))
                                successCallback();
                        })
                },
            error: function (r, s, x) {
                defaultAjaxCallback(r, s, x, function () {
                    alert("ERROR!");
                });
            }
        });
    } else {
        $(".filter-container select").empty();
        defaultAjaxCallback();
    }
}