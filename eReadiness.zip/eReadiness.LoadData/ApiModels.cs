﻿using RestSharp.Deserializers;
using System;

namespace eReadiness.LoadData
{
    public class gz02t00red
    {
        [DeserializeAs(Name = "teil-nr")]
        public string TeilNr { get; set; }
        [DeserializeAs(Name = "ben1-cz")]
        public string Ben1Cz { get; set; }
        [DeserializeAs(Name = "ben2-cz")]
        public string Ben2Cz { get; set; }
        [DeserializeAs(Name = "ben1-d")]
        public string Ben1 { get; set; }
        [DeserializeAs(Name = "ben2-d")]
        public string Ben2 { get; set; }
        [DeserializeAs(Name = "ben1-us")]
        public string Ben1Us { get; set; }
        [DeserializeAs(Name = "ben2-us")]
        public string Ben2Us { get; set; }
        [DeserializeAs(Name = "z")]
        public string Z { get; set; }
        [DeserializeAs(Name = "egew")]
        public string Egew { get; set; }
        [DeserializeAs(Name = "ggew")]
        public string Ggew { get; set; }
        [DeserializeAs(Name = "gkz")]
        public string Gkz { get; set; }
        [DeserializeAs(Name = "fab")]
        public string Fab { get; set; }
        [DeserializeAs(Name = "sich")]
        public string Sich { get; set; }
        [DeserializeAs(Name = "kz-z")]
        public string Kz { get; set; }
        [DeserializeAs(Name = "zdatum")]
        public string Zdatum { get; set; }
        [DeserializeAs(Name = "szeichn")]
        public string Szeichn { get; set; }
        [DeserializeAs(Name = "oberfl")]
        public string Oberfl { get; set; }
        [DeserializeAs(Name = "din")]
        public string Din { get; set; }
        [DeserializeAs(Name = "liz")]
        public string Liz { get; set; }
        [DeserializeAs(Name = "c")]
        public string C { get; set; }
        [DeserializeAs(Name = "nla")]
        public string Nla { get; set; }
        [DeserializeAs(Name = "mat")]
        public string Mat { get; set; }
        [DeserializeAs(Name = "qualitaet")]
        public string Qualitaet { get; set; }
        [DeserializeAs(Name = "fe-gew-ges")]
        public string FeGewGes { get; set; }
        [DeserializeAs(Name = "fe-gew-gwg")]
        public string FeGewGwg { get; set; }
        [DeserializeAs(Name = "bau-must1-kz")]
        public string BauMust1Kz { get; set; }
        [DeserializeAs(Name = "bau-must2-kz")]
        public string BauMust2Kz { get; set; }
        [DeserializeAs(Name = "baumuster3-kz")]
        public string Baumuster3Kz { get; set; }
        [DeserializeAs(Name = "bau-must4-kz")]
        public string BauMust4Kz { get; set; }
        [DeserializeAs(Name = "bau-must1-lief")]
        public string BauMust1Lief { get; set; }
        [DeserializeAs(Name = "bau-must2-lief")]
        public string BauMust2Lief { get; set; }
        [DeserializeAs(Name = "bau-must3-lief")]
        public string BauMust3Lief { get; set; }
        [DeserializeAs(Name = "bau-must4-lief")]
        public string BauMust4Lief { get; set; }
        [DeserializeAs(Name = "bau-must1-schl")]
        public string BauMust1Schl { get; set; }
        [DeserializeAs(Name = "bau-must2-schl")]
        public string BauMust2Schl { get; set; }
        [DeserializeAs(Name = "bau-must3-schl")]
        public string BauMust3Schl { get; set; }
        [DeserializeAs(Name = "bau-must4-schl")]
        public string BauMust4Schl { get; set; }
    }

    public class gz02t90
    {
        [DeserializeAs(Name = "last-load-redtables")]
        public DateTime LastLoadRedtables { get; set; }
        [DeserializeAs(Name = "last-load-wkterm")]
        public DateTime LastLoadWkterm { get; set; }
        [DeserializeAs(Name = "last-load-stereo")]
        public DateTime LastLoadStereo { get; set; }
        [DeserializeAs(Name = "last-load-fakom")]
        public DateTime LastLoadFakom { get; set; }
        [DeserializeAs(Name = "last-load-mbt")]
        public DateTime LastLoadMbt { get; set; }
        [DeserializeAs(Name = "last-load-teivon")]
        public DateTime LastLoadTeivon { get; set; }
        [DeserializeAs(Name = "last-load-dispo")]
        public DateTime LastLoadDispo { get; set; }
        [DeserializeAs(Name = "last-count-es")]
        public int LastCountEs { get; set; }
        [DeserializeAs(Name = "last-wkterm")]
        public int LastWkterm { get; set; }
    }

    public class gz04t00red
    {
        [DeserializeAs(Name = "lfdnr")]
        public int Lfdnr { get; set; }
        [DeserializeAs(Name = "umf")]
        public string Umf { get; set; }
        [DeserializeAs(Name = "takt")]
        public string Takt { get; set; }
        [DeserializeAs(Name = "teil-nr")]
        public string TeilNr { get; set; }
        [DeserializeAs(Name = "pfl")]
        public string Pfl { get; set; }
        [DeserializeAs(Name = "arb-pak-nr")]
        public string ArbPakNr { get; set; }
        [DeserializeAs(Name = "menge")]
        public int Menge { get; set; }
        [DeserializeAs(Name = "me")]
        public string Me { get; set; }
        [DeserializeAs(Name = "wwkz")]
        public string Wwkz { get; set; }
        [DeserializeAs(Name = "tegue")]
        public string Tegue { get; set; }
        [DeserializeAs(Name = "einschl")]
        public string Einschl { get; set; }
        [DeserializeAs(Name = "entschl")]
        public string Entschl { get; set; }
        [DeserializeAs(Name = "eins-ser")]
        public string EinsSer { get; set; }
        [DeserializeAs(Name = "entf-ser")]
        public string EntfSer { get; set; }
        [DeserializeAs(Name = "eins-null")]
        public string EinsNull { get; set; }
        [DeserializeAs(Name = "entf-null")]
        public string EntfNull { get; set; }
        [DeserializeAs(Name = "tyko")]
        public string Tyko { get; set; }
        [DeserializeAs(Name = "u-kz")]
        public string UKz { get; set; }
        [DeserializeAs(Name = "wk-1")]
        public string Wk1 { get; set; }
        [DeserializeAs(Name = "plan-1")]
        public string Plan1 { get; set; }
        [DeserializeAs(Name = "bza-1")]
        public string Bza1 { get; set; }
        [DeserializeAs(Name = "wk-2")]
        public string Wk2 { get; set; }
        [DeserializeAs(Name = "plan-2")]
        public string Plan2 { get; set; }
        [DeserializeAs(Name = "bza-2")]
        public string Bza2 { get; set; }
        [DeserializeAs(Name = "wk-3")]
        public string Wk3 { get; set; }
        [DeserializeAs(Name = "plan-3")]
        public string Plan3 { get; set; }
        [DeserializeAs(Name = "bza-3")]
        public string Bza3 { get; set; }
        [DeserializeAs(Name = "wk-4")]
        public string Wk4 { get; set; }
        [DeserializeAs(Name = "plan-4")]
        public string Plan4 { get; set; }
        [DeserializeAs(Name = "bza-4")]
        public string Bza4 { get; set; }
        [DeserializeAs(Name = "wk-5")]
        public string Wk5 { get; set; }
        [DeserializeAs(Name = "plan-5")]
        public string Plan5 { get; set; }
        [DeserializeAs(Name = "bza-5")]
        public string Bza5 { get; set; }
        [DeserializeAs(Name = "wk-6")]
        public string Wk6 { get; set; }
        [DeserializeAs(Name = "plan-6")]
        public string Plan6 { get; set; }
        [DeserializeAs(Name = "bza-6")]
        public string Bza6 { get; set; }
        [DeserializeAs(Name = "wk-7")]
        public string Wk7 { get; set; }
        [DeserializeAs(Name = "plan-7")]
        public string Plan7 { get; set; }
        [DeserializeAs(Name = "bza-7")]
        public string Bza7 { get; set; }
        [DeserializeAs(Name = "zp")]
        public string Zp { get; set; }
        [DeserializeAs(Name = "tauf-bem")]
        public string TaufBem { get; set; }
        [DeserializeAs(Name = "kost1")]
        public string Kost1 { get; set; }
        [DeserializeAs(Name = "kost2")]
        public string Kost2 { get; set; }
        [DeserializeAs(Name = "kost3")]
        public string Kost3 { get; set; }
        [DeserializeAs(Name = "kost4")]
        public string Kost4 { get; set; }
        [DeserializeAs(Name = "kost5")]
        public string Kost5 { get; set; }
        [DeserializeAs(Name = "tart")]
        public string Tart { get; set; }
        [DeserializeAs(Name = "bs")]
        public string Bs { get; set; }
        [DeserializeAs(Name = "fkd")]
        public string Fkd { get; set; }
        [DeserializeAs(Name = "prod")]
        public string Prod { get; set; }
        [DeserializeAs(Name = "prod-id")]
        public string ProdId { get; set; }
        [DeserializeAs(Name = "platf-kz")]
        public string PlatfKz { get; set; }
        [DeserializeAs(Name = "nla-ss")]
        public string NlaSs { get; set; }
        [DeserializeAs(Name = "kostgr")]
        public string Kostgr { get; set; }
        [DeserializeAs(Name = "szusatzben")]
        public string Szusatzben { get; set; }
        [DeserializeAs(Name = "ent-kz")]
        public string EntKz { get; set; }
        [DeserializeAs(Name = "pl-p-frg")]
        public string PlPFrg { get; set; }
        [DeserializeAs(Name = "pl-b-frg")]
        public string PlBFrg { get; set; }
        [DeserializeAs(Name = "kona-d")]
        public string KonaD { get; set; }
        [DeserializeAs(Name = "ent-st")]
        public string EntSt { get; set; }
        [DeserializeAs(Name = "umf-ref")]
        public string UmfRef { get; set; }
        [DeserializeAs(Name = "takt-ref")]
        public string TaktRef { get; set; }
        [DeserializeAs(Name = "lfdnr-ref")]
        public int LfdnrRef { get; set; }
        [DeserializeAs(Name = "mod-kz")]
        public string ModKz { get; set; }
        [DeserializeAs(Name = "tauf-n")]
        public string TaufN { get; set; }
        [DeserializeAs(Name = "tauf-l")]
        public string TaufL { get; set; }
        [DeserializeAs(Name = "fe-bem")]
        public string FeBem { get; set; }
        [DeserializeAs(Name = "gkz")]
        public string Gkz { get; set; }
        [DeserializeAs(Name = "nkz-1")]
        public string Nkz1 { get; set; }
        [DeserializeAs(Name = "nkz-2")]
        public string Nkz2 { get; set; }
        [DeserializeAs(Name = "nkz-3")]
        public string Nkz3 { get; set; }
        [DeserializeAs(Name = "linie")]
        public string Linie { get; set; }
        [DeserializeAs(Name = "pindex")]
        public int Pindex { get; set; }
        [DeserializeAs(Name = "eindex")]
        public int Eindex { get; set; }
        [DeserializeAs(Name = "sindex")]
        public int Sindex { get; set; }
        [DeserializeAs(Name = "mindex")]
        public int Mindex { get; set; }
        [DeserializeAs(Name = "meindex")]
        public int Meindex { get; set; }
        [DeserializeAs(Name = "tegue2")]
        public string Tegue2 { get; set; }
    }

    public class gz17t64wk
    {
        [DeserializeAs(Name = "terka")]
        public int Terka { get; set; }
        [DeserializeAs(Name = "umf")]
        public string Umf { get; set; }
        [DeserializeAs(Name = "takt")]
        public string Takt { get; set; }
        [DeserializeAs(Name = "fkz")]
        public string Fkz { get; set; }
        [DeserializeAs(Name = "mj")]
        public string Mj { get; set; }
        [DeserializeAs(Name = "ad-i")]
        public string AdI { get; set; }
        [DeserializeAs(Name = "lfdnr")]
        public int Lfdnr { get; set; }
        [DeserializeAs(Name = "wk")]
        public string Wk { get; set; }
        [DeserializeAs(Name = "teil-nr")]
        public string TeilNr { get; set; }
        [DeserializeAs(Name = "desen")]
        public string Desen { get; set; }
        [DeserializeAs(Name = "prod")]
        public string Prod { get; set; }
        [DeserializeAs(Name = "einschl")]
        public string Einschl { get; set; }
        [DeserializeAs(Name = "entschl")]
        public string Entschl { get; set; }
        [DeserializeAs(Name = "einschl-es")]
        public string EinschlEs { get; set; }
        [DeserializeAs(Name = "entschl-es")]
        public string EntschlEs { get; set; }
        [DeserializeAs(Name = "eins-ser-es")]
        public string EinsSerEs { get; set; }
        [DeserializeAs(Name = "entf-ser-es")]
        public string EntfSerEs { get; set; }
        [DeserializeAs(Name = "prkov")]
        public int Prkov { get; set; }
        [DeserializeAs(Name = "prpod")]
        public string Prpod { get; set; }
        [DeserializeAs(Name = "eins-ser")]
        public string EinsSer { get; set; }
        [DeserializeAs(Name = "entf-ser")]
        public string EntfSer { get; set; }
        [DeserializeAs(Name = "te-be")]
        public string TeBe { get; set; }
        [DeserializeAs(Name = "bza")]
        public string Bza { get; set; }
        [DeserializeAs(Name = "aekz")]
        public string Aekz { get; set; }
        [DeserializeAs(Name = "prod-id")]
        public string ProdId { get; set; }
        [DeserializeAs(Name = "pr-nummern")]
        public string PrNummern { get; set; }
        [DeserializeAs(Name = "prpod_kum")]
        public string PrpodKum { get; set; }
        [DeserializeAs(Name = "valid")]
        public string Valid { get; set; }
    }

    public class gz27v01_lotse
    {
        [DeserializeAs(Name = "cdilu")]
        public string Cdilu { get; set; }

        [DeserializeAs(Name = "dispowk")]
        public string Dispowk { get; set; }

        [DeserializeAs(Name = "werk")]
        public string Werk { get; set; }

        [DeserializeAs(Name = "verw")]
        public string Verw { get; set; }

        [DeserializeAs(Name = "cdilu-sach")]
        public string CdiluSach { get; set; }

        [DeserializeAs(Name = "bstlager")]
        public string Bstlager { get; set; }

        [DeserializeAs(Name = "ersm")]
        public string Ersm { get; set; }

        [DeserializeAs(Name = "wkstgr")]
        public string Wkstgr { get; set; }

        [DeserializeAs(Name = "snrbez")]
        public string Snrbez { get; set; }

        [DeserializeAs(Name = "insp-vorl")]
        public string InspVorl { get; set; }

        [DeserializeAs(Name = "sich-tage")]
        public string SichTage { get; set; }

        [DeserializeAs(Name = "betr-vorl")]
        public string BetrVorl { get; set; }

        [DeserializeAs(Name = "smm")]
        public string Smm { get; set; }

        [DeserializeAs(Name = "kmm")]
        public string Kmm { get; set; }

        [DeserializeAs(Name = "knm")]
        public string Knm { get; set; }

        [DeserializeAs(Name = "max-tage")]
        public string MaxTage { get; set; }

        [DeserializeAs(Name = "min-tage")]
        public string MinTage { get; set; }

        [DeserializeAs(Name = "snrbzart")]
        public string Snrbzart { get; set; }

        [DeserializeAs(Name = "me1")]
        public string Me1 { get; set; }

        [DeserializeAs(Name = "me2")]
        public string Me2 { get; set; }

        [DeserializeAs(Name = "klschlkz")]
        public string Klschlkz { get; set; }

        [DeserializeAs(Name = "max-best")]
        public string MaxBest { get; set; }

        [DeserializeAs(Name = "min-best")]
        public string MinBest { get; set; }

        [DeserializeAs(Name = "snrpst")]
        public string Snrpst { get; set; }

        [DeserializeAs(Name = "sperrkz")]
        public string Sperrkz { get; set; }

        [DeserializeAs(Name = "liefzt")]
        public string Liefzt { get; set; }

        [DeserializeAs(Name = "bstzt")]
        public string Bstzt { get; set; }

        [DeserializeAs(Name = "umrfakt")]
        public string Umrfakt { get; set; }

        [DeserializeAs(Name = "umrfakt-sb")]
        public string UmrfaktSb { get; set; }

        [DeserializeAs(Name = "slb")]
        public string Slb { get; set; }

        [DeserializeAs(Name = "sam")]
        public string Sam { get; set; }

        [DeserializeAs(Name = "abw")]
        public string Abw { get; set; }

        [DeserializeAs(Name = "gl-fakt")]
        public string GlFakt { get; set; }

        [DeserializeAs(Name = "mittelwert")]
        public string Mittelwert { get; set; }

        [DeserializeAs(Name = "mittelwert-kz")]
        public string MittelwertKz { get; set; }

        [DeserializeAs(Name = "ersbdme")]
        public string Ersbdme { get; set; }

        [DeserializeAs(Name = "ausschus")]
        public string Ausschus { get; set; }

        [DeserializeAs(Name = "ersmg")]
        public string Ersmg { get; set; }

        [DeserializeAs(Name = "dispokz-wk")]
        public string DispokzWk { get; set; }

        [DeserializeAs(Name = "dispokz-disp")]
        public string DispokzDisp { get; set; }

        [DeserializeAs(Name = "besi3")]
        public string Besi3 { get; set; }

        [DeserializeAs(Name = "abcwerkz")]
        public string Abcwerkz { get; set; }

        [DeserializeAs(Name = "aussch")]
        public string Aussch { get; set; }

        [DeserializeAs(Name = "entf")]
        public string Entf { get; set; }

        [DeserializeAs(Name = "filler2")]
        public string Filler2 { get; set; }

        [DeserializeAs(Name = "anf_be")]
        public string AnfBe { get; set; }

        [DeserializeAs(Name = "sd-datum")]
        public string SdDatum { get; set; }

        [DeserializeAs(Name = "syslikz")]
        public string Syslikz { get; set; }

        [DeserializeAs(Name = "vorlra")]
        public string Vorlra { get; set; }

        [DeserializeAs(Name = "ukdatexs")]
        public string Ukdatexs { get; set; }

        [DeserializeAs(Name = "ex-glae")]
        public string ExGlae { get; set; }

        [DeserializeAs(Name = "dispost")]
        public string Dispost { get; set; }

        [DeserializeAs(Name = "vorschst")]
        public string Vorschst { get; set; }

        [DeserializeAs(Name = "steunr")]
        public string Steunr { get; set; }

        [DeserializeAs(Name = "emanr")]
        public string Emanr { get; set; }

        [DeserializeAs(Name = "zp-aufl-kz")]
        public string ZpAuflKz { get; set; }

        [DeserializeAs(Name = "zp-geulig")]
        public string ZpGeulig { get; set; }

        [DeserializeAs(Name = "ukabldat")]
        public string Ukabldat { get; set; }

        [DeserializeAs(Name = "verb-fert")]
        public string VerbFert { get; set; }

        [DeserializeAs(Name = "sichbekz")]
        public string Sichbekz { get; set; }

        [DeserializeAs(Name = "afokz")]
        public string Afokz { get; set; }

        [DeserializeAs(Name = "auschlst")]
        public string Auschlst { get; set; }

        [DeserializeAs(Name = "rez10")]
        public string Rez10 { get; set; }

        [DeserializeAs(Name = "strbst")]
        public string Strbst { get; set; }

        [DeserializeAs(Name = "mitwezwi")]
        public string Mitwezwi { get; set; }

        [DeserializeAs(Name = "mad-wert")]
        public string MadWert { get; set; }

        [DeserializeAs(Name = "snrreskz")]
        public string Snrreskz { get; set; }

        [DeserializeAs(Name = "tgnwk")]
        public string Tgnwk { get; set; }

        [DeserializeAs(Name = "dispwk")]
        public string Dispwk { get; set; }

        [DeserializeAs(Name = "lagwk")]
        public string Lagwk { get; set; }

        [DeserializeAs(Name = "emswerk")]
        public string Emswerk { get; set; }

        [DeserializeAs(Name = "emsverv")]
        public string Emsverv { get; set; }

        [DeserializeAs(Name = "tabteil")]
        public string Tabteil { get; set; }

        [DeserializeAs(Name = "bstftyp")]
        public string Bstftyp { get; set; }

        [DeserializeAs(Name = "rez11")]
        public string Rez11 { get; set; }

        [DeserializeAs(Name = "c-1")]
        public string C1 { get; set; }

        [DeserializeAs(Name = "c-2")]
        public string C2 { get; set; }

        [DeserializeAs(Name = "z-1")]
        public string Z1 { get; set; }

        [DeserializeAs(Name = "rez30")]
        public string Rez30 { get; set; }
    }

    public class contracts
    {
        [DeserializeAs(Name = "cizav")]
        public string Cizav { get; set; }

        [DeserializeAs(Name = "matnr")]
        public string Matnr { get; set; }

        [DeserializeAs(Name = "name1")]
        public string Name1 { get; set; }

        [DeserializeAs(Name = "lifnr")]
        public string Lifnr { get; set; }

        [DeserializeAs(Name = "ebeln")]
        public string Ebeln { get; set; }

        [DeserializeAs(Name = "ebelp")]
        public string Ebelp { get; set; }

        [DeserializeAs(Name = "kvota")]
        public string Kvota { get; set; }

        [DeserializeAs(Name = "datab")]
        public string Datab { get; set; }

        [DeserializeAs(Name = "datbi")]
        public string Datbi { get; set; }

        [DeserializeAs(Name = "ebelnor")]
        public string Ebelnor { get; set; }
    }

    public class ti01t04
    {
        [DeserializeAs(Name = "lfdnr")]
        public int Lfdnr { get; set; }

        [DeserializeAs(Name = "wk")]
        public string Wk { get; set; }

        [DeserializeAs(Name = "umf")]
        public string Umf { get; set; }

        [DeserializeAs(Name = "takt")]
        public string Takt { get; set; }

        [DeserializeAs(Name = "prod")]
        public string Prod { get; set; }

        [DeserializeAs(Name = "teil-nr")]
        public string TeilNr { get; set; }

        [DeserializeAs(Name = "einschl")]
        public string Einschl { get; set; }

        [DeserializeAs(Name = "entschl")]
        public string Entschl { get; set; }

        [DeserializeAs(Name = "eindat-werk")]
        public string EindatWerk { get; set; }

        [DeserializeAs(Name = "entdat-werk")]
        public string EntdatWerk { get; set; }

        [DeserializeAs(Name = "term-source")]
        public string TermSource { get; set; }

        [DeserializeAs(Name = "ass")]
        public string Ass { get; set; }

        [DeserializeAs(Name = "eindat-null-werk")]
        public string EindatNullWerk { get; set; }

        [DeserializeAs(Name = "eindat-pvs-werk")]
        public string EindatPvsWerk { get; set; }

        [DeserializeAs(Name = "entdat-null-werk")]
        public string EntdatNullWerk { get; set; }

        [DeserializeAs(Name = "entdat-pvs-werk")]
        public string EntdatPvsWerk { get; set; }

        [DeserializeAs(Name = "prod-id")]
        public string ProdId { get; set; }
    }

    public class ti10t08_planbest
    {
        [DeserializeAs(Name = "aend-kz")]
        public string AendKz { get; set; }

        [DeserializeAs(Name = "tnr")]
        public string Tnr { get; set; }

        [DeserializeAs(Name = "gkz")]
        public string Gkz { get; set; }

        [DeserializeAs(Name = "liefnr")]
        public string Liefnr { get; set; }

        [DeserializeAs(Name = "liefidx")]
        public string Liefidx { get; set; }

        [DeserializeAs(Name = "bestnr")]
        public string Bestnr { get; set; }

        [DeserializeAs(Name = "gilt-ab")]
        public string GiltAb { get; set; }

        [DeserializeAs(Name = "gilt-bis")]
        public string GiltBis { get; set; }

        [DeserializeAs(Name = "wk")]
        public string Wk { get; set; }

        [DeserializeAs(Name = "quote")]
        public string Quote { get; set; }

        [DeserializeAs(Name = "bestmenge")]
        public string Bestmenge { get; set; }

        [DeserializeAs(Name = "me")]
        public string Me { get; set; }

        [DeserializeAs(Name = "a-preis")]
        public string APreis { get; set; }

        [DeserializeAs(Name = "wae-kz")]
        public string WaeKz { get; set; }

        [DeserializeAs(Name = "pe")]
        public string Pe { get; set; }

        [DeserializeAs(Name = "lb")]
        public string Lb { get; set; }

        [DeserializeAs(Name = "zb")]
        public string Zb { get; set; }

        [DeserializeAs(Name = "vb")]
        public string Vb { get; set; }

        [DeserializeAs(Name = "duns-nr")]
        public string DunsNr { get; set; }
    }


    public class ti10t08_planepnr
    {
        [DeserializeAs(Name = "aend-kz")]
        public string AendKz { get; set; }

        [DeserializeAs(Name = "pid")]
        public string Pid { get; set; }

        [DeserializeAs(Name = "epnr")]
        public string Epnr { get; set; }

        [DeserializeAs(Name = "teil-nr")]
        public string TeilNr { get; set; }

        [DeserializeAs(Name = "fkz")]
        public string Fkz { get; set; }

        [DeserializeAs(Name = "lief-nr")]
        public string LiefNr { get; set; }

        [DeserializeAs(Name = "lief-bez")]
        public string LiefBez { get; set; }

        [DeserializeAs(Name = "mustersoll-1")]
        public string Mustersoll1 { get; set; }

        [DeserializeAs(Name = "mustersoll-a")]
        public string MustersollA { get; set; }

        [DeserializeAs(Name = "muster-ist")]
        public string MusterIst { get; set; }

        [DeserializeAs(Name = "werkzeug-kz")]
        public string WerkzeugKz { get; set; }

        [DeserializeAs(Name = "wsg")]
        public string Wsg { get; set; }

        [DeserializeAs(Name = "vda-m")]
        public string VdaM { get; set; }

        [DeserializeAs(Name = "vda-l")]
        public string VdaL { get; set; }

        [DeserializeAs(Name = "vda-f")]
        public string VdaF { get; set; }

        [DeserializeAs(Name = "vda-g")]
        public string VdaG { get; set; }

        [DeserializeAs(Name = "menge")]
        public string Menge { get; set; }

        [DeserializeAs(Name = "bem")]
        public string Bem { get; set; }

        [DeserializeAs(Name = "f-anz")]
        public string FAnz { get; set; }

        [DeserializeAs(Name = "f-soll")]
        public string FSoll { get; set; }

        [DeserializeAs(Name = "f-ist")]
        public string FIst { get; set; }

        [DeserializeAs(Name = "e-anz")]
        public string EAnz { get; set; }

        [DeserializeAs(Name = "e-soll")]
        public string ESoll { get; set; }

        [DeserializeAs(Name = "e-ist")]
        public string EIst { get; set; }

        [DeserializeAs(Name = "m-anz")]
        public string MAnz { get; set; }

        [DeserializeAs(Name = "m-soll")]
        public string MSoll { get; set; }

        [DeserializeAs(Name = "m-ist")]
        public string MIst { get; set; }

        [DeserializeAs(Name = "l-anz")]
        public string LAnz { get; set; }

        [DeserializeAs(Name = "l-soll")]
        public string LSoll { get; set; }

        [DeserializeAs(Name = "l-ist")]
        public string LIst { get; set; }

        [DeserializeAs(Name = "dauer-erstprf")]
        public string DauerErstprf { get; set; }

        [DeserializeAs(Name = "dauer-folgprf")]
        public string DauerFolgprf { get; set; }

        [DeserializeAs(Name = "anz-cub")]
        public string AnzCub { get; set; }

        [DeserializeAs(Name = "anw-dat-lab")]
        public string AnwDatLab { get; set; }

        [DeserializeAs(Name = "anw-dat-mes")]
        public string AnwDatMes { get; set; }

        [DeserializeAs(Name = "anw-dat-ein")]
        public string AnwDatEin { get; set; }

        [DeserializeAs(Name = "anw-dat-fkt")]
        public string AnwDatFkt { get; set; }

        [DeserializeAs(Name = "soll-dat-lab")]
        public string SollDatLab { get; set; }

        [DeserializeAs(Name = "soll-dat-mes")]
        public string SollDatMes { get; set; }

        [DeserializeAs(Name = "soll-dat-ein")]
        public string SollDatEin { get; set; }

        [DeserializeAs(Name = "soll-dat-fkt")]
        public string SollDatFkt { get; set; }

        [DeserializeAs(Name = "te-note")]
        public string TeNote { get; set; }

        [DeserializeAs(Name = "te-datum")]
        public string TeDatum { get; set; }

        [DeserializeAs(Name = "zeidat-mb")]
        public string ZeidatMb { get; set; }

        [DeserializeAs(Name = "abschldat")]
        public string Abschldat { get; set; }

        [DeserializeAs(Name = "gewicht")]
        public string Gewicht { get; set; }

        [DeserializeAs(Name = "li-wsg-kz")]
        public string LiWsgKz { get; set; }

        [DeserializeAs(Name = "li-wsg")]
        public string LiWsg { get; set; }

        [DeserializeAs(Name = "li-name")]
        public string LiName { get; set; }

        [DeserializeAs(Name = "li-tel")]
        public string LiTel { get; set; }

        [DeserializeAs(Name = "li-abt")]
        public string LiAbt { get; set; }

        [DeserializeAs(Name = "li-kst")]
        public string LiKst { get; set; }

        [DeserializeAs(Name = "imds")]
        public string Imds { get; set; }

        [DeserializeAs(Name = "sola-sta")]
        public string SolaSta { get; set; }

        [DeserializeAs(Name = "merker-1")]
        public string Merker1 { get; set; }

        [DeserializeAs(Name = "merker-2")]
        public string Merker2 { get; set; }

        [DeserializeAs(Name = "merker-3")]
        public string Merker3 { get; set; }

        [DeserializeAs(Name = "merker-4")]
        public string Merker4 { get; set; }

        [DeserializeAs(Name = "merker-5")]
        public string Merker5 { get; set; }

        [DeserializeAs(Name = "bericht-kz")]
        public string BerichtKz { get; set; }

        [DeserializeAs(Name = "m-prio")]
        public string MPrio { get; set; }

        [DeserializeAs(Name = "versand-datum")]
        public string VersandDatum { get; set; }

        [DeserializeAs(Name = "filler")]
        public string Filler { get; set; }
    }

    public class ti10t08_planlief
    {
        [DeserializeAs(Name = "aend-kz")]
        public string AendKz { get; set; }
        [DeserializeAs(Name = "pid")]
        public string Pid { get; set; }
        [DeserializeAs(Name = "teil-nr")]
        public string TeilNr { get; set; }
        [DeserializeAs(Name = "fkz")]
        public string Fkz { get; set; }
        [DeserializeAs(Name = "liefnr")]
        public string Liefnr { get; set; }
        [DeserializeAs(Name = "lief-wk-01")]
        public string LiefWk01 { get; set; }
        [DeserializeAs(Name = "lief-bez")]
        public string LiefBez { get; set; }
        [DeserializeAs(Name = "abschl")]
        public string Abschl { get; set; }
        [DeserializeAs(Name = "mustersoll-1")]
        public string Mustersoll1 { get; set; }
        [DeserializeAs(Name = "mustersoll-a")]
        public string Mustersolla { get; set; }
        [DeserializeAs(Name = "hwz")]
        public string Hwz { get; set; }
        [DeserializeAs(Name = "swz")]
        public string Swz { get; set; }
        [DeserializeAs(Name = "emv")]
        public string Emv { get; set; }
        [DeserializeAs(Name = "wverl")]
        public string Wverl { get; set; }
        [DeserializeAs(Name = "merker-l")]
        public string Merker { get; set; }
        [DeserializeAs(Name = "epnr")]
        public string Epnr { get; set; }
        [DeserializeAs(Name = "csc-preis")]
        public string CscPreis { get; set; }
        [DeserializeAs(Name = "csc-preis-we")]
        public string CscPreisWe { get; set; }
        [DeserializeAs(Name = "csc-preis-wa")]
        public string CscPreisWa { get; set; }
        [DeserializeAs(Name = "csc-preis-wa-we")]
        public string CscPreisWaWe { get; set; }
        [DeserializeAs(Name = "start-ek")]
        public string StartEk { get; set; }
        [DeserializeAs(Name = "k-freigabe")]
        public string Freigabe { get; set; }
        [DeserializeAs(Name = "verh-dauer")]
        public string VerhDauer { get; set; }
        [DeserializeAs(Name = "nom-letter")]
        public string NomLetter { get; set; }
        [DeserializeAs(Name = "kopie")]
        public string Kopie { get; set; }
        [DeserializeAs(Name = "bemi-dauer")]
        public string BemiDauer { get; set; }
        [DeserializeAs(Name = "qel-besp-dat")]
        public string QelBespDat { get; set; }
        [DeserializeAs(Name = "qel-status")]
        public string QelStatus { get; set; }
        [DeserializeAs(Name = "mt-freigabe")]
        public string MtFreigabe { get; set; }
        [DeserializeAs(Name = "zei-an-lief")]
        public string ZeiAnLief { get; set; }
        [DeserializeAs(Name = "zeidat")]
        public string Zeidat { get; set; }
        [DeserializeAs(Name = "zei-freigabe")]
        public string ZeiFreigabe { get; set; }
        [DeserializeAs(Name = "plandate")]
        public string Plandate { get; set; }
        [DeserializeAs(Name = "reason")]
        public string Reason { get; set; }
        [DeserializeAs(Name = "actual-date")]
        public string ActualDate { get; set; }
        [DeserializeAs(Name = "kap-vereinb")]
        public string KapVereinb { get; set; }
        [DeserializeAs(Name = "kap-nutzb")]
        public string KapNutzb { get; set; }
        [DeserializeAs(Name = "kap-durchschn")]
        public string KapDurchschn { get; set; }
        [DeserializeAs(Name = "kap-bewdat")]
        public string KapBewdat { get; set; }
        [DeserializeAs(Name = "lief-wk-02")]
        public string LiefWk02 { get; set; }
        [DeserializeAs(Name = "lief-wk-03")]
        public string LiefWk03 { get; set; }
        [DeserializeAs(Name = "lief-wk-04")]
        public string LiefWk04 { get; set; }
        [DeserializeAs(Name = "lief-wk-05")]
        public string LiefWk05 { get; set; }
        [DeserializeAs(Name = "lief-wk-06")]
        public string LiefWk06 { get; set; }
        [DeserializeAs(Name = "lief-wk-07")]
        public string LiefWk07 { get; set; }
        [DeserializeAs(Name = "lief-wk-08")]
        public string LiefWk08 { get; set; }
        [DeserializeAs(Name = "lief-wk-09")]
        public string LiefWk09 { get; set; }
        [DeserializeAs(Name = "lief-wk-10")]
        public string LiefWk10 { get; set; }
        [DeserializeAs(Name = "lief-wk-11")]
        public string LiefWk11 { get; set; }
        [DeserializeAs(Name = "lief-wk-12")]
        public string LiefWk12 { get; set; }
        [DeserializeAs(Name = "herstellercode")]
        public string Herstellercode { get; set; }
        [DeserializeAs(Name = "duns-nr")]
        public string DunsNr { get; set; }
        [DeserializeAs(Name = "landschl")]
        public string Landschl { get; set; }
        [DeserializeAs(Name = "ortsbez")]
        public string Ortsbez { get; set; }
        [DeserializeAs(Name = "strasse")]
        public string Strasse { get; set; }
        [DeserializeAs(Name = "plz")]
        public string Plz { get; set; }
        [DeserializeAs(Name = "land")]
        public string Land { get; set; }
        [DeserializeAs(Name = "filler")]
        public string Filler { get; set; }
    }


    public class ti10t08_plantgs
    {
        [DeserializeAs(Name = "aend-kz")]
        public string AendKz { get; set; }

        [DeserializeAs(Name = "tnr")]
        public string Tnr { get; set; }

        [DeserializeAs(Name = "lieferant")]
        public string Lieferant { get; set; }

        [DeserializeAs(Name = "gen-stand")]
        public string GenStand { get; set; }

        [DeserializeAs(Name = "ls-id")]
        public string LsId { get; set; }

        [DeserializeAs(Name = "zeich-dat")]
        public string ZeichDat { get; set; }

        [DeserializeAs(Name = "ae-aea")]
        public string AeAea { get; set; }

        [DeserializeAs(Name = "ls-nr")]
        public string LsNr { get; set; }

        [DeserializeAs(Name = "anzahl")]
        public string Anzahl { get; set; }

        [DeserializeAs(Name = "werk")]
        public string Werk { get; set; }

        [DeserializeAs(Name = "duns-nr")]
        public string DunsNr { get; set; }

        [DeserializeAs(Name = "ablade-st")]
        public string AbladeSt { get; set; }
    }

}
