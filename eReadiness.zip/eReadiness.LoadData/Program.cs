﻿using eReadiness.DatabaseModels;
using NLog;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Threading.Tasks;

namespace eReadiness.LoadData
{
    class Program
    {
        private static Logger Log = LogManager.GetCurrentClassLogger();

        public static void Main(string[] args)
        {
            try
            {
                Log.Debug("eReadiness.LoadData starting...");

                Process.GetCurrentProcess().PriorityClass = ProcessPriorityClass.BelowNormal;

                ServicePointManager.Expect100Continue = true;
                ServicePointManager.DefaultConnectionLimit = 9999;
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Ssl3;

                List<DataContext.Models.PID> pids = new List<DataContext.Models.PID>();

                using (var context = new DataContext.ERContext())
                {
                    pids.AddRange(context.PIDs.Where(x => x.DateDeleted == null));
                }
                Stopwatch sw = new Stopwatch();
                sw.Start();

                new ApiLoad<ti10t08_planlief, TI10T08_PLANLIEF>().Copy();


                Truncate(typeof(TI01T04).Name);
                Truncate(typeof(GZ04T00RED).Name);
                Truncate(typeof(GZ17T64WK).Name);
                Truncate(typeof(TI10T08_PLANEPNR).Name);
                Truncate(typeof(TI10T08_PLANLIEF).Name);
                Truncate(typeof(GZ02T00RED).Name);
                Truncate(typeof(GZ02T90).Name);
                Truncate(typeof(SMLOUVY).Name);
                Truncate(typeof(TI10T08_PLANBEST).Name);
                Truncate(typeof(TI10T08_PLANTGS).Name);
                Truncate(typeof(GZ27V01_LOTSE).Name);

                List<Task<int>> tasksPid = new List<Task<int>>();

                List<Task<int>> tasksOther = new List<Task<int>>();
                tasksOther.Add(Task<int>.Factory.StartNew(() => { return new ApiLoad<ti10t08_planbest, TI10T08_PLANBEST>().Copy(); }));


                foreach (var pid in pids)
                {
                    tasksPid.Add(Task<int>.Factory.StartNew(() => { return new ApiLoad<ti01t04, TI01T04>(pid.ProjectCode).Copy(); }));
                    tasksPid.Add(Task<int>.Factory.StartNew(() => { return new ApiLoad<gz04t00red, GZ04T00RED>(pid.ProjectCode).Copy(); }));
                    tasksPid.Add(Task<int>.Factory.StartNew(() => { return new ApiLoad<gz17t64wk, GZ17T64WK>(pid.ProjectCode).Copy(); }));
                    tasksPid.Add(Task<int>.Factory.StartNew(() => { return new ApiLoad<ti10t08_planepnr, TI10T08_PLANEPNR>(pid.ProjectCode).Copy(); }));
                    tasksPid.Add(Task<int>.Factory.StartNew(() => { return new ApiLoad<ti10t08_planlief, TI10T08_PLANLIEF>(pid.ProjectCode).Copy(); }));
                    if (tasksPid.Count >= Properties.Settings.Default.MaxParallel)
                    {
                        Task.WaitAll(tasksPid.ToArray());
                        tasksPid.Clear();
                    }
                }

                if (tasksPid.Count > 0)
                {
                    Task.WaitAll(tasksPid.ToArray());
                    tasksPid.Clear();
                };

                tasksOther.Add(Task<int>.Factory.StartNew(() => { return new ApiLoad<gz27v01_lotse, GZ27V01_LOTSE>().Copy(); }));
                tasksOther.Add(Task<int>.Factory.StartNew(() => { return new ApiLoad<gz02t00red, GZ02T00RED>().Copy(); }));
                tasksOther.Add(Task<int>.Factory.StartNew(() => { return new ApiLoad<gz02t90, GZ02T90>().Copy(); }));
                tasksOther.Add(Task<int>.Factory.StartNew(() => { return new ApiLoad<contracts, SMLOUVY>().Copy(); }));
                tasksOther.Add(Task<int>.Factory.StartNew(() => { return new ApiLoad<ti10t08_plantgs, TI10T08_PLANTGS>().Copy(); }));
                Task.WaitAll(tasksOther.ToArray());

                foreach (var task in tasksOther)
                {
                    Console.WriteLine(task.Result);
                }

                using (var context = new DataContext.ERContext())
                {
                    Log.Debug("eReadiness.LoadData Executing sp LoadData", sw.Elapsed);
                    context.Database.CommandTimeout = 60 * 60 * 10;
                    context.Database.ExecuteSqlCommand("CALL \"LoadData\"()");
                }

                sw.Stop();

                Log.Debug("eReadiness.LoadData Elapsed={0}", sw.Elapsed);
            }
            catch (Exception ex)
            {
                Log.Error(ex);
            }
        }

        public static void Truncate(string tableName)
        {
            using (var connection = new Npgsql.NpgsqlConnection(ConfigurationManager.ConnectionStrings["DataPumpDB"].ConnectionString))
            {
                connection.Open();
                var command = connection.CreateCommand();
                command.CommandText = $"TRUNCATE TABLE  {ConfigurationManager.AppSettings["DefaultSchema"]}.\"{tableName}\"";
                command.ExecuteNonQuery();
            }
        }
    }
}
