﻿using eReadiness.DatabaseModels;
using System.Configuration;
using System.Data.Entity;
using System.Data.Entity.ModelConfiguration.Conventions;

namespace eReadiness.LoadData
{
    public class DPContext : DbContext
    {
        public DbSet<GZ02T00RED> GZ02T00REDs { get; set; }
        public DbSet<GZ02T90> GZ02T90s { get; set; }
        public DbSet<GZ04T00RED> GZ04T00REDs { get; set; }
        public DbSet<GZ17T64WK> GZ17T64WKs { get; set; }
        public DbSet<GZ27V01_LOTSE> GZ27V01_LOTSEs { get; set; }
        public DbSet<SMLOUVY> SMLOUVYs { get; set; }
        public DbSet<TI01T04> TI01T04s { get; set; }
        public DbSet<TI10T08_PLANBEST> TI10T08_PLANBESTs { get; set; }
        public DbSet<TI10T08_PLANEPNR> TI10T08_PLANEPNRs { get; set; }
        public DbSet<TI10T08_PLANLIEF> TI10T08_PLANLIEFs { get; set; }
        public DbSet<TI10T08_PLANTGS> TI10T08_PLANTGSs { get; set; }

        public DPContext() : base(nameOrConnectionString: "DataPumpDB")
        {

        }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Conventions.Remove<PluralizingTableNameConvention>();

            modelBuilder.HasDefaultSchema(ConfigurationManager.AppSettings["DefaultSchema"]);

            base.OnModelCreating(modelBuilder);
        }
    }
}
