﻿using AutoMapper;
using eReadiness.LoadData.Helpers;
using eReadiness.LoadData.Properties;
using NLog;
using RestSharp;
using System.Collections.Generic;
using System.Configuration;
using System.Security.Cryptography.X509Certificates;

namespace eReadiness.LoadData
{
    public class ApiLoad<TApi, TDb>
    {
        private static Logger Log = LogManager.GetCurrentClassLogger();

        private int FetchSize = 10000;

        private RestClient client;
        private string parameter;

        public ApiLoad(string parameter = null)
        {
            FetchSize = Settings.Default.ApiFetchSize;
            this.parameter = parameter;
            client = new RestClient(ConfigurationManager.AppSettings["RestApiURL"]);
            X509Store store = new X509Store(StoreName.My, StoreLocation.LocalMachine);
            store.Open(OpenFlags.ReadOnly);
            X509Certificate2Collection certificates = store.Certificates.Find(X509FindType.FindBySubjectName, ConfigurationManager.AppSettings["RestApiCertificateSubjectName"], true);
            client.ClientCertificates = certificates;
        }

        public int Copy()
        {
            using (var connection = new Npgsql.NpgsqlConnection(ConfigurationManager.ConnectionStrings["DataPumpDB"].ConnectionString))
            {
                var autoMapperConfig = new MapperConfiguration(cfg =>
                {
                    cfg.ReplaceMemberName("_", "");
                    cfg.CreateMap<TApi, TDb>();
                });

                var autoMapper = new Mapper(autoMapperConfig);

                connection.Open();

                int rowCount = 0;
                int offset = 0;
                do
                {
                    List<TDb> insertRows = new List<TDb>();


                    var resource = parameter != null ? typeof(TApi).Name + "/" + parameter : typeof(TApi).Name;
                    resource = resource.Replace("_", "-");

                    RestRequest request = new RestRequest(resource, Method.GET);
                    request.RequestFormat = DataFormat.Json;
                    request.AddHeader("Accept", "application/json");
                    request.AddHeader("x-ibm-client-id", ConfigurationManager.AppSettings["X-IBM-Client-Id"]);

                    request.AddOrUpdateParameter("fetch", FetchSize);
                    request.AddOrUpdateParameter("fetch-offset", offset);

                    var response = client.Execute<List<TApi>>(request);
                    var rows = response.Data;
                    if (rows != null)
                    {
                        rowCount = response.Data.Count;
                        offset = offset + rowCount;

                        foreach (var row in rows)
                        {
                            var newItem = autoMapper.Map<TDb>(row);
                            insertRows.Add(newItem);
                        }
                    }
                    else
                        Log.Debug($"{typeof(TDb).Name} {parameter} : {response.Content}");

                    var postgreSQLCopyHelper = PostgreSQLHelpers.CreateHelper<TDb>(typeof(TDb).Name);
                    postgreSQLCopyHelper.SaveAll(connection, insertRows);

                    Log.Debug($"{typeof(TDb).Name} {parameter} : {offset}");
                }
                while (rowCount == FetchSize);

                Log.Debug($"{typeof(TDb).Name} {parameter} : {offset}");

                return offset;
            }
        }
    }

}
