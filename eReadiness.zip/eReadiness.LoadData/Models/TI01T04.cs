﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace eReadiness.DatabaseModels
{
    public class TI01T04
    {
        [Key]
        public int Id { get; set; }

        [Index]
        public int LFDNR { get; set; }
        [StringLength(2)]
        public string WK { get; set; }
        [StringLength(3)]
        public string UMF { get; set; }
        [StringLength(6)]
        public string TAKT { get; set; }
        [StringLength(4)]
        public string PROD { get; set; }
        [StringLength(12)]
        public string TEIL_NR { get; set; }
        [StringLength(8)]
        public string EINSCHL { get; set; }
        [StringLength(8)]
        public string ENTSCHL { get; set; }
        [StringLength(8)]
        public string EINDAT_WERK { get; set; }
        [StringLength(8)]
        public string ENTDAT_WERK { get; set; }
        [StringLength(1)]
        public string TERM_SOURCE { get; set; }
        [StringLength(1)]
        public string ASS { get; set; }
        [StringLength(8)]
        public string EINDAT_NULL_WERK { get; set; }
        [StringLength(8)]
        public string ENTDAT_NULL_WERK { get; set; }
        [StringLength(8)]
        public string EINDAT_PVS_WERK { get; set; }
        [StringLength(8)]
        public string ENTDAT_PVS_WERK { get; set; }
        [StringLength(3)]
        public string PROD_ID { get; set; }
    }
}
