﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace eReadiness.DatabaseModels
{
    public class GZ27V01_LOTSE
    {
        [Key]
        public int Id { get; set; }
        [Index]
        [StringLength(45)]
        public string CDILU { get; set; }
        [StringLength(6)]
        public string DISPOWK { get; set; }
        [StringLength(6)]
        public string WERK { get; set; }
        [Index]
        [StringLength(6)]
        public string VERW { get; set; }
        [StringLength(27)]
        public string CDILU_SACH { get; set; }
        [StringLength(18)]
        public string BSTLAGER { get; set; }
        [StringLength(3)]
        public string ERSM { get; set; }
        [StringLength(15)]
        public string WKSTGR { get; set; }
        [StringLength(36)]
        public string SNRBEZ { get; set; }
        public /*decimal?*/string INSP_VORL { get; set; }
        public /*decimal?*/string SICH_TAGE { get; set; }
        public /*decimal?*/string BETR_VORL { get; set; }
        [StringLength(3)]
        public string SMM { get; set; }
        [StringLength(3)]
        public string KMM { get; set; }
        [StringLength(3)]
        public string KNM { get; set; }
        public /*decimal?*/string MAX_TAGE { get; set; }
        public /*decimal?*/string MIN_TAGE { get; set; }
        [StringLength(3)]
        public string SNRBZART { get; set; }
        [StringLength(6)]
        public string ME1 { get; set; }
        [StringLength(6)]
        public string ME2 { get; set; }
        [StringLength(3)]
        public string KLSCHLKZ { get; set; }
        public /*decimal?*/string MAX_BEST { get; set; }
        public /*decimal?*/string MIN_BEST { get; set; }
        [StringLength(3)]
        public string SNRPST { get; set; }
        [StringLength(3)]
        public string SPERRKZ { get; set; }
        [StringLength(9)]
        public string LIEFZT { get; set; }
        public /*decimal?*/string BSTZT { get; set; }
        public /*decimal?*/string UMRFAKT { get; set; }
        [StringLength(3)]
        public string UMRFAKT_SB { get; set; }
        [StringLength(3)]
        public string SLB { get; set; }
        [StringLength(3)]
        public string SAM { get; set; }
        public int? ABW { get; set; }
        public decimal? GL_FAKT { get; set; }
        public /*decimal?*/string MITTELWERT { get; set; }
        [StringLength(3)]
        public string MITTELWERT_KZ { get; set; }
        public int? ERSBDME { get; set; }
        public int? AUSSCHUS { get; set; }
        public int? ERSMG { get; set; }
        [StringLength(6)]
        public string DISPOKZ_WK { get; set; }
        [Index]
        [StringLength(8)]
        public string DISPOKZ_DISP { get; set; }
        [StringLength(3)]
        public string BESI3 { get; set; }
        [StringLength(3)]
        public string ABCWERKZ { get; set; }
        public int? AUSSCH { get; set; }
        [StringLength(12)]
        public string ENTF { get; set; }
        [StringLength(6)]
        public string FILLER2 { get; set; }
        [StringLength(3)]
        public string ANF_BE { get; set; }
        [StringLength(18)]
        public string SD_DATUM { get; set; }
        [StringLength(6)]
        public string SYSLIKZ { get; set; }
        public /*decimal?*/string VORLRA { get; set; }
        [StringLength(12)]
        public string UKDATEXS { get; set; }
        [StringLength(3)]
        public string EX_GLAE { get; set; }
        [StringLength(3)]
        public string DISPOST { get; set; }
        [StringLength(3)]
        public string VORSCHST { get; set; }
        [StringLength(3)]
        public string STEUNR { get; set; }
        [StringLength(12)]
        public string EMANR { get; set; }
        [StringLength(6)]
        public string ZP_AUFL_KZ { get; set; }
        [StringLength(3)]
        public string ZP_GEULIG { get; set; }
        public int? UKABLDAT { get; set; }
        [StringLength(3)]
        public string VERB_FERT { get; set; }
        [StringLength(3)]
        public string SICHBEKZ { get; set; }
        [StringLength(3)]
        public string AFOKZ { get; set; }
        [StringLength(3)]
        public string AUSCHLST { get; set; }
        [StringLength(30)]
        public string REZ10 { get; set; }
        [StringLength(3)]
        public string STRBST { get; set; }
        public int? MITWEZWI { get; set; }
        public int? MAD_WERT { get; set; }
        [StringLength(3)]
        public string SNRRESKZ { get; set; }
        [StringLength(6)]
        public string TGNWK { get; set; }
        [StringLength(3)]
        public string DISPWK { get; set; }
        [StringLength(3)]
        public string LAGWK { get; set; }
        [StringLength(3)]
        public string EMSWERK { get; set; }
        [StringLength(6)]
        public string EMSVERV { get; set; }
        [StringLength(3)]
        public string TABTEIL { get; set; }
        [StringLength(3)]
        public string BSTFTYP { get; set; }
        [StringLength(33)]
        public string REZ11 { get; set; }
        public int? C_1 { get; set; }
        public int? C_2 { get; set; }
        [StringLength(9)]
        public string Z_1 { get; set; }
        [StringLength(90)]
        public string REZ30 { get; set; }
    }
}
