﻿using System.ComponentModel.DataAnnotations;

namespace eReadiness.DatabaseModels
{
    public class TI10T08_PLANLIEF
    {
        [Key]
        public int Id { get; set; }
        [StringLength(1)]
        public string AEND_KZ { get; set; }
        [StringLength(3)]
        public string PID { get; set; }
        [StringLength(12)]
        public string TEIL_NR { get; set; }
        [StringLength(10)]
        public string FKZ { get; set; }
        [StringLength(10)]
        public string LIEFNR { get; set; }
        [StringLength(100)]
        public string LIEF_WK_01 { get; set; }
        [StringLength(30)]
        public string LIEF_BEZ { get; set; }
        [StringLength(2)]
        public string ABSCHL { get; set; }
        [StringLength(5)]
        public string MUSTERSOLL_1 { get; set; }
        [StringLength(5)]
        public string MUSTERSOLL_A { get; set; }
        [StringLength(5)]
        public string HWZ { get; set; }
        [StringLength(5)]
        public string SWZ { get; set; }
        [StringLength(5)]
        public string EMV { get; set; }
        [StringLength(5)]
        public string WVERL { get; set; }
        [StringLength(5)]
        public string MERKER_L { get; set; }
        [StringLength(100)]
        public string EPNR { get; set; }
        [StringLength(14)]
        public string CSC_PREIS { get; set; }
        [StringLength(3)]
        public string CSC_PREIS_WE { get; set; }
        [StringLength(14)]
        public string CSC_PREIS_WA { get; set; }
        [StringLength(3)]
        public string CSC_PREIS_WA_WE { get; set; }
        [StringLength(10)]
        public string START_EK { get; set; }
        [StringLength(10)]
        public string K_FREIGABE { get; set; }
        [StringLength(3)]
        public string VERH_DAUER { get; set; }
        [StringLength(10)]
        public string NOM_LETTER { get; set; }
        [StringLength(1)]
        public string KOPIE { get; set; }
        [StringLength(3)]
        public string BEMI_DAUER { get; set; }
        [StringLength(10)]
        public string QEL_BESP_DAT { get; set; }
        [StringLength(1)]
        public string QEL_STATUS { get; set; }
        [StringLength(3)]
        public string MT_FREIGABE { get; set; }
        [StringLength(10)]
        public string ZEI_AN_LIEF { get; set; }
        [StringLength(10)]
        public string ZEIDAT { get; set; }
        [StringLength(1)]      
        public string ZEI_FREIGABE { get; set; }
        [StringLength(10)]
        public string PLANDATE { get; set; }
        [StringLength(3)]
        public string REASON { get; set; }
        [StringLength(10)]
        public string ACTUAL_DATE { get; set; }
        [StringLength(10)]
        public string KAP_VEREINB { get; set; }
        [StringLength(10)]
        public string KAP_NUTZB { get; set; }
        [StringLength(10)]
        public string KAP_DURCHSCHN { get; set; }
        [StringLength(10)]
        public string KAP_BEWDAT { get; set; }
        [StringLength(2)]
        public string LIEF_WK_02 { get; set; }
        [StringLength(2)]
        public string LIEF_WK_03 { get; set; }
        [StringLength(2)]
        public string LIEF_WK_04 { get; set; }
        [StringLength(2)]
        public string LIEF_WK_05 { get; set; }
        [StringLength(2)]
        public string LIEF_WK_06 { get; set; }
        [StringLength(2)]
        public string LIEF_WK_07 { get; set; }
        [StringLength(2)]
        public string LIEF_WK_08 { get; set; }
        [StringLength(2)]
        public string LIEF_WK_09 { get; set; }
        [StringLength(2)]
        public string LIEF_WK_10 { get; set; }
        [StringLength(2)]
        public string LIEF_WK_11 { get; set; }
        [StringLength(2)]
        public string LIEF_WK_12 { get; set; }
        [StringLength(3)]
        public string HERSTELLERCODE { get; set; }
        [StringLength(11)]
        public string DUNS_NR { get; set; }
        [StringLength(3)]
        public string LANDSCHL { get; set; }
        [StringLength(40)]
        public string ORTSBEZ { get; set; }
        [StringLength(30)]
        public string STRASSE { get; set; }
        [StringLength(8)]
        public string PLZ { get; set; }
        [StringLength(30)]
        public string LAND { get; set; }
        [StringLength(76)]
        public string FILLER { get; set; }
    }
}