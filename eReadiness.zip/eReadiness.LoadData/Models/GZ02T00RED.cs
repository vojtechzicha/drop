﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace eReadiness.DatabaseModels
{
    public class GZ02T00RED
    {
        [Key]
        public int Id { get; set; }
        [StringLength(12)]
        [Index]
        public string TEIL_NR { get; set; }
        [StringLength(18)]
        public string BEN1_CZ { get; set; }
        [StringLength(18)]
        public string BEN2_CZ { get; set; }
        [StringLength(18)]
        public string BEN1_D { get; set; }
        [StringLength(18)]
        public string BEN2_D { get; set; }
        [StringLength(18)]
        public string BEN1_US { get; set; }
        [StringLength(18)]
        public string BEN2_US { get; set; }
        [StringLength(1)]
        public string Z { get; set; }
        [StringLength(6)]
        public string EGEW { get; set; }
        [StringLength(6)]
        public string GGEW { get; set; }
        [StringLength(1)]
        public string GKZ { get; set; }
        [StringLength(1)]
        public string FAB { get; set; }
        [StringLength(1)]
        public string SICH { get; set; }
        [StringLength(2)]
        public string KZ_Z { get; set; }
        [StringLength(8)]
        public string ZDATUM { get; set; }
        [StringLength(12)]
        public string SZEICHN { get; set; }
        [StringLength(4)]
        public string OBERFL { get; set; }
        [StringLength(2)]
        public string DIN { get; set; }
        [StringLength(1)]
        public string LIZ { get; set; }
        [StringLength(1)]
        public string C { get; set; }
        [StringLength(1)]
        public string NLA { get; set; }
        [StringLength(3)]
        public string MAT { get; set; }
        [StringLength(12)]
        public string QUALITAET { get; set; }
        [StringLength(6)]
        public string FE_GEW_GES { get; set; }
        [StringLength(6)]
        public string FE_GEW_GWG { get; set; }
        [StringLength(3)]
        public string BAU_MUST1_KZ { get; set; }
        [StringLength(3)]
        public string BAU_MUST2_KZ { get; set; }
        [StringLength(3)]
        public string BAU_MUST3_KZ { get; set; }
        [StringLength(3)]
        public string BAU_MUST4_KZ { get; set; }
        [StringLength(15)]
        public string BAU_MUST1_LIEF { get; set; }
        [StringLength(15)]
        public string BAU_MUST2_LIEF { get; set; }
        [StringLength(15)]
        public string BAU_MUST3_LIEF { get; set; }
        [StringLength(15)]
        public string BAU_MUST4_LIEF { get; set; }
        [StringLength(3)]
        public string BAU_MUST1_SCHL { get; set; }
        [StringLength(3)]
        public string BAU_MUST2_SCHL { get; set; }
        [StringLength(3)]
        public string BAU_MUST3_SCHL { get; set; }
        [StringLength(3)]
        public string BAU_MUST4_SCHL { get; set; }
    }
}
