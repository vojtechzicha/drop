﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace eReadiness.DatabaseModels
{
    public class GZ17T64WK
    {
        [Key]
        public int Id { get; set; }

        public int TERKA { get; set; }
        [StringLength(3)]
        public string UMF { get; set; }
        [StringLength(6)]
        public string TAKT { get; set; }
        [StringLength(3)]
        public string FKZ { get; set; }
        [StringLength(4)]
        public string MJ { get; set; }
        [StringLength(4)]
        public string AD_I { get; set; }
        [Index]
        public int? LFDNR { get; set; }
        [StringLength(2)]
        public string WK { get; set; }
        [StringLength(12)]
        public string TEIL_NR { get; set; }
        [StringLength(3)]
        public string DESEN { get; set; }
        [StringLength(4)]
        public string PROD { get; set; }
        [StringLength(8)]
        public string EINSCHL { get; set; }
        [StringLength(8)]
        public string ENTSCHL { get; set; }
        [StringLength(8)]
        public string EINSCHL_ES { get; set; }
        [StringLength(8)]
        public string ENTSCHL_ES { get; set; }
        [StringLength(8)]
        public string EINS_SER_ES { get; set; }
        [StringLength(8)]
        public string ENTF_SER_ES { get; set; }
        public int? PRKOV { get; set; }
        [StringLength(800)]
        public string PRPOD { get; set; }
        [Index]
        [StringLength(8)]
        public string EINS_SER { get; set; }
        [Index]
        [StringLength(8)]
        public string ENTF_SER { get; set; }
        [StringLength(1)]
        public string TE_BE { get; set; }
        [StringLength(1)]
        public string BZA { get; set; }
        [StringLength(1)]
        public string AEKZ { get; set; }
        [StringLength(3)]
        public string PROD_ID { get; set; }
        [StringLength(1000)]
        public string PR_NUMMERN { get; set; }
        [StringLength(1000)]
        public string PRPOD_KUM { get; set; }
        [StringLength(1)]
        public string VALID { get; set; }
    }
}
