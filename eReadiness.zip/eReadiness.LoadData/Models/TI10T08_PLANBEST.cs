﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace eReadiness.DatabaseModels
{
    public class TI10T08_PLANBEST
    {
        [Key]
        public int Id { get; set; }

        [StringLength(1)]
        public string AEND_KZ { get; set; }
        [StringLength(15)]
        [Index]
        public string TNR { get; set; }
        [StringLength(2)]
        public string GKZ { get; set; }
        [StringLength(8)]
        public string LIEFNR { get; set; }
        [StringLength(2)]
        public string LIEFIDX { get; set; }
        [StringLength(10)]
        public string BESTNR { get; set; }
        [StringLength(10)]
        public string GILT_AB { get; set; }
        [StringLength(10)]
        public string GILT_BIS { get; set; }
        [StringLength(2)]
        public string WK { get; set; }
        [StringLength(3)]
        public string QUOTE { get; set; }
        [StringLength(11)]
        public string BESTMENGE { get; set; }
        [StringLength(4)]
        public string ME { get; set; }
        [StringLength(11)]
        public string A_PREIS { get; set; }
        [StringLength(3)]
        public string WAE_KZ { get; set; }
        [StringLength(4)]
        public string PE { get; set; }
        [StringLength(4)]
        public string LB { get; set; }
        [StringLength(4)]
        public string ZB { get; set; }
        [StringLength(4)]
        public string VB { get; set; }
        [StringLength(11)]
        public string DUNS_NR { get; set; }
    }
}
