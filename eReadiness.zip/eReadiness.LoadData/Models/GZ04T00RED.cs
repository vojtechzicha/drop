﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace eReadiness.DatabaseModels
{
    public class GZ04T00RED
    {
        [Key]
        public int Id { get; set; }

        [Index]
        public int LFDNR { get; set; }

        [StringLength(3)]
        public string UMF { get; set; }

        [StringLength(6)]
        public string TAKT { get; set; }

        [StringLength(12)]
        [Index]
        public string TEIL_NR { get; set; }

        [StringLength(12)]
        public string PFL { get; set; }

        [StringLength(6)]
        public string ARB_PAK_NR { get; set; }

        public int? MENGE { get; set; }

        [StringLength(1)]
        public string ME { get; set; }

        [StringLength(4)]
        public string WWKZ { get; set; }

        [StringLength(80)]
        public string TEGUE { get; set; }

        [StringLength(8)]
        public string EINSCHL { get; set; }

        [StringLength(8)]
        public string ENTSCHL { get; set; }

        [StringLength(8)]
        public string EINS_SER { get; set; }

        [StringLength(8)]
        public string ENTF_SER { get; set; }

        [StringLength(8)]
        public string EINS_NULL { get; set; }

        [StringLength(8)]
        public string ENTF_NULL { get; set; }

        [StringLength(28)]
        public string TYKO { get; set; }

        [StringLength(3)]
        public string U_KZ { get; set; }

        [StringLength(2)]
        public string WK_1 { get; set; }

        [StringLength(1)]
        public string PLAN_1 { get; set; }

        [StringLength(1)]
        public string BZA_1 { get; set; }

        [StringLength(2)]
        public string WK_2 { get; set; }

        [StringLength(1)]
        public string PLAN_2 { get; set; }

        [StringLength(1)]
        public string BZA_2 { get; set; }

        [StringLength(2)]
        public string WK_3 { get; set; }

        [StringLength(1)]
        public string PLAN_3 { get; set; }

        [StringLength(1)]
        public string BZA_3 { get; set; }

        [StringLength(2)]
        public string WK_4 { get; set; }

        [StringLength(1)]
        public string PLAN_4 { get; set; }

        [StringLength(1)]
        public string BZA_4 { get; set; }

        [StringLength(2)]
        public string WK_5 { get; set; }

        [StringLength(1)]
        public string PLAN_5 { get; set; }

        [StringLength(1)]
        public string BZA_5 { get; set; }

        [StringLength(2)]
        public string WK_6 { get; set; }

        [StringLength(1)]
        public string PLAN_6 { get; set; }

        [StringLength(1)]
        public string BZA_6 { get; set; }

        [StringLength(2)]
        public string WK_7 { get; set; }

        [StringLength(1)]
        public string PLAN_7 { get; set; }

        [StringLength(1)]
        public string BZA_7 { get; set; }

        [StringLength(2)]
        public string ZP { get; set; }

        [StringLength(13)]
        public string TAUF_BEM { get; set; }

        [StringLength(4)]
        public string KOST1 { get; set; }

        [StringLength(4)]
        public string KOST2 { get; set; }

        [StringLength(4)]
        public string KOST3 { get; set; }

        [StringLength(4)]
        public string KOST4 { get; set; }

        [StringLength(4)]
        public string KOST5 { get; set; }

        [StringLength(1)]
        public string TART { get; set; }

        [StringLength(1)]
        public string BS { get; set; }

        [StringLength(1)]
        public string FKD { get; set; }

        [StringLength(4)]
        public string PROD { get; set; }

        [StringLength(3)]
        public string PROD_ID { get; set; }

        [StringLength(3)]
        public string PLATF_KZ { get; set; }

        [StringLength(1)]
        public string NLA_SS { get; set; }

        [StringLength(4)]
        public string KOSTGR { get; set; }

        [StringLength(18)]
        public string SZUSATZBEN { get; set; }

        [StringLength(1)]
        public string ENT_KZ { get; set; }

        [StringLength(8)]
        public string PL_P_FRG { get; set; }

        [StringLength(8)]
        public string PL_B_FRG { get; set; }

        [StringLength(8)]
        public string KONA_D { get; set; }

        [StringLength(3)]
        public string UMF_REF { get; set; }

        [StringLength(6)]
        public string TAKT_REF { get; set; }

        public int? LFDNR_REF { get; set; }

        [StringLength(6)]
        public string MOD_KZ { get; set; }

        [Index]
        [StringLength(44)]
        public string TAUF_N { get; set; }

        [Index]
        [StringLength(14)]
        public string TAUF_L { get; set; }

        [StringLength(18)]
        public string FE_BEM { get; set; }

        [StringLength(1)]
        public string GKZ { get; set; }

        [StringLength(1)]
        public string NKZ_1 { get; set; }

        [StringLength(1)]
        public string NKZ_2 { get; set; }

        [StringLength(1)]
        public string NKZ_3 { get; set; }

        [StringLength(10)]
        public string LINIE { get; set; }

        public int? PINDEX { get; set; }

        public int? EINDEX { get; set; }

        public int? SINDEX { get; set; }

        public int? MINDEX { get; set; }

        public int? MEINDEX { get; set; }

        [StringLength(8)]
        public string ENT_ST { get; set; }
    }
}


