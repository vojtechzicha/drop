﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace eReadiness.DatabaseModels
{
    public class SMLOUVY
    {
        [Key]
        public int Id { get; set; }

        [StringLength(2)]
        public string CIZAV { get; set; }
        [Index]
        [StringLength(18)]
        public string MATNR { get; set; }
        [StringLength(35)]
        public string NAME1 { get; set; }
        [StringLength(10)]
        public string LIFNR { get; set; }
        [StringLength(10)]
        public string EBELN { get; set; }
        [StringLength(5)]
        public string EBELP { get; set; }
        [StringLength(3)]
        public string KVOTA { get; set; }
        [StringLength(8)]
        public string DATAB { get; set; }
        [StringLength(8)]
        public string DATBI { get; set; }
        [StringLength(10)]
        public string EBELNOR { get; set; }
    }
}
