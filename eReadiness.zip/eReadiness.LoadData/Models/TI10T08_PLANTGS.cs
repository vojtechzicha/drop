﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace eReadiness.DatabaseModels
{
    public class TI10T08_PLANTGS
    {
        [Key]
        public int Id { get; set; }

        [StringLength(1)]
        public string AEND_KZ { get; set; }

        [StringLength(15)]
        [Index]
        public string TNR { get; set; }

        [StringLength(10)]
        public string LIEFERANT { get; set; }

        [StringLength(3)]
        public string GEN_STAND { get; set; }

        [StringLength(4)]
        public string LS_ID { get; set; }

        [StringLength(10)]
        public string ZEICH_DAT { get; set; }

        [StringLength(8)]
        public string AE_AEA { get; set; }

        [StringLength(9)]
        public string LS_NR { get; set; }

        [StringLength(5)]
        public string ANZAHL { get; set; }

        [StringLength(2)]
        public string WERK { get; set; }

        [StringLength(11)]
        public string DUNS_NR { get; set; }

        [StringLength(15)]
        public string ABLADE_ST { get; set; }
    }
}