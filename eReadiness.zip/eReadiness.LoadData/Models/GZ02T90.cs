﻿using System;
using System.ComponentModel.DataAnnotations;

namespace eReadiness.DatabaseModels
{
    public class GZ02T90
    {
        [Key]
        public int Id { get; set; }

        public DateTime? LAST_LOAD_REDTABLES { get; set; }
        public DateTime? LAST_LOAD_WKTERM { get; set; }
        public DateTime? LAST_LOAD_STEREO { get; set; }
        public DateTime? LAST_LOAD_FAKOM { get; set; }
        public DateTime? LAST_LOAD_MBT { get; set; }
        public DateTime? LAST_LOAD_TEIVON { get; set; }
        public DateTime? LAST_LOAD_DISPO { get; set; }
        public int? LAST_COUNT_ES { get; set; }
        public int? LAST_COUNT_WKTERM { get; set; }
    }
}
