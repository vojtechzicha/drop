﻿using System.ComponentModel.DataAnnotations;

namespace eReadiness.DatabaseModels
{
    public class TI10T08_PLANEPNR
    {
        [Key]
        public int Id { get; set; }

        [StringLength(1)]
        public string AEND_KZ { get; set; }
        [StringLength(3)]
        public string PID { get; set; }
        [StringLength(10)]
        public string EPNR { get; set; }
        [StringLength(12)]
        public string TEIL_NR { get; set; }
        [StringLength(3)]
        public string FKZ { get; set; }
        [StringLength(10)]
        public string LIEFNR { get; set; }
        [StringLength(30)]
        public string LIEF_BEZ { get; set; }
        [StringLength(5)]
        public string MUSTERSOLL_1 { get; set; }
        [StringLength(5)]
        public string MUSTERSOLL_A { get; set; }
        [StringLength(10)]
        public string MUSTER_IST { get; set; }
        [StringLength(1)]
        public string WERKZEUG_KZ { get; set; }
        [StringLength(5)]
        public string WSG { get; set; }
        [StringLength(2)]
        public string VDA_M { get; set; }
        [StringLength(2)]
        public string VDA_L { get; set; }
        [StringLength(2)]
        public string VDA_F { get; set; }
        [StringLength(2)]
        public string VDA_G { get; set; }
        [StringLength(4)]
        public string MENGE { get; set; }
        [StringLength(70)]
        public string BEM { get; set; }
        [StringLength(2)]
        public string F_ANZ { get; set; }
        [StringLength(10)]
        public string F_SOLL { get; set; }
        [StringLength(10)]
        public string F_IST { get; set; }
        [StringLength(2)]
        public string E_ANZ { get; set; }
        [StringLength(10)]
        public string E_SOLL { get; set; }
        [StringLength(10)]
        public string E_IST { get; set; }
        [StringLength(2)]
        public string M_ANZ { get; set; }
        [StringLength(10)]
        public string M_SOLL { get; set; }
        [StringLength(10)]
        public string M_IST { get; set; }
        [StringLength(2)]
        public string L_ANZ { get; set; }
        [StringLength(10)]
        public string L_SOLL { get; set; }
        [StringLength(10)]
        public string L_IST { get; set; }
        [StringLength(3)]
        public string DAUER_ERSTPRF { get; set; }
        [StringLength(3)]
        public string DAUER_FOLGPRF { get; set; }
        [StringLength(3)]
        public string ANZ_CUB { get; set; }
        [StringLength(10)]
        public string ANW_DAT_LAB { get; set; }
        [StringLength(10)]
        public string ANW_DAT_MES { get; set; }
        [StringLength(10)]
        public string ANW_DAT_EIN { get; set; }
        [StringLength(10)]
        public string ANW_DAT_FKT { get; set; }
        [StringLength(10)]
        public string SOLL_DAT_LAB { get; set; }
        [StringLength(10)]
        public string SOLL_DAT_MES { get; set; }
        [StringLength(10)]
        public string SOLL_DAT_EIN { get; set; }
        [StringLength(10)]
        public string SOLL_DAT_FKT { get; set; }
        [StringLength(1)]
        public string TE_NOTE { get; set; }
        [StringLength(10)]
        public string TE_DATUM { get; set; }
        [StringLength(8)]
        public string ZEIDAT_MB { get; set; }
        [StringLength(8)]
        public string ABSCHLDAT { get; set; }
        [StringLength(13)]
        public string GEWICHT { get; set; }
        [StringLength(1)]
        public string LI_WSG_KZ { get; set; }
        [StringLength(5)]
        public string LI_WSG { get; set; }
        [StringLength(25)]
        public string LI_NAME { get; set; }
        [StringLength(15)]
        public string LI_TEL { get; set; }
        [StringLength(8)]
        public string LI_ABT { get; set; }
        [StringLength(8)]
        public string LI_KST { get; set; }
        [StringLength(1)]
        public string IMDS { get; set; }
        [StringLength(3)]
        public string SOLA_STA { get; set; }
        [StringLength(2)]
        public string MERKER_1 { get; set; }
        [StringLength(2)]
        public string MERKER_2 { get; set; }
        [StringLength(2)]
        public string MERKER_3 { get; set; }
        [StringLength(2)]
        public string MERKER_4 { get; set; }
        [StringLength(2)]
        public string MERKER_5 { get; set; }
        [StringLength(1)]
        public string BERICHT_KZ { get; set; }
        [StringLength(1)]
        public string M_PRIO { get; set; }
        [StringLength(10)]
        public string VERSAND_DATUM { get; set; }
        [StringLength(18)]
        public string FILLER { get; set; }

    }
}
